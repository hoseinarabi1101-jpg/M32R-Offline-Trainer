'use strict';
(() => {
  const $ = selector => document.querySelector(selector);
  const clamp = (x, a=0, b=1) => Math.max(a, Math.min(b, x));
  const escapeHTML = value => String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
  const nativeStore = () => Boolean(window.M32_ANDROID && window.AndroidBridge && typeof window.AndroidBridge.getStore==='function');
  const getStore = key => {try{return nativeStore()?window.AndroidBridge.getStore(key):localStorage.getItem(key);}catch{return null;}};
  const setStore = (key,value) => {try{return nativeStore()?window.AndroidBridge.setStore(key,value):localStorage.setItem(key,value);}catch{return null;}};
  const ch2 = n => String(n).padStart(2,'0');
  const names = { ch:'CH',auxin:'AUX',fxrtn:'FX',bus:'BUS',dca:'DCA',mtx:'MTX',mono:'MONO',main:'MAIN' };
  const banks = [
    {id:'ch1',label:'CH 01–08',kind:'ch',start:1,count:8},
    {id:'ch2',label:'CH 09–16',kind:'ch',start:9,count:8},
    {id:'ch3',label:'CH 17–24',kind:'ch',start:17,count:8},
    {id:'ch4',label:'CH 25–32',kind:'ch',start:25,count:8},
    {id:'aux',label:'AUX 01–08',kind:'auxin',start:1,count:8},
    {id:'fx',label:'FX RETURNS',kind:'fxrtn',start:1,count:8},
    {id:'bus1',label:'BUS 01–08',kind:'bus',start:1,count:8},
    {id:'bus2',label:'BUS 09–16',kind:'bus',start:9,count:8},
    {id:'dca',label:'DCA 01–08',kind:'dca',start:1,count:8},
    {id:'mtx',label:'MATRIX / MONO',kind:'mtx',start:1,count:7},
  ];
  const remote = { bank:'ch1', selected:{kind:'ch',n:1}, tab:'eq', values:{}, pending:{}, lastTouch:{}, target:null,connected:true, lastReply:0, hasBridge:false, name:'' };
  let activeMode = 'remote';
  let localTracks = [];
  let fileSelected = null;
  let fileTab = 'eq';
  let fileMaster = { fader:0.75, mute:false };
  let audioContext = null;
  let playback = null;
  let playOffset = 0;
  let audioDuration = 0;
  let lastScrub = false;
  let toastTimer = null;
  let sendOnFaders=false;
  let selectedSendBus=1;
  let saveTimer=null;
  let trackId = 0;
  let fxChannel=1;
  const geqFreqs=[20,25,31.5,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000];
  let geqGains=Array(31).fill(0);
  try{const saved=JSON.parse(getStore('m32r_geq')||'null');if(Array.isArray(saved)&&saved.length===31)geqGains=saved.map(v=>clamp(Number(v),-12,12));}catch{}
  const saveGEQ=()=>{try{setStore('m32r_geq',JSON.stringify(geqGains));}catch{}};
  let proCurrent='mixer';
  let selectedOutput='main';
  const trainingSettings={matrix:{},routing:{},brightness:90};

  // Eight independent DELAY processors. Slots 1-4 use Bus 13-16;
  // slots 5-8 are virtual audio sends (not hardware M32 insert routing).
  const FX_COUNT=8;
  const fxId=n=>'fx'+n;
  const fxDefaults=()=>Object.fromEntries(Array.from({length:FX_COUNT},(_,i)=>{
    const time=[275,400,550,680,850,1000,1250,1600][i];
    return [fxId(i+1),{on:true,toMain:true,level:.25,time,feedback:.27,pingpong:i%3===1,triple:i%3===2}];
  }));
  let fxRack=fxDefaults();
  try {
    const saved=JSON.parse(getStore('m32r_fx_delay')||'null');
    if(saved&&saved.fx1){for(const k of Object.keys(fxRack))fxRack[k]={...fxRack[k],...(saved[k]||{})};}
  }catch{}
  for(const k of Object.keys(fxRack)){
    fxRack[k].time=clamp(Number(fxRack[k].time)||350,1,2000);
    fxRack[k].feedback=clamp(Number(fxRack[k].feedback)||0,0,.75);
  }
  function saveFX(){try{setStore('m32r_fx_delay',JSON.stringify(fxRack));}catch{}}
  const slotSendPath=(channel,slot)=>slot<=4?effectSendPath(channel,slot+12):`/ch/${ch2(channel)}/fx/${slot}/level`;

  function effectSendPath(n,bus){return `/ch/${ch2(n)}/mix/${ch2(bus)}/level`;}

  const channelsForBank = bank => {
    if (bank.kind === 'mtx') return [...Array(6)].map((_,i)=>({kind:'mtx',n:i+1})).concat([{kind:'mono',n:1}]);
    return [...Array(bank.count)].map((_,i)=>({kind:bank.kind,n:bank.start+i}));
  };
  const basePath = item => item.kind === 'main' ? '/main/st' : item.kind === 'mono' ? '/main/m' : `/${item.kind}/${item.kind==='dca' ? item.n : ch2(item.n)}`;
  const pathFor = (item, field) => `${basePath(item)}/mix/${field}`;
  function soloPath(item) {
    let n;
    if (item.kind==='ch') n=item.n;
    else if (item.kind==='auxin') n=32+item.n;
    else if (item.kind==='fxrtn') n=40+item.n;
    else if (item.kind==='bus') n=48+item.n;
    else if (item.kind==='mtx') n=64+item.n;
    else if (item.kind==='main') n=71;
    return n ? `/-stat/solosw/${ch2(n)}` : null;
  }
  function db(f) {
    if (f === undefined || f === null || f <= 0) return '-∞';
    const d = f >= 0.5 ? 40*f-30 : f>=.25 ? 80*f-50 : f>=.0625 ? 160*f-70 : 480*f-90;
    return (d>=0 ? '+' : '') + d.toFixed(1);
  }
  function gain(f) {
    if (f <= 0) return 0;
    const x = f >= .5 ? 40*f-30 : f>=.25 ? 80*f-50 : f>=.0625 ? 160*f-70 : 480*f-90;
    return Math.pow(10, x/20);
  }
  const notify = (message, duration=3800) => {
    const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>el.classList.remove('show'),duration);
  };
  function simFaderPath(item) {
    return sendOnFaders && item.kind === 'ch'
      ? `/ch/${ch2(item.n)}/mix/${ch2(selectedSendBus)}/level`
      : pathFor(item,'fader');
  }
  function initialScene(){
    const vals={};
    for(const kind of ['ch','auxin','fxrtn','bus','dca','mtx','mono','main']){
      const count={ch:32,auxin:8,fxrtn:8,bus:16,dca:8,mtx:6,mono:1,main:1}[kind];
      for(let n=1;n<=count;n++){
        const it={kind,n}; vals[pathFor(it,'fader')]=.75;
        vals[pathFor(it,'on')]=1;
        const sp=soloPath(it);if(sp)vals[sp]=0;
      }
    }
    for(let n=1;n<=32;n++){
      const pre=`/ch/${ch2(n)}`;
      vals[`${pre}/mix/pan`]=.5;
      vals[`${pre}/eq/on`]=1;
      vals[`${pre}/gate/on`]=0;
      vals[`${pre}/gate/thr`]=.5;
      vals[`${pre}/dyn/on`]=0;
      vals[`${pre}/dyn/thr`]=.6;
      for(let b=1;b<=4;b++){
        const bp=`${pre}/eq/${b}`;
        vals[bp+'/f']=[.233,.451,.699,.885][b-1];
        vals[bp+'/g']=.5; vals[bp+'/q']=.68;
      }
      for(let b=1;b<=16;b++)vals[`${pre}/mix/${ch2(b)}/level`]=0;
    }
    return vals;
  }
  function initScene(){
    remote.values=initialScene();
    try {
      const loaded=JSON.parse(getStore('m32r_current_state')||'null');
      if(loaded && typeof loaded==='object' && !Array.isArray(loaded))
        Object.assign(remote.values,loaded);
    }catch{}
    fileMaster.fader=remote.values['/main/st/mix/fader'];
    fileMaster.mute=remote.values['/main/st/mix/on']===0;
  }
  function persistScene(){
    clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{try{setStore('m32r_current_state',JSON.stringify(remote.values));}catch{}},250);
  }
  function trackAtChannel(n){return localTracks.find(t=>t.channel===n);}
  function syncAudioFromSim(path,value){
    const fxMatch=path.match(/^\/fxrtn\/(\d{2})\/mix\/(fader|on)$/);
    if(fxMatch){
      const id=fxId(Number(fxMatch[1]));
      if(fxRack[id]){if(fxMatch[2]==='fader')fxRack[id].level=Number(value);
        else fxRack[id].on=!!value;
        saveFX();updateFXGraph();}
      return;
    }
    if(path==='/main/st/mix/fader'){fileMaster.fader=value;updateGraph();updateLocalStripData();return;}
    if(path==='/main/st/mix/on'){fileMaster.mute=value===0;updateGraph();updateLocalStripData();return;}
    const solo=path.match(/^\/-stat\/solosw\/(\d+)$/);
    if(solo){const t=trackAtChannel(+solo[1]);if(t){t.solo=!!value;updateGraph();updateLocalStripData();}return;}
    const m=path.match(/^\/ch\/(\d{2})\/(.+)$/);
    if(!m)return;
    const t=trackAtChannel(+m[1]);if(!t)return;
    const field=m[2];
    if(field==='mix/fader')t.fader=value;
    else if(field==='mix/on')t.mute=value===0;
    else if(field==='mix/pan')t.pan=(value-.5)*2;
    else if(field==='config/name')t.name=String(value);
    else if(field==='eq/on')t.eqOn=value===1;
    else if(field==='dyn/on')t.comp.on=value===1;
    else if(field==='dyn/thr')t.comp.threshold=-60+60*value;
    else {
      const e=field.match(/^eq\/(\d)\/(f|g|q)$/);
      if(e){const band=t.eq[+e[1]-1];if(band) {
        if(e[2]==='f')band.freq=20*Math.pow(1000,value);
        if(e[2]==='g')band.gain=(value-.5)*30;
        if(e[2]==='q')band.q=10*Math.pow(.03,value);
      }}
    }
    updateGraph();updateLocalStripData();
  }
  function applySimToTrack(t){
    const n=ch2(t.channel),p=`/ch/${n}`;
    for(const [path,v] of Object.entries(remote.values)){
      if(path.startsWith(p+'/')||path===`/-stat/solosw/${n}`)syncAudioFromSim(path,v);
    }
    if(!remote.values[p+'/config/name'])remote.values[p+'/config/name']=t.name.slice(0,12);
    else t.name=String(remote.values[p+'/config/name']);
    updateRemoteStripData();persistScene();
  }
  function pushTrackToSim(t){
    const n=ch2(t.channel),p=`/ch/${n}`;
    remote.values[p+'/config/name']=t.name.slice(0,12);
    remote.values[p+'/mix/fader']=t.fader;
    remote.values[p+'/mix/on']=t.mute?0:1;
    remote.values[p+'/mix/pan']=(t.pan+1)/2;
    remote.values[`/-stat/solosw/${n}`]=t.solo?1:0;
    remote.values[p+'/eq/on']=t.eqOn===false?0:1;
    remote.values[p+'/dyn/on']=t.comp.on?1:0;
    remote.values[p+'/dyn/thr']=(t.comp.threshold+60)/60;
    t.eq.forEach((band,i)=>{
      remote.values[`${p}/eq/${i+1}/f`]=clamp(Math.log(band.freq/20)/Math.log(1000));
      remote.values[`${p}/eq/${i+1}/g`]=clamp(band.gain/30+.5);
      remote.values[`${p}/eq/${i+1}/q`]=clamp(Math.log(band.q/10)/Math.log(.03));
    });
    persistScene();updateRemoteStripData();
  }
  async function remoteSet(path,value){
    remote.values[path]=value;
    syncAudioFromSim(path,value);
    persistScene();
    return true;
  }
  function sceneRestore(values){
    remote.values={...initialScene(),...values};
    for(const t of localTracks){
      const n=ch2(t.channel),p=`/ch/${n}`;
      for(const [path,v] of Object.entries(remote.values)){
        if(path.startsWith(p+'/')||path===`/-stat/solosw/${n}`)syncAudioFromSim(path,v);
      }
    }
    syncAudioFromSim('/main/st/mix/fader',remote.values['/main/st/mix/fader']);
    syncAudioFromSim('/main/st/mix/on',remote.values['/main/st/mix/on']);
    makeStrips();updateRemoteInspector();updateGraph();persistScene();renderFX();
  }
  function sceneButtons(){
    $('#saveScene').onclick=()=>{
      const name=prompt('نام Scene را وارد کن (مثل جلسه اول):','تمرین من');if(!name)return;
      try{
        const scenes=JSON.parse(getStore('m32r_scenes')||'{}');
        scenes[name.trim()]={values:JSON.parse(JSON.stringify(remote.values)),fx:JSON.parse(JSON.stringify(fxRack)),geq:geqGains.slice()};
        setStore('m32r_scenes',JSON.stringify(scenes));notify('Scene «'+name.trim()+'» ذخیره شد.');
      }catch(e){notify('ذخیره انجام نشد: '+e.message);}
    };
    $('#loadScene').onclick=()=>{
      try{
        const scenes=JSON.parse(getStore('m32r_scenes')||'{}'), names=Object.keys(scenes);
        if(!names.length){notify('هنوز Scene ذخیره نکرده‌ای.');return;}
        const name=prompt('نام Scene را وارد کن:\n'+names.join(' / '),names[names.length-1]);
        if(!name)return;if(!scenes[name.trim()]){notify('Scene پیدا نشد.');return;}
        const scene=scenes[name.trim()];sceneRestore(scene.values||scene);if(scene.fx){fxRack=fxDefaults();for(const k of Object.keys(fxRack))fxRack[k]={...fxRack[k],...(scene.fx[k]||{})};saveFX();updateFXGraph();renderFX();}if(Array.isArray(scene.geq)&&scene.geq.length===31){geqGains=scene.geq.map(v=>clamp(Number(v),-12,12));saveGEQ();updateGraph();}notify('Scene بازیابی شد.');
      }catch(e){notify('بازیابی ممکن نشد: '+e.message);}
    };
    $('#resetScene').onclick=()=>{
      if(!confirm('تمام تنظیمات میکسر مجازی صفر/پیش‌فرض شوند؟ فایل‌های صوتی حذف نمی‌شوند.'))return;
      sceneRestore({});fxRack=fxDefaults();geqGains.fill(0);saveGEQ();saveFX();updateFXGraph();updateGraph();renderFX();notify('تنظیمات به حالت پیش‌فرض برگشت.');
    };
    $('#sofButton').onclick=()=>{
      sendOnFaders=!sendOnFaders;
      const btn=$('#sofButton');btn.classList.toggle('active-sof',sendOnFaders);
      btn.textContent=`SENDS ON FADERS: ${sendOnFaders?'ON · BUS '+ch2(selectedSendBus):'OFF'}`;
      updatePracticeStatus();makeStrips();
    };
  }
  function updatePracticeStatus(){
    $('#practiceStatus').textContent=sendOnFaders
      ? `حالت Sends on Faders · BUS ${ch2(selectedSendBus)}: فیدرهای CH سطح ارسال به این باس را تغییر می‌دهند. برای عوض‌کردن باس روی BUS 1–16 برو و SELECT را بزن. (صرفاً شبیه‌سازی مسیر؛ بدون پردازش Bus)`
      : `${banks.find(b=>b.id===remote.bank)?.label||''} · حالت عادی · روی SELECT بزن تا تنظیمات کانال را ببینی. برای تمرین شنیداری از «آوردن صدای واقعی» استفاده کن.`;
  }
  async function makeDemo(){
    if(localTracks.length){notify('برای ساخت صدای آزمایشی، ابتدا ترک‌های قبلی را از بخش میکس فایل‌ها پاک کن.');return;}
    audioContext||=new (window.AudioContext||window.webkitAudioContext)();
    const rate=22050,duration=16,count=Math.round(rate*duration);
    const samples=[110,220,440,880];
    for(let i=0;i<4;i++){
      const buffer=audioContext.createBuffer(1,count,rate),data=buffer.getChannelData(0),freq=samples[i];
      for(let j=0;j<count;j++){
        const t=j/rate,env=Math.min(1,t*15)*Math.min(1,(duration-t)*5);
        data[j]=env*(.23*Math.sin(2*Math.PI*freq*t)+.08*Math.sin(2*Math.PI*freq*2*t)+.02*Math.sin(2*Math.PI*freq*3*t));
      }
      const names=['بم · Bass','صدای بم','صدای میانی','صدای زیر'];
      const t={id:++trackId,channel:i+1,name:names[i],fader:.75,mute:false,solo:false,pan:0,eq:localEqDefaults(),eqOn:true,comp:{on:false,threshold:-24,ratio:3},buffer,size:count*4};
      localTracks.push(t);applySimToTrack(t);
    }
    renderLocal();makeStrips();renderFX();notify('۴ منبع صوتی آزمایشی روی CH 1–4 قرار گرفت. پخش را بزن و EQ و فیدرها را تغییر بده.',6000);
  }
  function makeStrips() {
    $('#bankbar').innerHTML=banks.map(b=>`<button class="bank-button ${remote.bank===b.id?'active':''}" data-bank="${b.id}">${b.label}</button>`).join('');
    $('#bankCaption').textContent=banks.find(b=>b.id===remote.bank)?.label||'';
    $('#remoteStrips').innerHTML=channelsForBank(banks.find(b=>b.id===remote.bank)).map(item=>stripHTML(item,'remote')).join('');
    $('#remoteMaster').innerHTML=stripHTML({kind:'main',n:1},'remote');
    updateRemoteStripData();updatePracticeStatus();
  }
  function stripHTML(item, mode) {
    const isRemote=mode==='remote';
    const id=isRemote ? `${item.kind}-${item.n}` : String(item.id);
    const identity = isRemote ? `${names[item.kind]} ${item.kind==='main' ? 'L/R' : ch2(item.n)}` : `FILE ${String(localTracks.indexOf(item)+1).padStart(2,'0')}`;
    const selected = isRemote ? (remote.selected.kind===item.kind&&remote.selected.n===item.n) : (fileSelected===item.id);
    const value=isRemote ? remote.values[simFaderPath(item)] : item.fader;
    const level=typeof value==='number' ? clamp(value) : .75;
    const label = isRemote ? (remote.values[`${basePath(item)}/config/name`]||identity) : item.name;
    const muted = isRemote ? remote.values[pathFor(item,'on')]===0 : item.mute;
    const solo = isRemote ? Boolean(remote.values[soloPath(item)]) : item.solo;
    const soloAllowed = isRemote ? Boolean(soloPath(item)) : item.id!=='file-master';
    return `<div class="strip ${selected?'selected':''} ${item.kind==='main'?'master':''}" data-id="${escapeHTML(id)}" data-mode="${mode}">
      <div class="strip-title">${escapeHTML(identity)}</div>
      <div class="scribble"><span class="scribble-name" title="${escapeHTML(label)}">${escapeHTML(label)}</span><span class="scribble-sub">${isRemote ? (sendOnFaders&&item.kind==='ch'? 'SEND BUS '+ch2(selectedSendBus) : 'OFFLINE') : 'LOCAL AUDIO'}</span></div>
      <div class="meter-mini" aria-label="متر سطح صدای واقعی در این نسخه موجود نیست"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
      <button class="strip-btn select ${selected?'active':''}" data-action="select">SELECT</button>
      <button class="strip-btn solo ${solo?'active':''}" data-action="solo" ${soloAllowed?'':'disabled'}>SOLO</button>
      <div class="fader-container" role="slider" tabindex="0" data-action="fader" aria-label="${escapeHTML(label)} فیدر" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(level*100)}" style="--level:${level};--knob:${(level*165).toFixed(2)}px">
        <div class="fader-markers"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        <div class="fader-rail"></div><div class="fader-knob"></div>
      </div>
      <div class="db-number">${isRemote&&typeof value!=='number'?'—':db(level)} dB</div>
      <button class="strip-btn mute ${muted?'active':''}" data-action="mute">MUTE</button>
    </div>`;
  }
  function updateVisualStrip(el, item, mode) {
    if (!el) return;
    const r=mode==='remote';
    const f=r ? remote.values[simFaderPath(item)] : item.fader;
    const level=typeof f==='number'?clamp(f):.75;
    const fader=el.querySelector('.fader-container');
    if (!fader.matches(':active')&&!fader.hasAttribute('data-dragging')) {
      fader.style.setProperty('--level',level);fader.style.setProperty('--knob',`${(level*165).toFixed(2)}px`);
      fader.setAttribute('aria-valuenow',String(Math.round(level*100)));
      el.querySelector('.db-number').textContent=r&&typeof f!=='number' ? '— dB' : `${db(level)} dB`;
    }
    const name=r ? remote.values[`${basePath(item)}/config/name`] : item.name;
    if (name) el.querySelector('.scribble-name').textContent=String(name);
    const muted=r ? remote.values[pathFor(item,'on')]===0 : item.mute;
    el.querySelector('.mute').classList.toggle('active',Boolean(muted));
    const solo=r ? Boolean(remote.values[soloPath(item)]) : item.solo;
    el.querySelector('.solo').classList.toggle('active',Boolean(solo));
    const isSelected=r ? remote.selected.kind===item.kind&&remote.selected.n===item.n : fileSelected===item.id;
    el.classList.toggle('selected',isSelected);
    el.querySelector('.select').classList.toggle('active',isSelected);
  }
  function updateRemoteStripData() {
    document.querySelectorAll('#remoteStrips .strip,#remoteMaster .strip').forEach(el => {
      const [kind,n]=el.dataset.id.split('-');updateVisualStrip(el,{kind,n:Number(n)},'remote');
    });
  }
  // Offline simulator: edits are stored locally, never sent to a console.
  function setRemoteFader(item,level) {remoteSet(simFaderPath(item),level);}
  function selectRemote(item) {
    remote.selected={kind:item.kind,n:item.n};remote.tab='eq';
    updateRemoteStripData(); updateRemoteInspector();
    if(item.kind==='bus'){selectedSendBus=item.n;$('#sofButton').textContent=`SENDS ON FADERS: ${sendOnFaders?'ON · BUS '+ch2(selectedSendBus):'OFF'}`;updatePracticeStatus();}
  }
  const isNumeric = x => typeof x==='number'&&Number.isFinite(x);
  const rv = (path,defaultValue=.5) => isNumeric(remote.values[path]) ? remote.values[path] : defaultValue;
  const controlHTML = (label,path,def,formatter) => `<div class="control-row" data-path="${escapeHTML(path)}"><label><span>${label}</span><output>${escapeHTML(formatter(rv(path,def)))}</output></label><input type="range" class="remote-input" data-path="${escapeHTML(path)}" min="0" max="1000" value="${Math.round(rv(path,def)*1000)}" data-format="${escapeHTML(label)}" /></div>`;
  const toggleHTML = (label,path) => `<div class="toggle-row"><span>${escapeHTML(label)}</span><button class="toggle ${rv(path,0)===1?'on':''}" type="button" data-toggle="${path}" aria-label="${escapeHTML(label)}"></button></div>`;
  // Interactive 4-band EQ in the same dark plotted style as the 31-band GEQ.
  // The plotted curve is a visual approximation; the actual sound uses the
  // native WebAudio low/high shelves and peaking biquad filters.
  const peqColors=['#ee8e75','#f4bd56','#64d9c5','#a999f3'];
  const peqLabels=['LOW','LOW MID','HIGH MID','HIGH'];
  function peqBands(mode){
    if(mode==='file'){
      const t=localTracks.find(t=>t.id===fileSelected);
      return t?t.eq.map(b=>({...b})):localEqDefaults();
    }
    const p=`/ch/${ch2(remote.selected.n)}/eq`;
    return Array.from({length:4},(_,i)=>{
      const b=i+1;
      return {freq:20*Math.pow(1000,rv(`${p}/${b}/f`,[.233,.451,.699,.885][i])),
        gain:(rv(`${p}/${b}/g`,.5)-.5)*30,
        q:10*Math.pow(.03,rv(`${p}/${b}/q`,.68)),
        type:i===0?'lowshelf':i===3?'highshelf':'peaking'};
    });
  }
  function peQPanel(mode){
    const bands=peqBands(mode);
    return `<section class="peq-panel"><div class="peq-heading"><strong>PARAMETRIC EQ · 4 BAND</strong><small>نمودار و فیدرهای گرافیکی · نقطه‌های رنگی را لمس و جابه‌جا کن</small></div>
      <canvas class="peq-plot" data-peq-kind="${mode}" aria-label="اکولایزر پارامتریک ۴ بانده قابل‌لمس"></canvas>
      <div class="peq-band-row" dir="ltr">${bands.map((b,i)=>`<div class="peq-band" style="--peq-color:${peqColors[i]}">
        <b>${peqLabels[i]}</b><output>${b.gain>0?'+':''}${b.gain.toFixed(1)} dB</output>
        <input class="peq-gain" type="range" orient="vertical" min="-15" max="15" step=".5" data-peq-gain="${i}" data-peq-mode="${mode}" value="${b.gain.toFixed(1)}" aria-label="gain band ${i+1}">
        <span class="peq-freq">${b.freq>=1000?(b.freq/1000).toFixed(1)+'k':b.freq.toFixed(0)} Hz</span></div>`).join('')}</div>
      <div class="peq-legend" dir="ltr"><span>20 Hz</span><span>100</span><span>1k</span><span>10k</span><span>20 kHz</span><strong>±15 dB</strong></div></section>`;
  }
  function peqMagnitude(b,f){
    const oct=Math.log2(f/b.freq),width=Math.max(.2,1.1/Math.sqrt(Math.max(.2,b.q)));
    if(b.type==='lowshelf')return b.gain/(1+Math.exp(clamp(oct*3/width,-35,35)));
    if(b.type==='highshelf')return b.gain/(1+Math.exp(clamp(-oct*3/width,-35,35)));
    return b.gain*Math.exp(-.5*(oct/width)**2);
  }
  function drawPEQ(mode){
    const canvas=document.querySelector(`#${mode==='remote'?'remoteInspector':'fileInspector'} .peq-plot`);
    if(!canvas)return;
    const w=Math.max(260,canvas.clientWidth||600),h=Math.max(160,canvas.clientHeight||210),dpi=window.devicePixelRatio||1;
    canvas.width=Math.round(w*dpi);canvas.height=Math.round(h*dpi);
    const c=canvas.getContext('2d');c.setTransform(dpi,0,0,dpi,0,0);
    const left=36,right=w-17,top=20,bottom=h-25;
    const fw=right-left,fh=bottom-top,mid=(top+bottom)/2;
    const xAt=f=>left+fw*clamp(Math.log(f/20)/Math.log(1000));
    const yAt=db=>mid-clamp(db,-15,15)*(fh/30);
    c.fillStyle='#091827';c.fillRect(0,0,w,h);
    c.font='11px monospace';c.lineWidth=1;
    for(let db=-15;db<=15;db+=5){let y=yAt(db);c.strokeStyle=db===0?'#6a8fa6':'#284052';c.beginPath();c.moveTo(left,y);c.lineTo(right,y);c.stroke();c.fillStyle='#91a8b8';c.textAlign='right';c.fillText(db>0?'+'+db:db.toString(),left-5,y+4);}
    for(let f of [20,50,100,200,500,1000,2000,5000,10000,20000]){const x=xAt(f);c.strokeStyle='#26394a';c.beginPath();c.moveTo(x,top);c.lineTo(x,bottom);c.stroke();}
    const bands=peqBands(mode); const enabled=mode==='remote'?rv(`/ch/${ch2(remote.selected.n)}/eq/on`,1)!==0:(localTracks.find(t=>t.id===fileSelected)?.eqOn!==false);
    const pts=[];
    for(let i=0;i<=350;i++){
      const f=20*Math.pow(1000,i/350);
      const gain=enabled?bands.reduce((sum,b)=>sum+peqMagnitude(b,f),0):0;
      pts.push([xAt(f),yAt(gain)]);
    }
    c.beginPath();pts.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));
    c.strokeStyle=enabled?'#f3bc65':'#657f90';c.lineWidth=3;c.shadowColor='#eda94755';c.shadowBlur=7;c.stroke();c.shadowBlur=0;
    bands.forEach((b,i)=>{
      const x=xAt(b.freq),y=yAt(b.gain);c.strokeStyle=peqColors[i]+'88';c.setLineDash([4,5]);c.beginPath();c.moveTo(x,top);c.lineTo(x,bottom);c.stroke();c.setLineDash([]);
      c.beginPath();c.arc(x,y,8,0,Math.PI*2);c.fillStyle=peqColors[i];c.fill();c.strokeStyle='#ffffff';c.lineWidth=2;c.stroke();
      c.fillStyle='#f7f9fc';c.textAlign='center';c.font='bold 10px sans-serif';c.fillText(String(i+1),x,y-12);
    });
  }
  function refreshPEQ(mode){
    const root=document.querySelector(mode==='remote'?'#remoteInspector':'#fileInspector');if(!root?.querySelector('.peq-panel'))return;
    const bands=peqBands(mode);
    root.querySelectorAll('.peq-band').forEach((el,i)=>{
      const b=bands[i];el.querySelector('output').textContent=(b.gain>0?'+':'')+b.gain.toFixed(1)+' dB';
      const gain=el.querySelector('input');if(gain!==document.activeElement)gain.value=b.gain.toFixed(1);
      el.querySelector('.peq-freq').textContent=(b.freq>=1000?(b.freq/1000).toFixed(1)+'k':b.freq.toFixed(0))+' Hz';
    });
    drawPEQ(mode);
  }
  function adjustPEQ(mode,index,freq,amount){
    const b=Math.max(0,Math.min(3,index));
    if(mode==='remote'){
      const p=`/ch/${ch2(remote.selected.n)}/eq/${b+1}`;
      if(freq!==null)remoteSet(p+'/f',clamp(Math.log(clamp(freq,20,20000)/20)/Math.log(1000)));
      if(amount!==null)remoteSet(p+'/g',clamp(amount/30+.5));
      refreshInspectorValues();
    }else{
      const t=localTracks.find(t=>t.id===fileSelected);if(!t)return;
      if(freq!==null)t.eq[b].freq=clamp(freq,20,20000);
      if(amount!==null)t.eq[b].gain=clamp(amount,-15,15);
      pushTrackToSim(t);updateGraph();
      document.querySelectorAll('#fileInspector [data-local-field]').forEach(el=>{
        const m=el.dataset.localField.match(/^eq\.(\d+)\.(freq|gain)$/);
        if(m&&Number(m[1])===b){let v=t.eq[b][m[2]];el.value=v;el.closest('.control-row').querySelector('output').textContent=v.toFixed(m[2]==='gain'?1:0)+(m[2]==='freq'?' Hz':' dB');}
      });
    }
    refreshPEQ(mode);
  }
  function initPEQEvents(){
    for(const mode of ['remote','file']){
      const root=document.querySelector(mode==='remote'?'#remoteInspector':'#fileInspector');
      root.addEventListener('input',e=>{
        const f=e.target.closest('[data-peq-gain]');if(!f)return;
        adjustPEQ(mode,+f.dataset.peqGain,null,+f.value);
      });
      root.addEventListener('pointerdown',e=>{
        const canvas=e.target.closest('.peq-plot');if(!canvas||e.button!==0)return;
        e.preventDefault();canvas.setPointerCapture(e.pointerId);
        const r=canvas.getBoundingClientRect();
        const bands=peqBands(mode);
        // Find closest colored handle horizontally; dragging moves that band's freq/gain.
        const xNorm=(e.clientX-r.left-36)/Math.max(1,r.width-53);
        let idx=0,minD=999;
        bands.forEach((b,i)=>{let d=Math.abs(Math.log(b.freq/20)/Math.log(1000)-xNorm);if(d<minD){idx=i;minD=d;}});
        canvas.dataset.peqDrag=String(idx);
        const update=ev=>{
          const rect=canvas.getBoundingClientRect();
          const n=clamp((ev.clientX-rect.left-36)/(rect.width-53));
          const y=clamp((ev.clientY-rect.top-20)/(rect.height-45));
          adjustPEQ(mode,idx,20*Math.pow(1000,n),15-y*30);
        };
        canvas._peqMove=update;update(e);
      });
      root.addEventListener('pointermove',e=>{const canvas=e.target.closest('.peq-plot');if(canvas?.hasPointerCapture(e.pointerId))canvas._peqMove?.(e);});
      root.addEventListener('pointerup',e=>{const canvas=e.target.closest('.peq-plot');if(canvas?.hasPointerCapture(e.pointerId)){canvas.releasePointerCapture(e.pointerId);delete canvas.dataset.peqDrag;}});
    }
  }

  function updateRemoteInspector() {
    const item=remote.selected;
    const heading=`<div class="inspector-title"><h3>پردازش کانال ${names[item.kind]} ${ch2(item.n)}</h3><span class="caption">SIMULATION · مستقل از سخت‌افزار</span></div>`;
    if (item.kind!=='ch') {
      $('#remoteInspector').innerHTML=heading+`<p class="small-message">فیدر، Solo و Mute این لایه تمرینی هستند. برای تنظیم EQ، کمپرسور و Sends از لایه CH 01–32 کانالی را انتخاب کن.</p>`;
      return;
    }
    const p=`/ch/${ch2(item.n)}`;
    const tabs=[['eq','EQ · اکولایزر'],['dyn','DYNAMICS'],['fx','FX1–FX8 · DELAY'],['send','BUS SENDS'],['pan','PAN / NAME']];
    let html=heading+`<div class="inspector-nav">${tabs.map(([id,label])=>`<button class="subtab ${remote.tab===id?'active':''}" data-remotetab="${id}">${label}</button>`).join('')}</div>`;
    if (remote.tab==='eq') {
      html+=peQPanel('remote')+`<div class="editor-grid"><div class="editor-card"><strong>PARAMETRIC EQ</strong>${toggleHTML('EQ روشن',`${p}/eq/on`)}<p class="small-message">چهار باند پارامتریکِ آموزشی. EQ روی فایل صوتی بارگذاری‌شده اثر می‌گذارد.</p></div>`;
      for (let i=1;i<=4;i++) {
        const bp=`${p}/eq/${i}`;
        html+=`<div class="editor-card"><strong>BAND ${i}</strong>${controlHTML('فرکانس',`${bp}/f`,[.23,.45,.65,.87][i-1],v=>`${Math.round(20*Math.pow(1000,v))} Hz`)}${controlHTML('گین',`${bp}/g`,.5,v=>`${((v-.5)*30).toFixed(1)} dB`)}${controlHTML('Q',`${bp}/q`,.5,v=>`${(10*Math.pow(.03,v)).toFixed(2)}`)}</div>`;
      }
      html+='</div>';
    } else if (remote.tab==='dyn') {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>GATE</strong>${toggleHTML('Gate روشن',`${p}/gate/on`)}${controlHTML('Threshold',`${p}/gate/thr`,.5,v=>`${Math.round(-80+80*v)} dB`)}</div><div class="editor-card"><strong>COMPRESSOR</strong>${toggleHTML('Compressor روشن',`${p}/dyn/on`)}${controlHTML('Threshold',`${p}/dyn/thr`,.6,v=>`${Math.round(-60+60*v)} dB`)}</div></div><p class="small-message">توجه: کمپرسور روی فایل صوتی پردازش می‌شود؛ Gate در این نسخه صرفاً برای تمرین نمایش و تنظیم می‌شود.</p>`;
    } else if(remote.tab==='fx'){
      html+=`<div class="editor-grid">${Array.from({length:FX_COUNT},(_,i)=>{
        const slot=i+1;
        return `<div class="editor-card"><strong>FX${slot} · DELAY ${slot<=4?'· BUS '+(12+slot):'· VIRTUAL SEND'}</strong>${controlHTML('SEND LEVEL',slotSendPath(item.n,slot),0,v=>`${db(v)} dB`)}</div>`;
      }).join('')}<div class="editor-card"><strong>رک دیلی</strong><button class="primary" type="button" id="gotoFXfromInspector">✨ تنظیم ۸ دیلی (حداکثر ۲۰۰۰ms)</button></div></div>`;

    } else if (remote.tab==='send') {
      html+='<div class="editor-grid">';
      for (let i=1;i<=16;i++) { const sendp=`${p}/mix/${ch2(i)}/level`; html+=`<div class="editor-card"><strong>BUS ${ch2(i)}</strong>${controlHTML('SEND LEVEL',sendp,0,v=>`${db(v)} dB`)}</div>`; }
      html+='</div>';
    } else {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>STEREO PAN</strong>${controlHTML('PAN',`${p}/mix/pan`,.5,v=>Math.abs(v-.5)<.01?'CENTER':v<.5?`L ${Math.round((.5-v)*200)}%`:`R ${Math.round((v-.5)*200)}%`)}</div><div class="editor-card"><strong>CHANNEL LABEL</strong><label class="field">نام کانال<input id="remoteChannelName" type="text" maxlength="12" value="${escapeHTML(remote.values[`${p}/config/name`]||'')}" placeholder="CH ${ch2(item.n)}" /></label><button class="soft" id="nameSave">ذخیره نام</button></div></div>`;
    }
    $('#remoteInspector').innerHTML=html;
    if(remote.tab==='eq')requestAnimationFrame(()=>drawPEQ('remote'));
  }
  function fmtRemote(label,v){if(label==='فرکانس')return `${Math.round(20*Math.pow(1000,v))} Hz`;if(label==='گین')return `${((v-.5)*30).toFixed(1)} dB`;if(label==='Q')return (10*Math.pow(.03,v)).toFixed(2);if(label==='PAN')return Math.abs(v-.5)<.01?'CENTER':v<.5?`L ${Math.round((.5-v)*200)}%`:`R ${Math.round((v-.5)*200)}%`;if(label==='SEND LEVEL')return `${db(v)} dB`;if(label==='Threshold')return `${Math.round(-80+80*v)} dB`;return String(v.toFixed(2));}
  function refreshInspectorValues(){
    document.querySelectorAll('#remoteInspector .control-row').forEach(el=>{
      const p=el.dataset.path;const v=remote.values[p];if(!isNumeric(v))return;
      const input=el.querySelector('input');if(input===document.activeElement)return;
      input.value=String(Math.round(clamp(v)*1000));
      el.querySelector('output').textContent=fmtRemote(input.dataset.format,v);
    });
    document.querySelectorAll('#remoteInspector .toggle').forEach(el=>el.classList.toggle('on',rv(el.dataset.toggle,0)===1));
  }
  function currentLocal(itemId) {return itemId==='file-master'?fileMaster:localTracks.find(t=>String(t.id)===itemId);}
  function localMasterItem(){return {id:'file-master',kind:'main',n:1,name:'MAIN L/R',fader:fileMaster.fader,mute:fileMaster.mute,solo:false};}
  function renderLocal() {
    $('#trackCount').textContent=`${localTracks.length} ترک`;
    $('#fileStrips').innerHTML=localTracks.length?localTracks.map(item=>stripHTML(item,'file')).join(''):'<div class="empty-state" dir="rtl">هنوز فایلی باز نشده. با «افزودن فایل از Files» شروع کن.<br /><small>فایل‌های طولانی و حجیم ممکن است در آیفون به حافظهٔ زیادی نیاز داشته باشند.</small></div>';
    $('#fileMaster').innerHTML=stripHTML(localMasterItem(),'file');
    $('#fileMaster .strip').dataset.id='file-master';
    const first=localTracks[0]; if (!localTracks.some(t=>t.id===fileSelected)) fileSelected=first?.id??null;
    updateLocalStripData();updateFileInspector();
    audioDuration=Math.max(0,...localTracks.map(t=>t.buffer.duration));
    updateTime();
  }
  function updateLocalStripData() {
    document.querySelectorAll('#fileStrips .strip,#fileMaster .strip').forEach(el=>{
      const item=el.dataset.id==='file-master'?localMasterItem():localTracks.find(t=>String(t.id)===el.dataset.id);
      if (item) updateVisualStrip(el,item,'file');
    });
  }
  function localEqDefaults() {return [
    {freq:100,gain:0,q:.8,type:'lowshelf'},
    {freq:450,gain:0,q:1,type:'peaking'},
    {freq:2500,gain:0,q:1,type:'peaking'},
    {freq:9000,gain:0,q:.8,type:'highshelf'}
  ];}
  function localRange(label,field,val,min,max,step,suffix) {
    return `<div class="control-row"><label><span>${label}</span><output>${Number(val).toFixed(step<1?1:0)}${suffix}</output></label><input type="range" data-local-field="${field}" min="${min}" max="${max}" step="${step}" value="${val}" /></div>`;
  }
  function updateFileInspector() {
    const t=localTracks.find(t=>t.id===fileSelected);
    if(!t){$('#fileInspector').innerHTML='<h3>ویرایش صدای فایل</h3><p class="small-message">یک فایل را اضافه و با SELECT انتخاب کن.</p>';return;}
    const tabs=[['eq','EQ · اکولایزر'],['dyn','COMPRESSOR'],['fx','FX SENDS'],['pan','PAN / INFO']];
    let html=`<div class="inspector-title"><h3>${escapeHTML(t.name)}</h3><span class="caption">میکس محلی · ${formatTime(t.buffer.duration)} · ${t.buffer.numberOfChannels===1?'Mono':'Stereo'}</span></div><div class="inspector-nav">${tabs.map(([id,label])=>`<button class="subtab ${id===fileTab?'active':''}" data-filetab="${id}">${label}</button>`).join('')}</div>`;
    if(fileTab==='eq'){
      html+=peQPanel('file')+`<div class="editor-grid">${t.eq.map((band,i)=>`<div class="editor-card"><strong>BAND ${i+1} · ${['LOW','LOW MID','HIGH MID','HIGH'][i]}</strong>${localRange('فرکانس',`eq.${i}.freq`,band.freq,20,18000,10,' Hz')}${localRange('گین',`eq.${i}.gain`,band.gain,-15,15,.5,' dB')}${i===1||i===2?localRange('Q',`eq.${i}.q`,band.q,.3,8,.1,''):''}</div>`).join('')}</div>`;
    } else if (fileTab==='fx') {
      html+=`<div class="editor-grid">${Array.from({length:FX_COUNT},(_,i)=>{
        const slot=i+1;return `<div class="editor-card"><strong>FX${slot} · DELAY</strong>${controlHTML('SEND LEVEL',slotSendPath(t.channel,slot),0,v=>`${db(v)} dB`)}</div>`;
      }).join('')}<div class="editor-card"><strong>تنظیم دیلی‌ها</strong><button class="primary" type="button" id="gotoFXfromFile">✨ FX RACK · ۸ دیلی</button></div></div>`;

    } else if(fileTab==='dyn'){
      html+=`<div class="editor-grid"><div class="editor-card"><strong>COMPRESSOR (روی صدای فایل)</strong><div class="toggle-row"><span>کمپرسور فعال</span><button class="toggle ${t.comp.on?'on':''}" type="button" data-local-toggle="comp.on"></button></div>${localRange('Threshold',`comp.threshold`,t.comp.threshold,-60,0,1,' dB')}${localRange('Ratio',`comp.ratio`,t.comp.ratio,1,12,.5,':1')}</div><div class="editor-card"><strong>مشخصات پردازش</strong><p class="small-message">پردازش صوت فایل با فیلترهای Web Audio و کمپرسور مرورگر انجام می‌شود و الزاماً الگوریتم داخلی کمپرسور MIDAS نیست.</p></div></div>`;
    } else {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>STEREO POSITION</strong>${localRange('Pan',`pan`,t.pan,-1,1,.01,'')}</div><div class="editor-card"><strong>فایل انتخاب‌شده</strong><p class="small-message" dir="ltr" style="text-align:left">${escapeHTML(t.name)}<br>${(t.size/1048576).toFixed(1)} MB · ${Math.round(t.buffer.sampleRate)} Hz<br>${t.buffer.numberOfChannels} channel(s)</p><button class="soft danger" type="button" data-delete-track="${t.id}">حذف این ترک</button></div></div>`;
    }
    $('#fileInspector').innerHTML=html;
    if(fileTab==='eq')requestAnimationFrame(()=>drawPEQ('file'));
  }

  // Eight independent Web Audio stereo delay processors. The same graph is
  // constructed in real-time playback and in OfflineAudioContext WAV export.
  function buildFX(ctx,mainBus){
    const slots=[];
    for(let i=1;i<=FX_COUNT;i++){
      const p=fxRack[fxId(i)];
      const input=ctx.createGain();
      const left=ctx.createDelay(2.05),right=ctx.createDelay(2.05);
      left.delayTime.value=p.time/1000;right.delayTime.value=p.time/1000;
      const lpan=ctx.createStereoPanner(),rpan=ctx.createStereoPanner();
      lpan.pan.value=p.pingpong?-.9:0;rpan.pan.value=p.pingpong?.9:0;
      const fbL=ctx.createGain(),fbR=ctx.createGain();
      fbL.gain.value=p.feedback;fbR.gain.value=p.feedback;
      const tap3=ctx.createDelay(6.05);tap3.delayTime.value=3*p.time/1000;
      const tap3Gain=ctx.createGain();tap3Gain.gain.value=p.triple?.28:0;
      const out=ctx.createGain();out.gain.value=p.on&&p.toMain?p.level:0;
      input.connect(left);left.connect(lpan);lpan.connect(out);
      left.connect(fbL);fbL.connect(right);right.connect(rpan);rpan.connect(out);
      right.connect(fbR);fbR.connect(left);
      input.connect(tap3);tap3.connect(tap3Gain);tap3Gain.connect(out);
      out.connect(mainBus);
      slots.push({input,left,right,lpan,rpan,fbL,fbR,tap3,tap3Gain,out});
    }
    return {slots,ctx};
  }
  function updateFXGraph(){
    if(!playback||!audioContext)return;
    const when=audioContext.currentTime;
    playback.fxGraph.slots.forEach((slot,index)=>{
      const p=fxRack[fxId(index+1)];
      const set=(param,val)=>param.setTargetAtTime(val,when,.025);
      set(slot.out.gain,p.on&&p.toMain?p.level:0);
      set(slot.left.delayTime,p.time/1000);set(slot.right.delayTime,p.time/1000);
      set(slot.tap3.delayTime,p.time*3/1000);
      set(slot.fbL.gain,p.feedback);set(slot.fbR.gain,p.feedback);
      set(slot.lpan.pan,p.pingpong?-.9:0);set(slot.rpan.pan,p.pingpong?.9:0);
      set(slot.tap3Gain.gain,p.triple?.28:0);
    });
  }

  function fxControl(key,property,title,min,max,step,unit){
    const v=fxRack[key][property];
    const display=unit==='s'?(v/1000).toFixed(2)+' s':typeof v==='number'?(Number(v).toFixed(step>=1?0:2)+' '+unit):v;
    return `<div class="control-row"><label><span>${title}</span><output>${display}</output></label><input type="range" min="${min}" max="${max}" step="${step}" value="${v}" data-fx-key="${key}" data-fx-prop="${property}" data-fx-unit="${unit}" /></div>`;
  }
  function fxToggle(key,property,label){const val=fxRack[key][property];return `<div class="toggle-row"><span>${label}</span><button class="toggle ${val?'on':''}" type="button" data-fx-toggle="${key}.${property}" aria-pressed="${val}"></button></div>`;}
  function renderFX(){
    const rack=$('#fxControls');if(!rack)return;
    rack.innerHTML=Array.from({length:FX_COUNT},(_,i)=>{
      const n=i+1,k=fxId(n),v=fxRack[k];
      return `<div class="fx-card"><div class="fx-card-head"><h3>FX${n} · DELAY</h3><span>⏱️</span></div>
        <span class="caption">${n<=4?'BUS '+(12+n):'VIRTUAL SEND '+n} · ${v.pingpong?'PING PONG':v.triple?'TRIPLE TAP':'STEREO ECHO'}</span>
        ${fxToggle(k,'on','دیلی روشن')}${fxToggle(k,'toMain','ارسال خروجی افکت به MAIN L/R')}
        ${fxToggle(k,'pingpong','Ping Pong · چپ / راست')}${fxToggle(k,'triple','Triple Tap · تکرار سوم')}
        ${fxControl(k,'time','Delay Time · زمان تکرار',1,2000,1,'ms')}
        ${fxControl(k,'feedback','Feedback · بازخورد',0,.75,.01,'')}
        ${fxControl(k,'level','FX RETURN · حجم دیلی',0,1,.01,'')}
        <p class="fx-explain">زمان دیلی تا ۲۰۰۰ میلی‌ثانیه. تغییرات هنگام پخش و خروجی WAV اعمال می‌شوند.</p>
      </div>`;
    }).join('');
    const dropdown=$('#fxChannelSelect');const selected=Number(dropdown?.value)||fxChannel;
    dropdown.innerHTML=Array.from({length:32},(_,i)=>{const n=i+1,t=trackAtChannel(n);return `<option value="${n}">${ch2(n)} · ${t?escapeHTML(t.name):'CH '+ch2(n)}</option>`;}).join('');
    fxChannel=Math.min(32,Math.max(1,selected));dropdown.value=String(fxChannel);
    renderFXSends();
    $('#fxAudioStatus').textContent=localTracks.length?`${localTracks.length} فایل/ترک وارد شده · ${formatTime(audioDuration)}`:'هنوز فایلی وارد نشده';
  }
  function renderFXSends(){
    const el=$('#fxSendControls');if(!el)return;
    el.innerHTML=Array.from({length:FX_COUNT},(_,i)=>{
      const slot=i+1,path=slotSendPath(fxChannel,slot),v=rv(path,0);
      return `<div class="editor-card"><strong>FX${slot} → DELAY · ${slot<=4?'BUS '+(12+slot):'VIRTUAL'}</strong>${controlHTML('SEND LEVEL',path,0,val=>`${db(val)} dB`)}<div class="fx-explain">${v===0?'ارسال این کانال خاموش است':`ارسال: ${db(v)} dB`}</div></div>`;
    }).join('');
  }
  function applyPreset(name){
    fxRack=fxDefaults();
    const p=fxRack;
    if(name==='vocal'){p.fx1.time=220;p.fx1.feedback=.20;p.fx1.level=.24;}
    else if(name==='hall'){p.fx1.time=680;p.fx1.feedback=.42;p.fx1.level=.30;}
    else if(name==='pingpong'){p.fx2.time=440;p.fx2.pingpong=true;p.fx2.feedback=.47;}
    else if(name==='triple'){p.fx3.time=360;p.fx3.triple=true;p.fx3.feedback=.35;}
    else if(name==='dry'){Object.values(p).forEach(fx=>fx.on=false);}
    else return;
    if(name!=='dry'){
      const slot=name==='pingpong'?2:name==='triple'?3:1;
      remoteSet(slotSendPath(fxChannel,slot),.75);
    }
    saveFX();updateFXGraph();updateGraph();renderFX();notify('تنظیم آماده دیلی اعمال شد.');
  }

  function initFXEvents(){
    $('#fxTab').onclick=()=>{activateMode('fx');renderFX();};
    $('#openFX').onclick=()=>{activateMode('fx');renderFX();};
    $('#fileFxButton').onclick=()=>{fxChannel=localTracks.find(t=>t.id===fileSelected)?.channel||1;activateMode('fx');renderFX();};
    $('#backToMixer').onclick=()=>activateMode('remote');
    $('#fxPlayButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#fxStopButton').onclick=()=>haltPlayback(true);
    $('#fxExportButton').onclick=exportMix;
    $('#fxAudioPicker').onchange=e=>loadFiles(e.target.files);
    $('#fxChannelSelect').onchange=e=>{fxChannel=+e.target.value;renderFXSends();};
    $('#fxSection').addEventListener('click',e=>{
      const preset=e.target.closest('[data-fx-preset]');if(preset){applyPreset(preset.dataset.fxPreset);return;}
      const tog=e.target.closest('[data-fx-toggle]');if(tog){const [k,property]=tog.dataset.fxToggle.split('.');fxRack[k][property]=!fxRack[k][property];saveFX();updateFXGraph();renderFX();return;}
    });
    $('#fxSection').addEventListener('change',e=>{if(e.target.matches('[data-fx-key]'))updateFXGraph(true);});
    $('#fxSection').addEventListener('input',e=>{
      const input=e.target.closest('[data-fx-key]');
      if(input){const key=input.dataset.fxKey,prop=input.dataset.fxProp,val=Number(input.value);fxRack[key][prop]=val;
        input.closest('.control-row').querySelector('output').textContent=prop==='time'?(val/1000).toFixed(2)+' s':(val.toFixed(Number(input.step)>=1?0:2)+' '+input.dataset.fxUnit);
        saveFX();updateFXGraph();return;}
      const send=e.target.closest('#fxSendControls .remote-input');if(send){const val=+send.value/1000;send.closest('.control-row').querySelector('output').textContent=`${db(val)} dB`;remoteSet(send.dataset.path,val);}
    });
  }

  function formatTime(seconds) {seconds=Math.floor(Math.max(0,seconds)||0);return `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;}
  function getOffset() {return playback ? clamp(playOffset + (audioContext.currentTime-playback.started),0,audioDuration) : playOffset;}
  function updateTime(){const offset=getOffset();$('#timeLabel').textContent=`${formatTime(offset)} / ${formatTime(audioDuration)}`;if(!lastScrub)$('#positionSlider').value=String(audioDuration?Math.round(offset/audioDuration*1000):0);}
  function createTrackAudio(ctx,t,target,fx,startingOffset) {
    if(t.buffer.duration<=startingOffset)return null;
    const source=ctx.createBufferSource();source.buffer=t.buffer;
    let node=source;
    const analyser=ctx.createAnalyser();analyser.fftSize=512;node.connect(analyser);node=analyser;
    const filters=[];
    t.eq.forEach(b=>{const filter=ctx.createBiquadFilter();filter.type=b.type;filter.frequency.value=b.freq;filter.gain.value=t.eqOn===false?0:b.gain;filter.Q.value=b.q;node.connect(filter);node=filter;filters.push(filter);});
    const compressor=ctx.createDynamicsCompressor();compressor.threshold.value=t.comp.on?t.comp.threshold:0;compressor.ratio.value=t.comp.on?t.comp.ratio:1;compressor.knee.value=6;compressor.attack.value=.012;compressor.release.value=.2;
    node.connect(compressor);node=compressor;
    const vol=ctx.createGain();vol.gain.value=trackAudible(t)?gain(t.fader):0;node.connect(vol);node=vol;
    const pan=ctx.createStereoPanner();pan.pan.value=t.pan;node.connect(pan);pan.connect(target);
    // FX sends follow fader/mute. Each FX return is shared between all 32 channel strips.
    const fxSends=fx.slots.map((slot,index)=>{
      const send=ctx.createGain();send.gain.value=gain(rv(slotSendPath(t.channel,index+1),0));
      vol.connect(send);send.connect(slot.input);return send;
    });

    source.start(0,startingOffset);
    return {source,analyser,filters,compressor,vol,pan,fxSends,track:t};
  }
  function trackAudible(t){return !t.mute&&(!localTracks.some(x=>x.solo)||t.solo);}
  function makeGraph(ctx,offset){
    const out=ctx.createGain();out.gain.value=fileMaster.mute?0:gain(fileMaster.fader);
    const limiter=ctx.createDynamicsCompressor();limiter.threshold.value=-2;limiter.ratio.value=12;limiter.knee.value=0;limiter.attack.value=.002;limiter.release.value=.08;
    let geqInput=out;
    const geqNodes=geqFreqs.map((freq,i)=>{
      const filter=ctx.createBiquadFilter();filter.type='peaking';filter.frequency.value=Math.min(freq,ctx.sampleRate*.44);filter.Q.value=4.3;filter.gain.value=geqGains[i];
      geqInput.connect(filter);geqInput=filter;return filter;
    });
    geqInput.connect(limiter);
    const spectrum=ctx.createAnalyser();spectrum.fftSize=2048;spectrum.smoothingTimeConstant=.72;
    limiter.connect(spectrum);spectrum.connect(ctx.destination);
    const fxGraph=buildFX(ctx,out);
    const nodes=localTracks.map(t=>createTrackAudio(ctx,t,out,fxGraph,offset)).filter(Boolean);
    return {nodes,out,limiter,fxGraph,geqNodes,spectrum};
  }
  function updateGraph() {
    if (!playback||!audioContext) return;
    const when=audioContext.currentTime;
    playback.out.gain.setTargetAtTime(fileMaster.mute?0:gain(fileMaster.fader),when,.012);
    playback.geqNodes.forEach((f,i)=>f.gain.setTargetAtTime(geqGains[i],when,.02));
    for (const g of playback.nodes) {
      const t=g.track;
      g.vol.gain.setTargetAtTime(trackAudible(t)?gain(t.fader):0,when,.01);
      g.pan.pan.setTargetAtTime(t.pan,when,.01);
      g.filters.forEach((f,i)=>{const eq=t.eq[i];f.frequency.setTargetAtTime(eq.freq,when,.01);f.gain.setTargetAtTime(t.eqOn===false?0:eq.gain,when,.01);f.Q.setTargetAtTime(eq.q,when,.01);});
      g.compressor.threshold.setTargetAtTime(t.comp.on?t.comp.threshold:0,when,.02);
      g.compressor.ratio.setTargetAtTime(t.comp.on?t.comp.ratio:1,when,.02);
      g.fxSends.forEach((send,index)=>send.gain.setTargetAtTime(gain(rv(slotSendPath(t.channel,index+1),0)),when,.02));

    }
  }
  async function beginPlayback(){
    if(!localTracks.length){notify('ابتدا فایل صوتی اضافه کن.');return;}
    if(playback) return;
    if(playOffset>=audioDuration-.01)playOffset=0;
    try{
      audioContext ||= new (window.AudioContext||window.webkitAudioContext)();
      await audioContext.resume();
      const graph=makeGraph(audioContext,playOffset);
      playback={...graph,started:audioContext.currentTime};
      $('#playButton').textContent='⏸ مکث';$('#simPlayButton').textContent='⏸ مکث';$('#fxPlayButton').textContent='⏸ مکث';requestAnimationFrame(tick);
    }catch(e){notify('پخش آغاز نشد: '+e.message);}
  }
  function haltPlayback(reset=false){
    if(playback){
      const remaining=getOffset();
      playback.nodes.forEach(n=>{try{n.source.stop();}catch{}});
      playback.out.disconnect();playback.limiter.disconnect();playback.spectrum.disconnect();
      playback=null;
      playOffset=reset?0:remaining;
    } else if(reset)playOffset=0;
    $('#playButton').textContent='▶ پخش';$('#simPlayButton').textContent='▶ پخش';$('#fxPlayButton').textContent='▶ پخش و شنیدن';document.querySelectorAll('.meter-mini i').forEach(x=>x.classList.remove('lit'));updateTime();
  }
  function tick(){
    if(!playback)return;
    updateTime();
    for(const node of playback.nodes){
      const buffer=new Float32Array(node.analyser.fftSize);node.analyser.getFloatTimeDomainData(buffer);
      let power=0;for(let i=0;i<buffer.length;i++)power+=buffer[i]*buffer[i];
      const rms=Math.sqrt(power/buffer.length),t=node.track;
      const magnitude=trackAudible(t)?clamp((20*Math.log10(Math.max(1e-5,rms))+65)/60):0;
      for(const el of document.querySelectorAll(`.strip[data-id="ch-${t.channel}"],.strip[data-id="${t.id}"]`)){
        el.querySelectorAll('.meter-mini i').forEach((bar,i)=>bar.classList.toggle('lit',i<Math.round(magnitude*9)));
      }
    }
    if(proCurrent==='rta')renderRTAChart();
    if(getOffset()>=audioDuration-.04){haltPlayback(true);return;}requestAnimationFrame(tick);
  }
  async function loadFiles(fileList) {
    const files=Array.from(fileList||[]);if(!files.length)return;
    if(playback)haltPlayback(true);
    notify('فایل‌ها در حال باز شدن‌اند…',10000);
    try{
      audioContext||=new (window.AudioContext||window.webkitAudioContext)();
      let added=0;
      for(const file of files){
        if(localTracks.length>=32){notify('حداکثر ۳۲ فایل در کانال‌های CH پشتیبانی می‌شود.');break;}
        try{
          const bytes=await file.arrayBuffer();const buffer=await audioContext.decodeAudioData(bytes.slice(0));
          const taken=new Set(localTracks.map(t=>t.channel));let assigned=1;while(taken.has(assigned))assigned++;
          const t={id:++trackId,channel:assigned,name:file.name,fader:.75,mute:false,solo:false,pan:0,eq:localEqDefaults(),eqOn:true,comp:{on:false,threshold:-24,ratio:3},buffer,size:file.size};localTracks.push(t);applySimToTrack(t);added++;
        } catch(err){notify(`فایل «${file.name}» باز نشد؛ احتمالاً فرمت توسط مرورگر پشتیبانی نمی‌شود.`,5500);}
      }
      renderLocal();makeStrips();renderFX(); if(added)notify(`${added} فایل با موفقیت وارد میز میکس شد.`);
    }catch(err){notify('خطا هنگام باز کردن فایل: '+err.message);}
    $('#audioPicker').value='';$('#simAudioPicker').value='';
  }
  function toWAV(buffer){
    const chs=2,len=buffer.length;
    const output=new ArrayBuffer(44+len*chs*2),view=new DataView(output);
    const write=(off,s)=>{for(let i=0;i<s.length;i++)view.setUint8(off+i,s.charCodeAt(i));};
    write(0,'RIFF');view.setUint32(4,36+len*4,true);write(8,'WAVE');write(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,chs,true);view.setUint32(24,buffer.sampleRate,true);view.setUint32(28,buffer.sampleRate*chs*2,true);view.setUint16(32,chs*2,true);view.setUint16(34,16,true);write(36,'data');view.setUint32(40,len*chs*2,true);
    const a=buffer.getChannelData(0),b=buffer.getChannelData(1);let offset=44;
    for(let i=0;i<len;i++){for(const v of [a[i],b[i]]){let sample=clamp(v,-1,1);view.setInt16(offset,sample<0?sample*0x8000:sample*0x7fff,true);offset+=2;}}
    return new Blob([output],{type:'audio/wav'});
  }
  async function exportMix() {
    if(!localTracks.length){notify('ابتدا فایل اضافه کن.');return;}
    if(audioDuration>300 && !confirm('خروجی WAV طولانی می‌تواند حافظه زیادی مصرف کند. ادامه می‌دهی؟'))return;
    if(audioDuration>1800){notify('برای خروجی بیشتر از ۳۰ دقیقه، از DAW کامپیوتر استفاده کن.');return;}
    const button=$('#exportButton'),fxButton=$('#fxExportButton');button.disabled=true;fxButton.disabled=true;
    button.textContent='در حال ساخت WAV…';fxButton.textContent='در حال ساخت WAV…';
    try {
      const rate=44100; const tail=Math.min(16,Math.max(.3,...Object.values(fxRack).map(fx=>fx.on&&fx.toMain&&fx.feedback>0?fx.time/1000*(1+Math.ceil(Math.log(.025)/Math.log(Math.max(.01,fx.feedback)))):fx.on?fx.time/1000:0)));
      const ctx=new OfflineAudioContext(2,Math.ceil((audioDuration+tail)*rate),rate);
      makeGraph(ctx,0);
      const result=await ctx.startRendering();
      const blob=toWAV(result);
      if (window.M32_ANDROID && window.AndroidBridge) {
        const started=window.AndroidBridge.beginWav('M32-LiveStudio-Mix.wav');
        if (!started.startsWith('OK')) throw Error(started);
        try {
          const bytes=new Uint8Array(await blob.arrayBuffer());
          const chunkSize=24*1024;
          for(let pos=0;pos<bytes.length;pos+=chunkSize) {
            const chunk=bytes.subarray(pos,Math.min(pos+chunkSize,bytes.length));
            let binary='';for(let j=0;j<chunk.length;j++)binary+=String.fromCharCode(chunk[j]);
            const status=window.AndroidBridge.appendWavChunk(btoa(binary));
            if(status!=='OK')throw Error(status);
          }
          const saved=window.AndroidBridge.finishWav();
          if(!saved.startsWith('OK:'))throw Error(saved);
          notify('فایل WAV در '+saved.slice(4)+' ذخیره شد.',6500);
        } catch(e) {window.AndroidBridge.cancelWav();throw e;}
      } else {
        const objectURL=URL.createObjectURL(blob);
        const link=document.createElement('a');link.href=objectURL;link.download='M32-LiveStudio-Mix.wav';document.body.append(link);link.click();link.remove();
        setTimeout(()=>URL.revokeObjectURL(objectURL),60000);
        notify('میکس استریوی WAV ساخته شد. فایل را در Downloads / Files ذخیره کن.');
      }
    } catch(error){notify('خروجی ساخته نشد: '+error.message,6000);}
    finally {button.disabled=false;fxButton.disabled=false;button.textContent='↓ خروجی WAV با افکت‌ها';fxButton.textContent='↓ خروجی WAV با FX';}
  }
  function updateFaderVisual(strip,level){
    const f=strip.querySelector('.fader-container');f.style.setProperty('--level',level);f.style.setProperty('--knob',`${(level*165).toFixed(2)}px`);f.setAttribute('aria-valuenow',String(Math.round(level*100)));
    strip.querySelector('.db-number').textContent=`${db(level)} dB`;
  }
  const throttle=new Map();
  function editStripFader(strip,level) {
    level=clamp(Math.round(level*1023)/1023);
    updateFaderVisual(strip,level);
    const itemId=strip.dataset.id;
    if (strip.dataset.mode==='remote') {
      const [kind,n]=itemId.split('-');const item={kind,n:Number(n)};
      const path=simFaderPath(item);remote.values[path]=level;
      syncAudioFromSim(path,level);persistScene();
      const prev=throttle.get(path)||0;
      if(performance.now()-prev>38){throttle.set(path,performance.now());setRemoteFader(item,level);}
    } else {
      if(itemId==='file-master'){fileMaster.fader=level;remoteSet('/main/st/mix/fader',level);updateRemoteStripData();}
      else {const item=currentLocal(itemId);if(item){item.fader=level;pushTrackToSim(item);}}
      updateGraph();
    }
  }
  function attachFaderPointers(container){
    container.addEventListener('pointerdown',e=>{
      const f=e.target.closest('.fader-container');if(!f||!container.contains(f))return;
      if(e.button!==0)return;
      e.preventDefault();f.setPointerCapture(e.pointerId);f.dataset.dragging='1';
      const update=clientY=>{const r=f.getBoundingClientRect();const raw=clamp((r.bottom-clientY-14)/(r.height-28));editStripFader(f.closest('.strip'),raw);};
      f._faderMove=event=>update(event.clientY);update(e.clientY);
    });
    container.addEventListener('pointermove',e=>{const f=e.target.closest('.fader-container');if(f?.hasPointerCapture(e.pointerId))f._faderMove?.(e);});
    const end=e=>{
      const f=e.target.closest('.fader-container');if(!f||!f.hasPointerCapture(e.pointerId))return;
      delete f.dataset.dragging;
      const strip=f.closest('.strip');
      if(strip.dataset.mode==='remote'&&remote.connected){const [kind,n]=strip.dataset.id.split('-');setRemoteFader({kind,n:Number(n)},Number((f.style.getPropertyValue('--level')||'.75').trim()));}
    };
    container.addEventListener('pointerup',end);container.addEventListener('pointercancel',end);
    container.addEventListener('keydown',e=>{
      const f=e.target.closest('.fader-container');if(!f)return;
      if(!['ArrowUp','ArrowDown','Home','End'].includes(e.key))return;e.preventDefault();
      const old=Number(f.style.getPropertyValue('--level'))||0;
      const updated=e.key==='Home'?0:e.key==='End'?1:old+(e.key==='ArrowUp'?.01:-.01);
      editStripFader(f.closest('.strip'),updated);
    });
  }
  function stripAction(event){
    const btn=event.target.closest('[data-action]');if(!btn||btn.dataset.action==='fader')return;
    const el=btn.closest('.strip');if(!el)return;
    const action=btn.dataset.action;
    if(el.dataset.mode==='remote'){
      const [kind,n]=el.dataset.id.split('-');const item={kind,n:Number(n)};
      if(action==='select'){selectRemote(item);return;}
      if(action==='mute'){const p=pathFor(item,'on');const next=remote.values[p]===0?1:0;btn.classList.toggle('active',next===0);remoteSet(p,next);}
      if(action==='solo'){const p=soloPath(item);if(!p)return;const next=remote.values[p]?0:1;btn.classList.toggle('active',next===1);remoteSet(p,next);}
    }else{
      const t=currentLocal(el.dataset.id);if(!t)return;
      if(action==='select'){if(el.dataset.id==='file-master')return;fileSelected=t.id;fileTab='eq';updateLocalStripData();updateFileInspector();}
      if(action==='mute'){if(el.dataset.id==='file-master'){fileMaster.mute=!fileMaster.mute;remoteSet('/main/st/mix/on',fileMaster.mute?0:1);}else {t.mute=!t.mute;pushTrackToSim(t);}updateLocalStripData();updateGraph();}
      if(action==='solo'&&el.dataset.id!=='file-master'){t.solo=!t.solo;pushTrackToSim(t);updateLocalStripData();updateGraph();}
    }
  }
  function activateMode(mode) {
    activeMode=mode;$('#proWorkspace').classList.add('hidden');
    document.querySelectorAll('.mode').forEach(el=>{const active=el.dataset.mode===mode;el.classList.toggle('active',active);el.setAttribute('aria-selected',String(active));});
    $('#remoteSection').classList.toggle('hidden',mode!=='remote');$('#fileSection').classList.toggle('hidden',mode!=='file');$('#fxSection').classList.toggle('hidden',mode!=='fx');
    if(mode==='fx'){renderFX();window.scrollTo({top:0,behavior:'smooth'});}
  }
  function initEvents(){
    $('#remoteTab').onclick=()=>activateMode('remote');$('#fileTab').onclick=()=>activateMode('file');initFXEvents();
    $('#bankbar').addEventListener('click',e=>{const b=e.target.closest('[data-bank]');if(!b)return;remote.bank=b.dataset.bank;makeStrips();});
    for(const container of [$('#remoteStrips'),$('#remoteMaster'),$('#fileStrips'),$('#fileMaster')]){container.addEventListener('click',stripAction);attachFaderPointers(container);}
    $('#remoteInspector').addEventListener('click',async e=>{
      if(e.target.closest('#gotoFXfromInspector')){fxChannel=remote.selected.n;activateMode('fx');return;}
      const tab=e.target.closest('[data-remotetab]');if(tab){remote.tab=tab.dataset.remotetab;updateRemoteInspector();return;}
      const togg=e.target.closest('[data-toggle]');if(togg){const p=togg.dataset.toggle;const next=rv(p,0)===1?0:1;await remoteSet(p,next);togg.classList.toggle('on',next===1);return;}
      if(e.target.closest('#nameSave')){
        const p=`/ch/${ch2(remote.selected.n)}/config/name`;const val=$('#remoteChannelName').value.trim();
        if(val) {await remoteSet(p,val);updateRemoteStripData();}
      }
    });
    let sliderThrottle=new Map();
    $('#remoteInspector').addEventListener('input',e=>{
      const input=e.target.closest('.remote-input');if(!input)return;
      const val=Number(input.value)/1000;const path=input.dataset.path;
      input.closest('.control-row').querySelector('output').textContent=fmtRemote(input.dataset.format,val);
      remote.values[path]=val;
      if(path.includes('/eq/'))refreshPEQ('remote');
      const now=performance.now();if(now-(sliderThrottle.get(path)||0)>70){sliderThrottle.set(path,now);remoteSet(path,val);}
    });
    $('#remoteInspector').addEventListener('change',e=>{const inp=e.target.closest('.remote-input');if(inp)remoteSet(inp.dataset.path,Number(inp.value)/1000);});
    $('#fileInspector').addEventListener('click',e=>{
      const tab=e.target.closest('[data-filetab]');if(tab){fileTab=tab.dataset.filetab;updateFileInspector();return;}
      const tog=e.target.closest('[data-local-toggle]');const t=localTracks.find(x=>x.id===fileSelected);
      if(tog&&t){t.comp.on=!t.comp.on;tog.classList.toggle('on',t.comp.on);updateGraph();pushTrackToSim(t);}
      if(e.target.closest('#gotoFXfromFile')){fxChannel=t?.channel||1;activateMode('fx');return;}
      const del=e.target.closest('[data-delete-track]');if(del){haltPlayback(true);localTracks=localTracks.filter(x=>x.id!==Number(del.dataset.deleteTrack));renderLocal();}
    });
    $('#fileInspector').addEventListener('input',e=>{
      const fxinput=e.target.closest('.remote-input');if(fxinput){const v=Number(fxinput.value)/1000;fxinput.closest('.control-row').querySelector('output').textContent=`${db(v)} dB`;remoteSet(fxinput.dataset.path,v);return;}
      const input=e.target.closest('[data-local-field]');if(!input)return;
      const t=localTracks.find(x=>x.id===fileSelected);if(!t)return;
      const f=input.dataset.localField,v=Number(input.value);
      if(f.startsWith('eq.')){const [,index,key]=f.split('.');t.eq[Number(index)][key]=v;}
      else if(f.startsWith('comp.'))t.comp[f.split('.')[1]]=v;
      else if(f==='pan')t.pan=v;
      input.closest('.control-row').querySelector('output').textContent=v.toFixed(Number(input.step)<1?1:0)+(f==='pan'?'':f.includes('freq')?' Hz':f.includes('gain')||f.includes('threshold')?' dB':f.includes('ratio')?':1':'');
      updateGraph();pushTrackToSim(t);
      if(f.startsWith('eq.'))refreshPEQ('file');
    });
    $('#helpButton').onclick=()=>$('#helpDialog').showModal();
    $('#simAudioPicker').onchange=e=>loadFiles(e.target.files);
    $('#demoButton').onclick=makeDemo;
    $('#simPlayButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#simStopButton').onclick=()=>haltPlayback(true);
    sceneButtons();
    $('#audioPicker').onchange=e=>loadFiles(e.target.files);
    $('#playButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#stopButton').onclick=()=>haltPlayback(true);
    $('#positionSlider').addEventListener('pointerdown',()=>lastScrub=true);
    $('#positionSlider').addEventListener('change',e=>{const wasPlaying=Boolean(playback);haltPlayback(false);playOffset=(Number(e.target.value)/1000)*audioDuration;lastScrub=false;updateTime();if(wasPlaying)beginPlayback();});
    $('#positionSlider').addEventListener('pointerup',()=>{lastScrub=false;});
    $('#exportButton').onclick=exportMix;
    $('#clearButton').onclick=()=>{if(!localTracks.length)return;if(confirm('تمام فایل‌های بارگذاری‌شده از پروژه فعلی حذف شوند؟')){haltPlayback(true);localTracks=[];renderLocal();}};
  }
  // ---------------------------------------------------------------------------
  // Pro surface: fourteen screens with 8 delay FX slots + main GEQ.
  // Matrix, non-FX routing and DCA remain training-only in v0.6.
  // ---------------------------------------------------------------------------
  const proPages=[
    ['mixer','01','میکسر','MIXER'],['channel','02','کانال و EQ','CHANNEL'],
    ['dynamics','03','داینامیک','DYNAMICS'],['sends','04','ارسال‌ها','SENDS'],
    ['geq','05','اکولایزر ۳۱ باند','GEQ'],['fx','06','رک افکت','FX RACK'],
    ['fxreturns','07','بازگشت افکت','FX RETURNS'],['matrix','08','ماتریکس','MATRIX'],
    ['routing','09','مسیریابی','ROUTING'],['player','10','پخش فایل','PLAYER'],
    ['scenes','11','صحنه‌ها','SCENES'],['setup','12','تنظیمات','SETUP'],
    ['rta','13','آنالایزر','RTA'],['export','14','خروجی WAV','EXPORT']
  ];
  const geqOther={};
  const trainingOutputs=['main',...Array.from({length:16},(_,i)=>`bus${i+1}`),...Array.from({length:6},(_,i)=>`matrix${i+1}`)];
  const outLabel=id=>id==='main'?'MAIN L/R':id.startsWith('bus')?`BUS ${ch2(Number(id.slice(3)))}`:`MATRIX ${Number(id.slice(6))}`;
  const proCard=(heading,body,mini='')=>`<article class="pro-card"><div class="pro-card-top"><h3>${heading}</h3>${mini?`<span class="pro-badge">${mini}</span>`:''}</div>${body}</article>`;
  const fieldSlider=(key,label,value,min,max,step,unit='')=>`<label class="pro-slider"><span>${label} <output>${Number(value).toFixed(step>=1?0:1)}${unit}</output></span><input data-pro-slider="${key}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"></label>`;
  const banner=(label,text)=>`<div class="pro-banner"><strong>${label}</strong><span>${text}</span></div>`;
  function updateNav(){
    document.querySelectorAll('#proNav [data-pro-page]').forEach(b=>b.classList.toggle('selected',b.dataset.proPage===proCurrent));
  }
  function showProPage(id){
    proCurrent=id;
    updateNav();
    const inspectorModes={mixer:['remote',null],channel:['remote','eq'],dynamics:['remote','dyn'],sends:['remote','send'],fx:['fx',null],player:['file',null]};
    if(inspectorModes[id]){
      const [mode,tab]=inspectorModes[id];
      if(mode==='remote'&&tab){remote.selected.kind='ch';remote.tab=tab;remote.bank='ch1';makeStrips();updateRemoteInspector();}
      activateMode(mode);
    }else{
      activeMode='pro';
      for(const section of ['remoteSection','fileSection','fxSection'])$('#'+section).classList.add('hidden');
      $('#proWorkspace').classList.remove('hidden');
      renderPro();
    }
    // Keep navigation in view when selecting from the 14-page menu.
    $('#proNav').scrollIntoView({block:'start',behavior:'instant'});
  }
  function proGains(){return selectedOutput==='main'?geqGains:(geqOther[selectedOutput]||=Array(31).fill(0));}
  const freqCaption=f=>f>=1000?(f/1000).toString().replace('.5','.5')+'k':String(f);
  function renderGEQPlot(){
    const canvas=$('#geqPlot');if(!canvas)return;
    const dpi=window.devicePixelRatio||1,w=Math.max(200,canvas.clientWidth),h=170;
    canvas.width=Math.round(w*dpi);canvas.height=Math.round(h*dpi);
    const c=canvas.getContext('2d');c.scale(dpi,dpi);c.clearRect(0,0,w,h);
    const mid=h/2,padding=13;
    c.strokeStyle='#26394b';c.lineWidth=1;
    for(let i=-12;i<=12;i+=3){let y=mid-i*5.1;c.beginPath();c.moveTo(10,y);c.lineTo(w-10,y);c.stroke();}
    for(let i=0;i<=10;i++){let x=padding+(w-padding*2)*i/10;c.beginPath();c.moveTo(x,6);c.lineTo(x,h-6);c.stroke();}
    const curve=proGains(),points=[];
    for(let t=0;t<500;t++){
      const f=20*Math.pow(1000,t/499);let dbSum=0;
      for(let k=0;k<31;k++){
        const d=Math.log2(f/geqFreqs[k]);dbSum+=curve[k]*Math.exp(-.5*(d/.20)**2);
      }
      points.push([padding+(w-2*padding)*t/499,mid-Math.max(-14,Math.min(14,dbSum))*5.1]);
    }
    c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.strokeStyle='#f7ba58';c.lineWidth=3;c.stroke();
    c.font='10px monospace';c.fillStyle='#a7b6ca';c.fillText('+12',4,22);c.fillText('0',4,mid-6);c.fillText('-12',4,h-16);
  }
  function renderRTAChart(){
    const canvas=$('#rtaCanvas');if(!canvas)return;
    const w=Math.max(200,canvas.clientWidth),h=235,dpi=window.devicePixelRatio||1;
    if(canvas.width!==Math.round(w*dpi)||canvas.height!==Math.round(h*dpi)){canvas.width=Math.round(w*dpi);canvas.height=Math.round(h*dpi);}
    const c=canvas.getContext('2d');c.setTransform(dpi,0,0,dpi,0,0);c.clearRect(0,0,w,h);
    for(let i=0;i<5;i++){c.strokeStyle='#25374a';c.beginPath();c.moveTo(6,13+i*48);c.lineTo(w-6,13+i*48);c.stroke();}
    if(!playback?.spectrum){c.fillStyle='#b7c9d8';c.font='14px sans-serif';c.textAlign='center';c.fillText('برای نمایش طیف فرکانسی، یک فایل صوتی پخش کن',w/2,h/2);return;}
    const n=playback.spectrum.frequencyBinCount,bytes=new Uint8Array(n);playback.spectrum.getByteFrequencyData(bytes);
    const steps=75,nyquist=audioContext.sampleRate/2,barW=(w-24)/steps;
    for(let i=0;i<steps;i++){
      const f=25*Math.pow(800,i/(steps-1)),index=Math.max(0,Math.min(n-1,Math.round(f/nyquist*n))),value=bytes[index]/255;
      const y=(h-29)*Math.pow(value,1.18);
      c.fillStyle=value>.8?'#f49e68':value>.54?'#f1c66f':'#46dbb6';
      c.fillRect(12+i*barW,h-20-y,Math.max(2,barW-1),y);
    }
    c.textAlign='left';c.fillStyle='#c1d5e0';c.font='12px monospace';['30','100','300','1k','3k','10k','20k'].forEach((f,i)=>c.fillText(f,12+(w-56)*i/6,h-2));
  }
  function renderPro(){
    const page=proPages.find(p=>p[0]===proCurrent)||proPages[0];
    $('#proTitle').textContent=`${page[2]} / ${page[3]}`;
    $('#proTag').textContent=['geq','fxreturns','rta','export'].includes(proCurrent)?'LIVE AUDIO ENGINE':'TRAINING / AUDIO';
    const el=$('#proContent');let content='';
    if(proCurrent==='geq'){
      const real=selectedOutput==='main',vals=proGains();
      content=`${banner(real?'✅ پردازش شنیداری فعال':'⚠️ نمایش و تمرین فقط',real?'این ۳۱ فیلتر روی MAIN L/R، هنگام پخش فایل و در خروجی WAV اعمال می‌شوند.':'برای BUS و MATRIX فعلاً تنظیمات قابل تمرین‌اند، اما روی فایل خروجی صوتی اعمال نمی‌شوند.')}
      <div class="pro-tools"><label>خروجی مورد نظر <select id="geqOutput">${trainingOutputs.map(o=>`<option value="${o}" ${o===selectedOutput?'selected':''}>${outLabel(o)}</option>`).join('')}</select></label>
      <button class="soft" data-pro-click="geq-flat">FLAT · صفرکردن</button><button class="soft" data-pro-click="geq-vocal">Speech Curve</button><button class="soft" data-pro-click="geq-dip">Room Trim</button></div>
      ${proCard('GRAPHIC EQ · RESPONSE CURVE','<canvas id="geqPlot" aria-label="نمودار پاسخ ۳۱ باند"></canvas>','31 BAND')}
      ${proCard('31 BAND EQUALIZER',`<div class="geq-scroll" dir="ltr"><div class="geq-bands">${vals.map((v,i)=>`<div class="geq-band"><output>${v>0?'+':''}${v.toFixed(0)}</output><input type="range" data-geq="${i}" aria-label="GEQ ${geqFreqs[i]} Hz" min="-12" max="12" step=".5" value="${v}" orient="vertical"><span>${freqCaption(geqFreqs[i])}</span></div>`).join('')}</div></div>`,'±12 dB')}`;
    } else if(proCurrent==='fxreturns'){
      content=banner('✅ هشت بازگشت دیلی واقعی','FX1 تا FX8 با کنترل حجم، MUTE و ارسال به MAIN L/R روی پخش و WAV اثر می‌گذارند.');
      content+=`<div class="pro-cards four">${Array.from({length:FX_COUNT},(_,i)=>{
        const id=fxId(i+1),fx=fxRack[id];
        return proCard(`FX${i+1} · DELAY`,`${fieldSlider('fx.'+id+'.level','FX Return Level',fx.level,0,1,.01)}<div class="pro-actions"><button data-pro-toggle="${id}.on" class="soft ${fx.on?'pro-on':''}">${fx.on?'ON':'MUTE'}</button><button data-pro-toggle="${id}.toMain" class="soft ${fx.toMain?'pro-on':''}">${fx.toMain?'→ MAIN L/R':'MAIN قطع'}</button></div>`,'DELAY');
      }).join('')}</div>`;

    } else if(proCurrent==='routing'){
      const ch=Math.max(1,Math.min(32,fxChannel));
      content=banner('۸ مسیر افکت شنیداری','FX1–FX4 از BUS13–16 و FX5–FX8 از Virtual Send مستقل می‌آیند. مسیرهای فیزیکی AES50/XLR در این شبیه‌ساز وجود ندارند.');
      content+=`<div class="pro-flow" dir="ltr"><span>CH ${ch2(ch)}</span><b>→</b><span>FX SEND 1–8</span><b>→</b><span>8 × DELAY</span><b>→</b><span>FX RETURN</span><b>→</b><span>MAIN L/R</span></div>
      <div class="pro-tools"><label>کانال مبدا <select id="proFXChannel">${Array.from({length:32},(_,i)=>`<option ${i+1===ch?'selected':''} value="${i+1}">CH ${ch2(i+1)}${trackAtChannel(i+1)?' · '+escapeHTML(trackAtChannel(i+1).name):''}</option>`).join('')}</select></label><button class="primary" data-pro-click="tofx">تنظیم دیلی‌ها</button></div>
      <div class="pro-cards four">${Array.from({length:8},(_,i)=>{
        const slot=i+1,v=rv(slotSendPath(ch,slot),0);
        return proCard(`FX${slot} → DELAY`,fieldSlider(`fxsend.${slot}`,`CH ${ch2(ch)} · ${slot<=4?'BUS '+(12+slot):'VIRTUAL'}`,v,0,1,.01),'SEND');
      }).join('')}</div>`;

    } else if(proCurrent==='matrix'){
      content=banner('⚠️ صفحه تمرینی (بدون پردازش ماتریکس)','در این نسخه فیدرهای ماتریکس و مسیرهای زیر برای آشنایی با ساختار M32R هستند. خروجی‌های فیزیکی مستقل یا متریکس صوتی واقعی ساخته نمی‌شوند.');
      content+=`<div class="pro-flow" dir="ltr"><span>MAIN L/R</span><b>→</b><span>MATRIX 1–6</span><b>→</b><span>SPEAKERS / ZONES</span></div><div class="pro-cards three">${Array.from({length:6},(_,i)=>{const n=i+1,v=trainingSettings.matrix[n]??.75;return proCard('MATRIX '+n,`${fieldSlider('matrix.'+n,'سطح تمرینی',v,0,1,.01)}<span class="pro-muted">فقط نمایش آموزشی</span>`,'TRAINING');}).join('')}</div>`;
    } else if(proCurrent==='scenes'){
      let sceneNames=[];try{sceneNames=Object.keys(JSON.parse(getStore('m32r_scenes')||'{}'));}catch{}
      content=banner('ذخیره Scene','فیدرها، EQ کانال‌ها، GEQ مستر، باس‌سندها و تنظیم‌های FX ذخیره می‌شوند. صدای فایل‌های بارگذاری‌شده در Scene ذخیره نمی‌شود.');
      content+=`<div class="pro-tools"><button class="primary" data-pro-click="save-scene">💾 ذخیره Scene</button><button class="soft" data-pro-click="load-scene">↺ بازیابی Scene</button><button class="soft" data-pro-click="reset-scene">شروع از صفر</button></div>${proCard('SCENE MEMORY',sceneNames.length?`<div class="scene-tags">${sceneNames.map(x=>`<span>${escapeHTML(x)}</span>`).join('')}</div>`:'<p class="pro-muted">هنوز Scene ذخیره‌شده‌ای نداری.</p>')}`;
    } else if(proCurrent==='setup'){
      content=proCard('SYSTEM / OFFLINE AUDIO',`<div class="pro-specs"><div><small>حالت</small><b>OFFLINE · LOCAL</b></div><div><small>Audio Input</small><b>FILES ON DEVICE</b></div><div><small>Mixdown</small><b>44.1 kHz · 16-bit WAV</b></div><div><small>Connection</small><b>NO MIXER / NO NETWORK</b></div><div><small>GEQ</small><b>MAIN 31-BAND</b></div><div><small>Active FX</small><b>8 × DELAY / 2000 ms</b></div></div>`,'DEVICE INFO');
      content+=banner('کار با گوشی','برای تمرین با فیدرهای بیشتر، گوشی را افقی بگیر. برنامه پس از نصب، بدون اینترنت به میکسر مجازی دسترسی می‌دهد.');
    } else if(proCurrent==='rta'){
      content=banner('RTA LIVE','نمایش طیف صدای میکس‌شده از خروجی برنامه است. این RTA صدای میکروفون یا صدای محیط سالن را اندازه‌گیری نمی‌کند.');
      content+=`<div class="pro-tools"><label class="primary pick-file" for="rtaAudioPicker">＋ افزودن فایل WAV/MP3</label><input type="file" id="rtaAudioPicker" accept="audio/*" multiple hidden><button class="primary" data-pro-click="play-audio">▶ پخش / مکث</button><button class="soft" data-pro-click="stop-audio">■ توقف</button></div>${proCard('REAL TIME ANALYZER · FFT','<canvas id="rtaCanvas" aria-label="فرکانس صدای میکس"></canvas>','LIVE SPECTRUM')}`;
    } else if(proCurrent==='export'){
      content=banner('WAV EXPORT · میکس آفلاین','تمام ترک‌های بارگذاری‌شده، فیدر، پن، اکولایزر ۴ بانده، کمپرسور کانال، GEQ مستر، FX1–FX8 DELAY و Master وارد فایل خروجی WAV می‌شوند.');
      content+=`${proCard('FINAL MIXDOWN',`<p class="pro-muted">ترک فعال: ${localTracks.length} | مدت: ${formatTime(audioDuration)} | کیفیت WAV: 44.1 kHz / 16-bit / Stereo</p><div class="pro-actions"><button class="primary" data-pro-click="export-wav">↓ ساخت WAV با تمام افکت‌ها</button><button class="soft" data-pro-click="to-player">♫ مدیریت فایل‌ها</button></div><p class="pro-muted">خروجی طولانی به حافظه زیادی نیاز دارد. خروجی MP3 هنوز پیاده‌سازی نشده است.</p>`,'EXPORT')}`;
    }
    el.innerHTML=content;
    if(proCurrent==='geq')requestAnimationFrame(renderGEQPlot);
    if(proCurrent==='rta')requestAnimationFrame(renderRTAChart);
  }
  function initPro(){
    const nav=$('#proNav');nav.innerHTML=proPages.map(([id,n,label,en])=>`<button class="pro-tab" data-pro-page="${id}"><span class="pro-tab-number">${n}</span><strong>${label}</strong><small>${en}</small></button>`).join('');
    updateNav();
    nav.addEventListener('click',e=>{const btn=e.target.closest('[data-pro-page]');if(btn)showProPage(btn.dataset.proPage);});
    $('#proWorkspace').addEventListener('change',e=>{
      if(e.target.id==='geqOutput'){selectedOutput=e.target.value;renderPro();}
      if(e.target.id==='proFXChannel'){fxChannel=Number(e.target.value);renderPro();}
      if(e.target.id==='rtaAudioPicker')loadFiles(e.target.files);
    });
    $('#proWorkspace').addEventListener('input',e=>{
      const slider=e.target.closest('[data-geq]');if(slider){
        const index=Number(slider.dataset.geq),v=Number(slider.value);proGains()[index]=v;
        slider.closest('.geq-band').querySelector('output').textContent=(v>0?'+':'')+v.toFixed(1);
        if(selectedOutput==='main'){saveGEQ();updateGraph();}renderGEQPlot();return;
      }
      const p=e.target.closest('[data-pro-slider]');if(!p)return;
      const key=p.dataset.proSlider,v=Number(p.value);
      p.closest('.pro-slider').querySelector('output').textContent=v.toFixed(Number(p.step)>=1?0:2);
      if(key.startsWith('matrix.'))trainingSettings.matrix[Number(key.split('.')[1])]=v;
      if(key.startsWith('fx.')){const [,fx,field]=key.split('.');fxRack[fx][field]=v;saveFX();updateFXGraph();}
      if(key.startsWith('fxsend.'))remoteSet(slotSendPath(fxChannel,Number(key.split('.')[1])),v);
    });
    $('#proWorkspace').addEventListener('click',e=>{
      const toggle=e.target.closest('[data-pro-toggle]');if(toggle){const [fx,property]=toggle.dataset.proToggle.split('.');fxRack[fx][property]=!fxRack[fx][property];saveFX();updateFXGraph();renderPro();return;}
      const btn=e.target.closest('[data-pro-click]');if(!btn)return;
      const action=btn.dataset.proClick;
      if(action==='geq-flat'){proGains().fill(0);if(selectedOutput==='main'){saveGEQ();updateGraph();}renderPro();}
      else if(action==='geq-vocal'||action==='geq-dip'){
        const vals=proGains();vals.fill(0);
        geqFreqs.forEach((f,i)=>{vals[i]=action==='geq-vocal'?(f<80?-4:f<180?-2:f>4500?1.5:0):(f>180&&f<450?-3:f>1800&&f<3500?-2:0);});
        if(selectedOutput==='main'){saveGEQ();updateGraph();}renderPro();
      }
      else if(action==='save-scene'){$('#saveScene').click();renderPro();}
      else if(action==='load-scene'){$('#loadScene').click();renderPro();}
      else if(action==='reset-scene'){$('#resetScene').click();renderPro();}
      else if(action==='export-wav')exportMix();
      else if(action==='to-player')showProPage('player');
      else if(action==='tofx')showProPage('fx');
      else if(action==='play-audio'){if(playback)haltPlayback(false);else beginPlayback();}
      else if(action==='stop-audio')haltPlayback(true);
    });
    window.addEventListener('resize',()=>{if(proCurrent==='geq')renderGEQPlot();if(proCurrent==='rta')renderRTAChart();refreshPEQ('remote');refreshPEQ('file');});
    window.M32PRO_TEST={getPage:()=>proCurrent,getTracks:()=>localTracks.length,getGEQ:()=>geqGains.slice(),getFX:()=>JSON.parse(JSON.stringify(fxRack)),getPEQ:mode=>peqBands(mode),selectPage:showProPage};
  }

  initPro();
  initScene();initEvents();initPEQEvents();makeStrips();renderLocal();updateRemoteInspector();renderFX();
})();
