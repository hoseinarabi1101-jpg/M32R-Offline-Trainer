package com.m32livestudio.app;

import android.content.res.AssetManager;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Tiny zero-dependency loopback-only HTTP server for WebView to talk to UDP OSC. */
final class LocalServer {
    private final ServerSocket listener;
    private final ExecutorService io = Executors.newFixedThreadPool(5);
    private final AssetManager assets;
    private final OscBridge osc;
    private volatile boolean running = true;

    LocalServer(AssetManager assets,OscBridge osc) throws IOException {
        this.assets=assets; this.osc=osc;
        listener=new ServerSocket(0,12,InetAddress.getByName("127.0.0.1"));
        Thread t=new Thread(this::loop,"m32-loopback-http");t.setDaemon(true);t.start();
    }
    String url(){return "http://127.0.0.1:"+listener.getLocalPort()+"/";}
    void close(){running=false;try{listener.close();}catch(Exception ignored){}io.shutdownNow();}
    private void loop(){
        while(running) try {
            Socket client=listener.accept();client.setSoTimeout(7000);
            io.execute(()->serve(client));
        } catch(Exception e){if(running)android.util.Log.w("M32/HTTP","Listener",e);}
    }
    private static String line(InputStream input) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        while(b.size()<8192) {
            int c=input.read();
            if(c<0)return null;
            if(c=='\n')return b.toString(StandardCharsets.ISO_8859_1.name()).replaceFirst("\\r$","");
            b.write(c);
        }
        throw new IOException("Header line too long");
    }
    private void serve(Socket client){
        try(client) {
            BufferedInputStream in=new BufferedInputStream(client.getInputStream());
            OutputStream out=client.getOutputStream();
            String first=line(in);
            if(first==null)return;
            String[] request=first.split(" ");
            if(request.length<2){sendJson(out,400,new JSONObject().put("error","Invalid request"));return;}
            String method=request[0],path=request[1].split("\\?",2)[0];
            Map<String,String> headers=new HashMap<>();
            for(int i=0;i<60;i++) {
                String row=line(in);
                if(row==null || row.isEmpty())break;
                int colon=row.indexOf(':');
                if(colon>0)headers.put(row.substring(0,colon).trim().toLowerCase(java.util.Locale.ROOT),row.substring(colon+1).trim());
            }
            String host=headers.getOrDefault("host","");
            if(!host.matches("(?i)(?:127\\.0\\.0\\.1|localhost):\\d+")) {
                sendJson(out,403,new JSONObject().put("error","Loopback only"));return;
            }
            if(path.startsWith("/api/")) {
                JSONObject body=new JSONObject();
                if("POST".equals(method)) {
                    int len=Integer.parseInt(headers.getOrDefault("content-length","0"));
                    if(len<0 || len>20000){sendJson(out,413,new JSONObject().put("error","Request too large"));return;}
                    byte[] raw=new byte[len];
                    int read=0;while(read<len){int n=in.read(raw,read,len-read);if(n<0)break;read+=n;}
                    if(read!=len){sendJson(out,400,new JSONObject().put("error","Incomplete data"));return;}
                    body=new JSONObject(new String(raw,StandardCharsets.UTF_8));
                }
                handleApi(method,path,body,out);
                return;
            }
            if(!"GET".equals(method)){sendJson(out,405,new JSONObject().put("error","Method not allowed"));return;}
            String name=path.equals("/")?"index.html":path.startsWith("/")?path.substring(1):path;
            if(!name.matches("[a-zA-Z0-9_-]+\\.(?:html|css|js|png|svg)")){
                sendJson(out,404,new JSONObject().put("error","Not found"));return;
            }
            try(InputStream content=assets.open(name)) {
                String contentType=name.endsWith(".html")?"text/html; charset=utf-8":name.endsWith(".css")?"text/css; charset=utf-8":name.endsWith(".js")?"text/javascript; charset=utf-8":name.endsWith(".svg")?"image/svg+xml":"image/png";
                ByteArrayOutputStream b=new ByteArrayOutputStream();
                byte[] part=new byte[8192];int count;while((count=content.read(part))!=-1)b.write(part,0,count);
                send(out,200,contentType,b.toByteArray());
            } catch(IOException e){sendJson(out,404,new JSONObject().put("error","Not found"));}
        }catch(Exception e){android.util.Log.w("M32/HTTP","Request failed",e);}
    }
    private void handleApi(String method,String path,JSONObject data,OutputStream out) throws Exception {
        JSONObject res=new JSONObject();
        if(path.equals("/api/ping") && method.equals("GET")) {
            sendJson(out,200,res.put("ok",true).put("protected",false));return;
        }
        if(path.equals("/api/status") && method.equals("GET")) {
            sendJson(out,200,osc.status());return;
        }
        if(path.equals("/api/connect") && method.equals("POST")) {
            String ip=data.optString("ip","");
            try {osc.connect(ip);sendJson(out,200,res.put("ok",true).put("ip",ip));}
            catch(Exception e){sendJson(out,400,res.put("error",e.getMessage()));}
            return;
        }
        if(path.equals("/api/disconnect") && method.equals("POST")) {
            osc.disconnect();sendJson(out,200,res.put("ok",true));return;
        }
        if(path.equals("/api/inspect") && method.equals("POST")) {
            int n=data.optInt("channel",0);
            if(n<1 || n>32){sendJson(out,400,res.put("error","Invalid channel"));return;}
            if(!osc.hasTarget()){sendJson(out,409,res.put("error","ابتدا به میکسر وصل شوید"));return;}
            osc.inspect(n);sendJson(out,200,res.put("ok",true));return;
        }
        if(path.equals("/api/control") && method.equals("POST")) {
            try {
                osc.control(data.optString("p",""),data.opt("v"));
                sendJson(out,200,res.put("ok",true));
            }catch(IllegalStateException e){sendJson(out,409,res.put("error",e.getMessage()));}
            catch(Exception e){sendJson(out,400,res.put("error",e.getMessage()));}
            return;
        }
        sendJson(out,404,res.put("error","Unknown endpoint"));
    }
    private static void sendJson(OutputStream out,int code,JSONObject data)throws IOException {
        send(out,code,"application/json; charset=utf-8",data.toString().getBytes(StandardCharsets.UTF_8));
    }
    private static void send(OutputStream out,int code,String type,byte[] body)throws IOException {
        String phrase=code==200?"OK":code==400?"Bad Request":code==403?"Forbidden":code==404?"Not Found":code==405?"Method Not Allowed":code==409?"Conflict":code==413?"Payload Too Large":"Unauthorized";
        String head="HTTP/1.1 "+code+" "+phrase+"\r\nContent-Type: "+type+"\r\nContent-Length: "+body.length+"\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.US_ASCII));out.write(body);out.flush();
    }
}
