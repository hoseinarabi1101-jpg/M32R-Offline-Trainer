package com.m32livestudio.app;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/** Compatible subset of MIDAS M32/X32 OSC 1.0 using Wi-Fi / UDP 10023. */
final class OscBridge {
    private final DatagramSocket socket;
    private final ScheduledExecutorService poller = Executors.newSingleThreadScheduledExecutor();
    private final Map<String,Object> values = new ConcurrentHashMap<>();
    private final List<String> initial = new ArrayList<>();
    private volatile InetAddress target;
    private volatile long lastReply;
    private volatile String mixerName = "";
    private volatile boolean running = true;
    private int scanCursor = 0;

    OscBridge() throws IOException {
        socket = new DatagramSocket();
        for (int i=1; i<=32; i++) {
            String p = "/ch/" + two(i);
            initial.add(p + "/mix/fader"); initial.add(p + "/mix/on");
            initial.add(p + "/mix/pan"); initial.add(p + "/config/name");
        }
        for (String group : new String[]{"auxin:8", "fxrtn:8", "bus:16", "mtx:6"}) {
            String[] parts = group.split(":");
            for (int i=1;i<=Integer.parseInt(parts[1]);i++) {
                String p="/"+parts[0]+"/"+two(i);
                initial.add(p+"/mix/fader");initial.add(p+"/mix/on");initial.add(p+"/config/name");
            }
        }
        for(int i=1;i<=8;i++) { initial.add("/dca/"+i+"/mix/fader");initial.add("/dca/"+i+"/mix/on"); }
        for(int i=1;i<=71;i++) initial.add("/-stat/solosw/"+two(i));
        for(String p:new String[]{"/main/st", "/main/m"}) { initial.add(p+"/mix/fader");initial.add(p+"/mix/on"); }
        Thread receiver = new Thread(this::receiveLoop, "m32-udp-listener");
        receiver.setDaemon(true);receiver.start();
        poller.scheduleAtFixedRate(this::refresh,1700,1700,TimeUnit.MILLISECONDS);
    }

    static String two(int n) { return String.format(java.util.Locale.ROOT,"%02d",n); }

    synchronized void connect(String ip) throws IOException {
        if(!validIp(ip)) throw new IllegalArgumentException("آدرس IP میکسر صحیح نیست.");
        InetAddress addr=InetAddress.getByName(ip);
        if(addr.isAnyLocalAddress() || addr.isLoopbackAddress() || addr.isMulticastAddress())
            throw new IllegalArgumentException("آدرس IP مجاز نیست.");
        target=addr;lastReply=0;mixerName="";values.clear();scanCursor=0;
        send("/xinfo",null);send("/info",null);send("/xremote",null);
        for(int n=0;n<30 && scanCursor<initial.size();n++) send(initial.get(scanCursor++),null);
    }

    static boolean validIp(String ip) {
        if(ip==null || !ip.matches("\\d{1,3}(\\.\\d{1,3}){3}"))return false;
        String[] p=ip.split("\\.");
        for(String t:p) if(Integer.parseInt(t)>255)return false;
        int first=Integer.parseInt(p[0]);
        return first>=1 && first<=223 && !(first==169 && Integer.parseInt(p[1])==254);
    }

    synchronized void disconnect() {
        target=null;lastReply=0;mixerName="";values.clear();scanCursor=0;
    }

    private synchronized void refresh() {
        if(target==null) return;
        send("/xremote",null);
        send("/xinfo",null);
        for(int n=0;n<40 && scanCursor<initial.size();n++) send(initial.get(scanCursor++),null);
    }

    private static byte[] stringBytes(String v) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        b.write(v.getBytes(StandardCharsets.UTF_8));b.write(0);
        while(b.size()%4!=0)b.write(0);
        return b.toByteArray();
    }
    synchronized void send(String address,Object value) {
        if(target==null)return;
        try {
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            out.write(stringBytes(address));
            String type=",";
            if(value instanceof String)type+= "s";
            else if(value instanceof Integer || value instanceof Boolean)type+="i";
            else if(value instanceof Number)type+="f";
            out.write(stringBytes(type));
            if(value instanceof String)out.write(stringBytes((String)value));
            else if(value instanceof Number || value instanceof Boolean) {
                ByteBuffer bb=ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN);
                if("i".equals(type.substring(1))) bb.putInt(value instanceof Boolean? ((boolean)value?1:0): ((Number)value).intValue());
                else bb.putFloat(((Number)value).floatValue());
                out.write(bb.array());
            }
            byte[] data=out.toByteArray();
            socket.send(new DatagramPacket(data,data.length,target,10023));
        } catch(Exception e) { android.util.Log.w("M32/OSC","Send failed",e); }
    }

    private void receiveLoop() {
        byte[] buf=new byte[65535];
        while(running) {
            try {
                DatagramPacket packet=new DatagramPacket(buf,buf.length);socket.receive(packet);
                InetAddress desired=target;
                if(desired!=null && desired.equals(packet.getAddress())) {
                    parse(buf, packet.getOffset(), packet.getLength(),0);
                }
            } catch(Exception e) {if(running) android.util.Log.w("M32/OSC","Receive failed",e);}
        }
    }

    private static int padded(int pos,int start) { return start+((pos-start+3)&~3); }
    private static class ReadString {
        String text; int next;
        ReadString(String t,int n){text=t;next=n;}
    }
    private static ReadString readString(byte[] buf,int pos,int limit,int origin) throws IOException {
        int end=pos;
        while(end<limit && buf[end]!=0)end++;
        if(end>=limit)throw new IOException("Missing OSC terminator");
        String v=new String(buf,pos,end-pos,StandardCharsets.UTF_8);
        int next = padded(end+1,origin);
        if(next>limit)throw new IOException("Invalid OSC alignment");
        return new ReadString(v,next);
    }
    private void parse(byte[] b,int start,int length,int depth) {
        if(depth>5 || length<4 || length>65535)return;
        int limit=start+length;
        try {
            if(length>=16 && b[start]=='#' && b[start+1]=='b' && b[start+2]=='u') {
                int p=start+16;
                while(p+4<=limit) {
                    int n=ByteBuffer.wrap(b,p,4).order(ByteOrder.BIG_ENDIAN).getInt();p+=4;
                    if(n<=0 || n>65535 || p+n>limit)break;
                    parse(b,p,n,depth+1);p+=n;
                }
                return;
            }
            ReadString address=readString(b,start,limit,start);
            if(!address.text.startsWith("/"))return;
            List<Object> args=new ArrayList<>();
            if(address.next<limit) {
                ReadString tags=readString(b,address.next,limit,start);
                int p=tags.next;
                if(tags.text.startsWith(",")) for(int i=1;i<tags.text.length();i++) {
                    char type=tags.text.charAt(i);
                    if(type=='i' || type=='f') {
                        if(p+4>limit)break;
                        ByteBuffer bb=ByteBuffer.wrap(b,p,4).order(ByteOrder.BIG_ENDIAN);
                        args.add(type=='i'?bb.getInt():bb.getFloat());p+=4;
                    } else if(type=='s') {
                        ReadString s=readString(b,p,limit,start);args.add(s.text);p=s.next;
                    } else if(type=='T')args.add(1);
                    else if(type=='F')args.add(0);
                    else break;
                }
            }
            lastReply=System.currentTimeMillis();
            if((address.text.equals("/xinfo") || address.text.equals("/info")) && !args.isEmpty()) {
                StringBuilder sb=new StringBuilder();
                for(int n=0;n<args.size() && n<4;n++)if(args.get(n) instanceof String){if(sb.length()>0)sb.append(" · ");sb.append(args.get(n));}
                mixerName=sb.length()>180?sb.substring(0,180):sb.toString();
            } else if(!args.isEmpty() && address.text.length()<=95) {
                Object v=args.get(0);
                if(v instanceof Number || (v instanceof String && ((String)v).length()<130))values.put(address.text,v);
            }
        } catch(Exception ignored) {/* Malformed or unsupported OSC packets are ignored. */}
    }

    JSONObject status() throws Exception {
        JSONObject j=new JSONObject();
        InetAddress addr=target;
        j.put("target",addr==null?JSONObject.NULL:addr.getHostAddress());
        j.put("connected",addr!=null && lastReply>0 && System.currentTimeMillis()-lastReply<12000);
        j.put("lastReply",lastReply);j.put("mixerName",mixerName);
        JSONObject state=new JSONObject();
        for(Map.Entry<String,Object> e:values.entrySet())state.put(e.getKey(),e.getValue());
        j.put("values",state);
        return j;
    }
    boolean isConnected() {return target!=null && lastReply>0 && System.currentTimeMillis()-lastReply<12000;}
    boolean hasTarget(){return target!=null;}

    void inspect(int channel) {
        if(channel<1 || channel>32)throw new IllegalArgumentException("Invalid channel");
        String p="/ch/"+two(channel);
        List<String> queries=new ArrayList<>();
        for(String s:new String[]{"/eq/on","/gate/on","/gate/thr","/dyn/on","/dyn/thr","/dyn/ratio"}) queries.add(p+s);
        for(int band=1;band<=4;band++)for(String s:new String[]{"f","g","q"})queries.add(p+"/eq/"+band+"/"+s);
        for(int bus=1;bus<=16;bus++)queries.add(p+"/mix/"+two(bus)+"/level");
        for(int i=0;i<queries.size();i++) {
            String q=queries.get(i);
            poller.schedule(()->send(q,null),i*6L,TimeUnit.MILLISECONDS);
        }
    }

    private static final Pattern CONTROL = Pattern.compile(
        "^/(?:ch/(?:0[1-9]|[12][0-9]|3[012])|auxin/0[1-8]|fxrtn/0[1-8]|bus/(?:0[1-9]|1[0-6])|mtx/0[1-6]|main/(?:st|m)|dca/[1-8])/mix/(?:fader|on)$|"+
        "^/ch/(?:0[1-9]|[12][0-9]|3[012])/(?:mix/pan|(?:eq|gate|dyn)/on|eq/[1-4]/(?:f|g|q)|(?:gate|dyn)/thr|dyn/ratio|mix/(?:0[1-9]|1[0-6])/level|config/name)$|"+
        "^/-stat/solosw/(?:0[1-9]|[1-6][0-9]|7[01])$");
    void control(String path,Object value) {
        if(!isConnected()) throw new IllegalStateException("میکسر متصل نیست؛ فرمان ارسال نشد.");
        if(path==null || path.length()>90 || !CONTROL.matcher(path).matches())throw new IllegalArgumentException("پارامتر مجاز نیست");
        final Object normalized;
        if(path.endsWith("/config/name")) {
            if(!(value instanceof String) || ((String)value).length()>12 || ((String)value).matches("(?s).*[\\x00-\\x1F].*"))
                throw new IllegalArgumentException("نام کانال نامعتبر است");
            normalized=value;
        } else if(path.endsWith("/on") || path.contains("/solosw/") || path.endsWith("/ratio")) {
            if(!(value instanceof Number))throw new IllegalArgumentException("مقدار باید عدد صحیح باشد");
            double n=((Number)value).doubleValue();
            if((path.endsWith("/ratio") && (n<0 || n>11 || Math.floor(n)!=n)) ||
               (!path.endsWith("/ratio") && n!=0 && n!=1))throw new IllegalArgumentException("مقدار صحیح مجاز نیست");
            normalized=(int)n;
        } else {
            if(!(value instanceof Number))throw new IllegalArgumentException("مقدار عددی نیست");
            double n=((Number)value).doubleValue();
            if(!Double.isFinite(n) || n<0 || n>1)throw new IllegalArgumentException("مقدار باید بین صفر تا یک باشد");
            normalized=(float)n;
        }
        send(path,normalized);values.put(path,normalized);
    }

    void close(){running=false;disconnect();poller.shutdownNow();socket.close();}
}
