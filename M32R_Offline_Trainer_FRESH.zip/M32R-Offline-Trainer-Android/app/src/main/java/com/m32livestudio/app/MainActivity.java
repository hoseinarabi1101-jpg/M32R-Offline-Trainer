package com.m32livestudio.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.WindowManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Locale;

/** Android shell: private offline WebView UI + native audio file picker and WAV save. */
public final class MainActivity extends Activity {
    private static final int CHOOSE_AUDIO=903;
    private WebView web;
    private LocalServer local;
    private ValueCallback<Uri[]> chooser;
    private final Object wavLock=new Object();
    private OutputStream wavStream;
    private Uri wavUri;
    private String wavDestination="";
    private boolean wavActive=false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        try {
            local=new LocalServer(getAssets());
        }catch(Exception e){Toast.makeText(this,"خطا در راه‌اندازی برنامه: "+e.getMessage(),Toast.LENGTH_LONG).show();finish();return;}
        web=new WebView(this);
        web.setBackgroundColor(0xff0b111b);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.getSettings().setUserAgentString(web.getSettings().getUserAgentString()+" M32ROfflineTrainer/0.3");
        web.addJavascriptInterface(new SaveBridge(),"AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){
                Uri uri=request.getUrl();return !("127.0.0.1".equals(uri.getHost()) && uri.getPort()==Uri.parse(local.url()).getPort());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params) {
                if(chooser!=null)chooser.onReceiveValue(null);
                chooser=callback;
                try {
                    Intent picker=new Intent(Intent.ACTION_GET_CONTENT);
                    picker.addCategory(Intent.CATEGORY_OPENABLE);
                    picker.setType("audio/*");
                    picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                    startActivityForResult(Intent.createChooser(picker,"انتخاب فایل‌های صوتی"),CHOOSE_AUDIO);
                } catch(Exception e) {chooser=null;callback.onReceiveValue(null);Toast.makeText(MainActivity.this,"باز کردن فایل ممکن نیست",Toast.LENGTH_LONG).show();}
                return true;
            }
        });
        setContentView(web);
        web.loadUrl(local.url());
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=CHOOSE_AUDIO || chooser==null)return;
        Uri[] chosen=null;
        if(resultCode==RESULT_OK && data!=null) {
            ClipData clips=data.getClipData();
            if(clips!=null){chosen=new Uri[clips.getItemCount()];for(int i=0;i<clips.getItemCount();i++)chosen[i]=clips.getItemAt(i).getUri();}
            else if(data.getData()!=null)chosen=new Uri[]{data.getData()};
        }
        chooser.onReceiveValue(chosen);chooser=null;
    }
    private class SaveBridge {
        /** State is saved natively because the private HTTP server uses an ephemeral port. */
        @JavascriptInterface public String getStore(String key) {
            if(key==null || !key.matches("m32r_[a-z_]+"))return null;
            return getSharedPreferences("m32r_offline_training",MODE_PRIVATE).getString(key,null);
        }
        @JavascriptInterface public void setStore(String key,String value) {
            if(key==null || !key.matches("m32r_[a-z_]+") || value==null || value.length()>1000000)return;
            getSharedPreferences("m32r_offline_training",MODE_PRIVATE).edit().putString(key,value).apply();
        }
        @JavascriptInterface public String beginWav(String name) {
            synchronized(wavLock) {
                discard();
                try {
                    String filename = "M32-LiveStudio-Mix-"+System.currentTimeMillis()+".wav";
                    if(Build.VERSION.SDK_INT>=29) {
                        ContentValues cv=new ContentValues();
                        cv.put(MediaStore.Downloads.DISPLAY_NAME,filename);
                        cv.put(MediaStore.Downloads.MIME_TYPE,"audio/wav");
                        cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/M32 Live Studio");
                        cv.put(MediaStore.Downloads.IS_PENDING,1);
                        wavUri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
                        if(wavUri==null)throw new IOException("Cannot open Downloads");
                        wavStream=getContentResolver().openOutputStream(wavUri);
                        wavDestination="Downloads/M32 Live Studio/"+filename;
                    } else {
                        File dir=getExternalFilesDir(Environment.DIRECTORY_MUSIC);
                        if(dir==null)throw new IOException("Cannot open music folder");
                        if(!dir.exists() && !dir.mkdirs())throw new IOException("Cannot create folder");
                        File file=new File(dir,filename);
                        wavStream=new FileOutputStream(file);
                        wavDestination=file.getAbsolutePath();
                    }
                    if(wavStream==null)throw new IOException("Cannot write audio");
                    wavActive=true;
                    return "OK";
                }catch(Exception e){discard();return "ERROR: "+e.getMessage();}
            }
        }
        @JavascriptInterface public String appendWavChunk(String base64) {
            synchronized(wavLock) {
                if(!wavActive || wavStream==null)return "ERROR: No export is active";
                try {wavStream.write(Base64.decode(base64,Base64.DEFAULT));return "OK";}
                catch(Exception e){discard();return "ERROR: "+e.getMessage();}
            }
        }
        @JavascriptInterface public String finishWav() {
            synchronized(wavLock){
                if(!wavActive)return "ERROR: No active export";
                try {
                    wavStream.flush();wavStream.close();wavStream=null;
                    if(Build.VERSION.SDK_INT>=29 && wavUri!=null) {
                        ContentValues c=new ContentValues();c.put(MediaStore.Downloads.IS_PENDING,0);
                        getContentResolver().update(wavUri,c,null,null);
                    }
                    wavActive=false;wavUri=null;
                    return "OK: "+wavDestination;
                }catch(Exception e){discard();return "ERROR: "+e.getMessage();}
            }
        }
        @JavascriptInterface public void cancelWav(){synchronized(wavLock){discard();}}
    }
    private void discard(){
        try {if(wavStream!=null)wavStream.close();}catch(Exception ignored){}
        wavStream=null;wavActive=false;
        if(wavUri!=null && Build.VERSION.SDK_INT>=29){try {getContentResolver().delete(wavUri,null,null);}catch(Exception ignored){}}
        wavUri=null;
    }
    @Override public void onBackPressed(){
        if(web!=null && web.canGoBack())web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(chooser!=null){chooser.onReceiveValue(null);chooser=null;}
        synchronized(wavLock){discard();}
        if(local!=null)local.close();
        if(web!=null){web.destroy();web=null;}
        super.onDestroy();
    }
}
