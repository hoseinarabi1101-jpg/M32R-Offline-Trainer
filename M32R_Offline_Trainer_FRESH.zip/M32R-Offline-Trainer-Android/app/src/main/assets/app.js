'use strict';
(() => {
  const $ = selector => document.querySelector(selector);
  const clamp = (x, a=0, b=1) => Math.max(a, Math.min(b, x));
  const escapeHTML = value => String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
  const nativeStore = () => Boolean(window.M32_ANDROID && window.AndroidBridge && typeof window.AndroidBridge.getStore==='function');
  const getStore = key => nativeStore() ? window.AndroidBridge.getStore(key) : localStorage.getItem(key);
  const setStore = (key,value) => nativeStore() ? window.AndroidBridge.setStore(key,value) : localStorage.setItem(key,value);
  const ch2 = n => String(n).padStart(2,'0');
  const names = { ch:'CH',auxin:'AUX',fxrtn:'FX',bus:'BUS',dca:'DCA',mtx:'MTX',mono:'MONO',main:'MAIN' };
  const banks = [
    {id:'ch1',label:'CH 01–08',kind:'ch',start:1,count:8},
    {id:'ch2',label:'CH 09–16',kind:'ch',start:9,count:8},
    {id:'ch3',label:'CH 17–24',kind:'ch',start:17,count:8},
    {id:'ch4',label:'CH 25–32',kind:'ch',start:25,count:8},
    {id:'aux',label:'AUX 01–08',kind:'auxin',start:1,count:8},
    {id:'fx',label:'FX RETURNS',kind:'fxrtn',start:1,count:8},
    {id:'bus1',label:'BUS 01–08',kind:'bus',start:1,count:8},
    {id:'bus2',label:'BUS 09–16',kind:'bus',start:9,count:8},
    {id:'dca',label:'DCA 01–08',kind:'dca',start:1,count:8},
    {id:'mtx',label:'MATRIX / MONO',kind:'mtx',start:1,count:7},
  ];
  const remote = { bank:'ch1', selected:{kind:'ch',n:1}, tab:'eq', values:{}, pending:{}, lastTouch:{}, target:null,connected:true, lastReply:0, hasBridge:false, name:'' };
  let activeMode = 'remote';
  let localTracks = [];
  let fileSelected = null;
  let fileTab = 'eq';
  let fileMaster = { fader:0.75, mute:false };
  let audioContext = null;
  let playback = null;
  let playOffset = 0;
  let audioDuration = 0;
  let lastScrub = false;
  let toastTimer = null;
  let sendOnFaders=false;
  let selectedSendBus=1;
  let saveTimer=null;
  let trackId = 0;
  const channelsForBank = bank => {
    if (bank.kind === 'mtx') return [...Array(6)].map((_,i)=>({kind:'mtx',n:i+1})).concat([{kind:'mono',n:1}]);
    return [...Array(bank.count)].map((_,i)=>({kind:bank.kind,n:bank.start+i}));
  };
  const basePath = item => item.kind === 'main' ? '/main/st' : item.kind === 'mono' ? '/main/m' : `/${item.kind}/${item.kind==='dca' ? item.n : ch2(item.n)}`;
  const pathFor = (item, field) => `${basePath(item)}/mix/${field}`;
  function soloPath(item) {
    let n;
    if (item.kind==='ch') n=item.n;
    else if (item.kind==='auxin') n=32+item.n;
    else if (item.kind==='fxrtn') n=40+item.n;
    else if (item.kind==='bus') n=48+item.n;
    else if (item.kind==='mtx') n=64+item.n;
    else if (item.kind==='main') n=71;
    return n ? `/-stat/solosw/${ch2(n)}` : null;
  }
  function db(f) {
    if (f === undefined || f === null || f <= 0) return '-∞';
    const d = f >= 0.5 ? 40*f-30 : f>=.25 ? 80*f-50 : f>=.0625 ? 160*f-70 : 480*f-90;
    return (d>=0 ? '+' : '') + d.toFixed(1);
  }
  function gain(f) {
    if (f <= 0) return 0;
    const x = f >= .5 ? 40*f-30 : f>=.25 ? 80*f-50 : f>=.0625 ? 160*f-70 : 480*f-90;
    return Math.pow(10, x/20);
  }
  const notify = (message, duration=3800) => {
    const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>el.classList.remove('show'),duration);
  };
  function simFaderPath(item) {
    return sendOnFaders && item.kind === 'ch'
      ? `/ch/${ch2(item.n)}/mix/${ch2(selectedSendBus)}/level`
      : pathFor(item,'fader');
  }
  function initialScene(){
    const vals={};
    for(const kind of ['ch','auxin','fxrtn','bus','dca','mtx','mono','main']){
      const count={ch:32,auxin:8,fxrtn:8,bus:16,dca:8,mtx:6,mono:1,main:1}[kind];
      for(let n=1;n<=count;n++){
        const it={kind,n}; vals[pathFor(it,'fader')]=.75;
        vals[pathFor(it,'on')]=1;
        const sp=soloPath(it);if(sp)vals[sp]=0;
      }
    }
    for(let n=1;n<=32;n++){
      const pre=`/ch/${ch2(n)}`;
      vals[`${pre}/mix/pan`]=.5;
      vals[`${pre}/eq/on`]=1;
      vals[`${pre}/gate/on`]=0;
      vals[`${pre}/gate/thr`]=.5;
      vals[`${pre}/dyn/on`]=0;
      vals[`${pre}/dyn/thr`]=.6;
      for(let b=1;b<=4;b++){
        const bp=`${pre}/eq/${b}`;
        vals[bp+'/f']=[.233,.451,.699,.885][b-1];
        vals[bp+'/g']=.5; vals[bp+'/q']=.68;
      }
      for(let b=1;b<=16;b++)vals[`${pre}/mix/${ch2(b)}/level`]=0;
    }
    return vals;
  }
  function initScene(){
    remote.values=initialScene();
    try {
      const loaded=JSON.parse(getStore('m32r_current_state')||'null');
      if(loaded && typeof loaded==='object' && !Array.isArray(loaded))
        Object.assign(remote.values,loaded);
    }catch{}
    fileMaster.fader=remote.values['/main/st/mix/fader'];
    fileMaster.mute=remote.values['/main/st/mix/on']===0;
  }
  function persistScene(){
    clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{try{setStore('m32r_current_state',JSON.stringify(remote.values));}catch{}},250);
  }
  function trackAtChannel(n){return localTracks.find(t=>t.channel===n);}
  function syncAudioFromSim(path,value){
    if(path==='/main/st/mix/fader'){fileMaster.fader=value;updateGraph();updateLocalStripData();return;}
    if(path==='/main/st/mix/on'){fileMaster.mute=value===0;updateGraph();updateLocalStripData();return;}
    const solo=path.match(/^\/-stat\/solosw\/(\d+)$/);
    if(solo){const t=trackAtChannel(+solo[1]);if(t){t.solo=!!value;updateGraph();updateLocalStripData();}return;}
    const m=path.match(/^\/ch\/(\d{2})\/(.+)$/);
    if(!m)return;
    const t=trackAtChannel(+m[1]);if(!t)return;
    const field=m[2];
    if(field==='mix/fader')t.fader=value;
    else if(field==='mix/on')t.mute=value===0;
    else if(field==='mix/pan')t.pan=(value-.5)*2;
    else if(field==='config/name')t.name=String(value);
    else if(field==='eq/on')t.eqOn=value===1;
    else if(field==='dyn/on')t.comp.on=value===1;
    else if(field==='dyn/thr')t.comp.threshold=-60+60*value;
    else {
      const e=field.match(/^eq\/(\d)\/(f|g|q)$/);
      if(e){const band=t.eq[+e[1]-1];if(band) {
        if(e[2]==='f')band.freq=20*Math.pow(1000,value);
        if(e[2]==='g')band.gain=(value-.5)*30;
        if(e[2]==='q')band.q=10*Math.pow(.03,value);
      }}
    }
    updateGraph();updateLocalStripData();
  }
  function applySimToTrack(t){
    const n=ch2(t.channel),p=`/ch/${n}`;
    for(const [path,v] of Object.entries(remote.values)){
      if(path.startsWith(p+'/')||path===`/-stat/solosw/${n}`)syncAudioFromSim(path,v);
    }
    if(!remote.values[p+'/config/name'])remote.values[p+'/config/name']=t.name.slice(0,12);
    else t.name=String(remote.values[p+'/config/name']);
    updateRemoteStripData();persistScene();
  }
  function pushTrackToSim(t){
    const n=ch2(t.channel),p=`/ch/${n}`;
    remote.values[p+'/config/name']=t.name.slice(0,12);
    remote.values[p+'/mix/fader']=t.fader;
    remote.values[p+'/mix/on']=t.mute?0:1;
    remote.values[p+'/mix/pan']=(t.pan+1)/2;
    remote.values[`/-stat/solosw/${n}`]=t.solo?1:0;
    remote.values[p+'/eq/on']=t.eqOn===false?0:1;
    remote.values[p+'/dyn/on']=t.comp.on?1:0;
    remote.values[p+'/dyn/thr']=(t.comp.threshold+60)/60;
    t.eq.forEach((band,i)=>{
      remote.values[`${p}/eq/${i+1}/f`]=clamp(Math.log(band.freq/20)/Math.log(1000));
      remote.values[`${p}/eq/${i+1}/g`]=clamp(band.gain/30+.5);
      remote.values[`${p}/eq/${i+1}/q`]=clamp(Math.log(band.q/10)/Math.log(.03));
    });
    persistScene();updateRemoteStripData();
  }
  async function remoteSet(path,value){
    remote.values[path]=value;
    syncAudioFromSim(path,value);
    persistScene();
    return true;
  }
  function sceneRestore(values){
    remote.values={...initialScene(),...values};
    for(const t of localTracks){
      const n=ch2(t.channel),p=`/ch/${n}`;
      for(const [path,v] of Object.entries(remote.values)){
        if(path.startsWith(p+'/')||path===`/-stat/solosw/${n}`)syncAudioFromSim(path,v);
      }
    }
    syncAudioFromSim('/main/st/mix/fader',remote.values['/main/st/mix/fader']);
    syncAudioFromSim('/main/st/mix/on',remote.values['/main/st/mix/on']);
    makeStrips();updateRemoteInspector();updateGraph();persistScene();
  }
  function sceneButtons(){
    $('#saveScene').onclick=()=>{
      const name=prompt('نام Scene را وارد کن (مثل جلسه اول):','تمرین من');if(!name)return;
      try{
        const scenes=JSON.parse(getStore('m32r_scenes')||'{}');
        scenes[name.trim()]=JSON.parse(JSON.stringify(remote.values));
        setStore('m32r_scenes',JSON.stringify(scenes));notify('Scene «'+name.trim()+'» ذخیره شد.');
      }catch(e){notify('ذخیره انجام نشد: '+e.message);}
    };
    $('#loadScene').onclick=()=>{
      try{
        const scenes=JSON.parse(getStore('m32r_scenes')||'{}'), names=Object.keys(scenes);
        if(!names.length){notify('هنوز Scene ذخیره نکرده‌ای.');return;}
        const name=prompt('نام Scene را وارد کن:\n'+names.join(' / '),names[names.length-1]);
        if(!name)return;if(!scenes[name.trim()]){notify('Scene پیدا نشد.');return;}
        sceneRestore(scenes[name.trim()]);notify('Scene بازیابی شد.');
      }catch(e){notify('بازیابی ممکن نشد: '+e.message);}
    };
    $('#resetScene').onclick=()=>{
      if(!confirm('تمام تنظیمات میکسر مجازی صفر/پیش‌فرض شوند؟ فایل‌های صوتی حذف نمی‌شوند.'))return;
      sceneRestore({});notify('تنظیمات به حالت پیش‌فرض برگشت.');
    };
    $('#sofButton').onclick=()=>{
      sendOnFaders=!sendOnFaders;
      const btn=$('#sofButton');btn.classList.toggle('active-sof',sendOnFaders);
      btn.textContent=`SENDS ON FADERS: ${sendOnFaders?'ON · BUS '+ch2(selectedSendBus):'OFF'}`;
      updatePracticeStatus();makeStrips();
    };
  }
  function updatePracticeStatus(){
    $('#practiceStatus').textContent=sendOnFaders
      ? `حالت Sends on Faders · BUS ${ch2(selectedSendBus)}: فیدرهای CH سطح ارسال به این باس را تغییر می‌دهند. برای عوض‌کردن باس روی BUS 1–16 برو و SELECT را بزن. (صرفاً شبیه‌سازی مسیر؛ بدون پردازش Bus)`
      : `${banks.find(b=>b.id===remote.bank)?.label||''} · حالت عادی · روی SELECT بزن تا تنظیمات کانال را ببینی. برای تمرین شنیداری از «آوردن صدای واقعی» استفاده کن.`;
  }
  async function makeDemo(){
    if(localTracks.length){notify('برای ساخت صدای آزمایشی، ابتدا ترک‌های قبلی را از بخش میکس فایل‌ها پاک کن.');return;}
    audioContext||=new (window.AudioContext||window.webkitAudioContext)();
    const rate=22050,duration=16,count=Math.round(rate*duration);
    const samples=[110,220,440,880];
    for(let i=0;i<4;i++){
      const buffer=audioContext.createBuffer(1,count,rate),data=buffer.getChannelData(0),freq=samples[i];
      for(let j=0;j<count;j++){
        const t=j/rate,env=Math.min(1,t*15)*Math.min(1,(duration-t)*5);
        data[j]=env*(.23*Math.sin(2*Math.PI*freq*t)+.08*Math.sin(2*Math.PI*freq*2*t)+.02*Math.sin(2*Math.PI*freq*3*t));
      }
      const names=['بم · Bass','صدای بم','صدای میانی','صدای زیر'];
      const t={id:++trackId,channel:i+1,name:names[i],fader:.75,mute:false,solo:false,pan:0,eq:localEqDefaults(),eqOn:true,comp:{on:false,threshold:-24,ratio:3},buffer,size:count*4};
      localTracks.push(t);applySimToTrack(t);
    }
    renderLocal();makeStrips();notify('۴ منبع صوتی آزمایشی روی CH 1–4 قرار گرفت. پخش را بزن و EQ و فیدرها را تغییر بده.',6000);
  }
  function makeStrips() {
    $('#bankbar').innerHTML=banks.map(b=>`<button class="bank-button ${remote.bank===b.id?'active':''}" data-bank="${b.id}">${b.label}</button>`).join('');
    $('#bankCaption').textContent=banks.find(b=>b.id===remote.bank)?.label||'';
    $('#remoteStrips').innerHTML=channelsForBank(banks.find(b=>b.id===remote.bank)).map(item=>stripHTML(item,'remote')).join('');
    $('#remoteMaster').innerHTML=stripHTML({kind:'main',n:1},'remote');
    updateRemoteStripData();updatePracticeStatus();
  }
  function stripHTML(item, mode) {
    const isRemote=mode==='remote';
    const id=isRemote ? `${item.kind}-${item.n}` : String(item.id);
    const identity = isRemote ? `${names[item.kind]} ${item.kind==='main' ? 'L/R' : ch2(item.n)}` : `FILE ${String(localTracks.indexOf(item)+1).padStart(2,'0')}`;
    const selected = isRemote ? (remote.selected.kind===item.kind&&remote.selected.n===item.n) : (fileSelected===item.id);
    const value=isRemote ? remote.values[simFaderPath(item)] : item.fader;
    const level=typeof value==='number' ? clamp(value) : .75;
    const label = isRemote ? (remote.values[`${basePath(item)}/config/name`]||identity) : item.name;
    const muted = isRemote ? remote.values[pathFor(item,'on')]===0 : item.mute;
    const solo = isRemote ? Boolean(remote.values[soloPath(item)]) : item.solo;
    const soloAllowed = isRemote ? Boolean(soloPath(item)) : item.id!=='file-master';
    return `<div class="strip ${selected?'selected':''} ${item.kind==='main'?'master':''}" data-id="${escapeHTML(id)}" data-mode="${mode}">
      <div class="strip-title">${escapeHTML(identity)}</div>
      <div class="scribble"><span class="scribble-name" title="${escapeHTML(label)}">${escapeHTML(label)}</span><span class="scribble-sub">${isRemote ? (sendOnFaders&&item.kind==='ch'? 'SEND BUS '+ch2(selectedSendBus) : 'OFFLINE') : 'LOCAL AUDIO'}</span></div>
      <div class="meter-mini" aria-label="متر سطح صدای واقعی در این نسخه موجود نیست"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
      <button class="strip-btn select ${selected?'active':''}" data-action="select">SELECT</button>
      <button class="strip-btn solo ${solo?'active':''}" data-action="solo" ${soloAllowed?'':'disabled'}>SOLO</button>
      <div class="fader-container" role="slider" tabindex="0" data-action="fader" aria-label="${escapeHTML(label)} فیدر" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(level*100)}" style="--level:${level};--knob:${(level*165).toFixed(2)}px">
        <div class="fader-markers"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        <div class="fader-rail"></div><div class="fader-knob"></div>
      </div>
      <div class="db-number">${isRemote&&typeof value!=='number'?'—':db(level)} dB</div>
      <button class="strip-btn mute ${muted?'active':''}" data-action="mute">MUTE</button>
    </div>`;
  }
  function updateVisualStrip(el, item, mode) {
    if (!el) return;
    const r=mode==='remote';
    const f=r ? remote.values[simFaderPath(item)] : item.fader;
    const level=typeof f==='number'?clamp(f):.75;
    const fader=el.querySelector('.fader-container');
    if (!fader.matches(':active')&&!fader.hasAttribute('data-dragging')) {
      fader.style.setProperty('--level',level);fader.style.setProperty('--knob',`${(level*165).toFixed(2)}px`);
      fader.setAttribute('aria-valuenow',String(Math.round(level*100)));
      el.querySelector('.db-number').textContent=r&&typeof f!=='number' ? '— dB' : `${db(level)} dB`;
    }
    const name=r ? remote.values[`${basePath(item)}/config/name`] : item.name;
    if (name) el.querySelector('.scribble-name').textContent=String(name);
    const muted=r ? remote.values[pathFor(item,'on')]===0 : item.mute;
    el.querySelector('.mute').classList.toggle('active',Boolean(muted));
    const solo=r ? Boolean(remote.values[soloPath(item)]) : item.solo;
    el.querySelector('.solo').classList.toggle('active',Boolean(solo));
    const isSelected=r ? remote.selected.kind===item.kind&&remote.selected.n===item.n : fileSelected===item.id;
    el.classList.toggle('selected',isSelected);
    el.querySelector('.select').classList.toggle('active',isSelected);
  }
  function updateRemoteStripData() {
    document.querySelectorAll('#remoteStrips .strip,#remoteMaster .strip').forEach(el => {
      const [kind,n]=el.dataset.id.split('-');updateVisualStrip(el,{kind,n:Number(n)},'remote');
    });
  }
  // Offline simulator: edits are stored locally, never sent to a console.
  function setRemoteFader(item,level) {remoteSet(simFaderPath(item),level);}
  function selectRemote(item) {
    remote.selected={kind:item.kind,n:item.n};remote.tab='eq';
    updateRemoteStripData(); updateRemoteInspector();
    if(item.kind==='bus'){selectedSendBus=item.n;$('#sofButton').textContent=`SENDS ON FADERS: ${sendOnFaders?'ON · BUS '+ch2(selectedSendBus):'OFF'}`;updatePracticeStatus();}
  }
  const isNumeric = x => typeof x==='number'&&Number.isFinite(x);
  const rv = (path,defaultValue=.5) => isNumeric(remote.values[path]) ? remote.values[path] : defaultValue;
  const controlHTML = (label,path,def,formatter) => `<div class="control-row" data-path="${escapeHTML(path)}"><label><span>${label}</span><output>${escapeHTML(formatter(rv(path,def)))}</output></label><input type="range" class="remote-input" data-path="${escapeHTML(path)}" min="0" max="1000" value="${Math.round(rv(path,def)*1000)}" data-format="${escapeHTML(label)}" /></div>`;
  const toggleHTML = (label,path) => `<div class="toggle-row"><span>${escapeHTML(label)}</span><button class="toggle ${rv(path,0)===1?'on':''}" type="button" data-toggle="${path}" aria-label="${escapeHTML(label)}"></button></div>`;
  function updateRemoteInspector() {
    const item=remote.selected;
    const heading=`<div class="inspector-title"><h3>پردازش کانال ${names[item.kind]} ${ch2(item.n)}</h3><span class="caption">SIMULATION · مستقل از سخت‌افزار</span></div>`;
    if (item.kind!=='ch') {
      $('#remoteInspector').innerHTML=heading+`<p class="small-message">فیدر، Solo و Mute این لایه تمرینی هستند. برای تنظیم EQ، کمپرسور و Sends از لایه CH 01–32 کانالی را انتخاب کن.</p>`;
      return;
    }
    const p=`/ch/${ch2(item.n)}`;
    const tabs=[['eq','EQ · اکولایزر'],['dyn','DYNAMICS'],['send','BUS SENDS'],['pan','PAN / NAME']];
    let html=heading+`<div class="inspector-nav">${tabs.map(([id,label])=>`<button class="subtab ${remote.tab===id?'active':''}" data-remotetab="${id}">${label}</button>`).join('')}</div>`;
    if (remote.tab==='eq') {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>PARAMETRIC EQ</strong>${toggleHTML('EQ روشن',`${p}/eq/on`)}<p class="small-message">چهار باند پارامتریکِ آموزشی. EQ روی فایل صوتی بارگذاری‌شده اثر می‌گذارد.</p></div>`;
      for (let i=1;i<=4;i++) {
        const bp=`${p}/eq/${i}`;
        html+=`<div class="editor-card"><strong>BAND ${i}</strong>${controlHTML('فرکانس',`${bp}/f`,[.23,.45,.65,.87][i-1],v=>`${Math.round(20*Math.pow(1000,v))} Hz`)}${controlHTML('گین',`${bp}/g`,.5,v=>`${((v-.5)*30).toFixed(1)} dB`)}${controlHTML('Q',`${bp}/q`,.5,v=>`${(10*Math.pow(.03,v)).toFixed(2)}`)}</div>`;
      }
      html+='</div>';
    } else if (remote.tab==='dyn') {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>GATE</strong>${toggleHTML('Gate روشن',`${p}/gate/on`)}${controlHTML('Threshold',`${p}/gate/thr`,.5,v=>`${Math.round(-80+80*v)} dB`)}</div><div class="editor-card"><strong>COMPRESSOR</strong>${toggleHTML('Compressor روشن',`${p}/dyn/on`)}${controlHTML('Threshold',`${p}/dyn/thr`,.6,v=>`${Math.round(-60+60*v)} dB`)}</div></div><p class="small-message">توجه: کمپرسور روی فایل صوتی پردازش می‌شود؛ Gate در این نسخه صرفاً برای تمرین نمایش و تنظیم می‌شود.</p>`;
    } else if (remote.tab==='send') {
      html+='<div class="editor-grid">';
      for (let i=1;i<=16;i++) { const sendp=`${p}/mix/${ch2(i)}/level`; html+=`<div class="editor-card"><strong>BUS ${ch2(i)}</strong>${controlHTML('SEND LEVEL',sendp,0,v=>`${db(v)} dB`)}</div>`; }
      html+='</div>';
    } else {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>STEREO PAN</strong>${controlHTML('PAN',`${p}/mix/pan`,.5,v=>Math.abs(v-.5)<.01?'CENTER':v<.5?`L ${Math.round((.5-v)*200)}%`:`R ${Math.round((v-.5)*200)}%`)}</div><div class="editor-card"><strong>CHANNEL LABEL</strong><label class="field">نام کانال<input id="remoteChannelName" type="text" maxlength="12" value="${escapeHTML(remote.values[`${p}/config/name`]||'')}" placeholder="CH ${ch2(item.n)}" /></label><button class="soft" id="nameSave">ذخیره نام</button></div></div>`;
    }
    $('#remoteInspector').innerHTML=html;
  }
  function fmtRemote(label,v){if(label==='فرکانس')return `${Math.round(20*Math.pow(1000,v))} Hz`;if(label==='گین')return `${((v-.5)*30).toFixed(1)} dB`;if(label==='Q')return (10*Math.pow(.03,v)).toFixed(2);if(label==='PAN')return Math.abs(v-.5)<.01?'CENTER':v<.5?`L ${Math.round((.5-v)*200)}%`:`R ${Math.round((v-.5)*200)}%`;if(label==='SEND LEVEL')return `${db(v)} dB`;if(label==='Threshold')return `${Math.round(-80+80*v)} dB`;return String(v.toFixed(2));}
  function refreshInspectorValues(){
    document.querySelectorAll('#remoteInspector .control-row').forEach(el=>{
      const p=el.dataset.path;const v=remote.values[p];if(!isNumeric(v))return;
      const input=el.querySelector('input');if(input===document.activeElement)return;
      input.value=String(Math.round(clamp(v)*1000));
      el.querySelector('output').textContent=fmtRemote(input.dataset.format,v);
    });
    document.querySelectorAll('#remoteInspector .toggle').forEach(el=>el.classList.toggle('on',rv(el.dataset.toggle,0)===1));
  }
  function currentLocal(itemId) {return itemId==='file-master'?fileMaster:localTracks.find(t=>String(t.id)===itemId);}
  function localMasterItem(){return {id:'file-master',kind:'main',n:1,name:'MAIN L/R',fader:fileMaster.fader,mute:fileMaster.mute,solo:false};}
  function renderLocal() {
    $('#trackCount').textContent=`${localTracks.length} ترک`;
    $('#fileStrips').innerHTML=localTracks.length?localTracks.map(item=>stripHTML(item,'file')).join(''):'<div class="empty-state" dir="rtl">هنوز فایلی باز نشده. با «افزودن فایل از Files» شروع کن.<br /><small>فایل‌های طولانی و حجیم ممکن است در آیفون به حافظهٔ زیادی نیاز داشته باشند.</small></div>';
    $('#fileMaster').innerHTML=stripHTML(localMasterItem(),'file');
    $('#fileMaster .strip').dataset.id='file-master';
    const first=localTracks[0]; if (!localTracks.some(t=>t.id===fileSelected)) fileSelected=first?.id??null;
    updateLocalStripData();updateFileInspector();
    audioDuration=Math.max(0,...localTracks.map(t=>t.buffer.duration));
    updateTime();
  }
  function updateLocalStripData() {
    document.querySelectorAll('#fileStrips .strip,#fileMaster .strip').forEach(el=>{
      const item=el.dataset.id==='file-master'?localMasterItem():localTracks.find(t=>String(t.id)===el.dataset.id);
      if (item) updateVisualStrip(el,item,'file');
    });
  }
  function localEqDefaults() {return [
    {freq:100,gain:0,q:.8,type:'lowshelf'},
    {freq:450,gain:0,q:1,type:'peaking'},
    {freq:2500,gain:0,q:1,type:'peaking'},
    {freq:9000,gain:0,q:.8,type:'highshelf'}
  ];}
  function localRange(label,field,val,min,max,step,suffix) {
    return `<div class="control-row"><label><span>${label}</span><output>${Number(val).toFixed(step<1?1:0)}${suffix}</output></label><input type="range" data-local-field="${field}" min="${min}" max="${max}" step="${step}" value="${val}" /></div>`;
  }
  function updateFileInspector() {
    const t=localTracks.find(t=>t.id===fileSelected);
    if(!t){$('#fileInspector').innerHTML='<h3>ویرایش صدای فایل</h3><p class="small-message">یک فایل را اضافه و با SELECT انتخاب کن.</p>';return;}
    const tabs=[['eq','EQ · اکولایزر'],['dyn','COMPRESSOR'],['pan','PAN / INFO']];
    let html=`<div class="inspector-title"><h3>${escapeHTML(t.name)}</h3><span class="caption">میکس محلی · ${formatTime(t.buffer.duration)} · ${t.buffer.numberOfChannels===1?'Mono':'Stereo'}</span></div><div class="inspector-nav">${tabs.map(([id,label])=>`<button class="subtab ${id===fileTab?'active':''}" data-filetab="${id}">${label}</button>`).join('')}</div>`;
    if(fileTab==='eq'){
      html+=`<div class="editor-grid">${t.eq.map((band,i)=>`<div class="editor-card"><strong>BAND ${i+1} · ${['LOW','LOW MID','HIGH MID','HIGH'][i]}</strong>${localRange('فرکانس',`eq.${i}.freq`,band.freq,20,18000,10,' Hz')}${localRange('گین',`eq.${i}.gain`,band.gain,-15,15,.5,' dB')}${i===1||i===2?localRange('Q',`eq.${i}.q`,band.q,.3,8,.1,''):''}</div>`).join('')}</div>`;
    } else if(fileTab==='dyn'){
      html+=`<div class="editor-grid"><div class="editor-card"><strong>COMPRESSOR (روی صدای فایل)</strong><div class="toggle-row"><span>کمپرسور فعال</span><button class="toggle ${t.comp.on?'on':''}" type="button" data-local-toggle="comp.on"></button></div>${localRange('Threshold',`comp.threshold`,t.comp.threshold,-60,0,1,' dB')}${localRange('Ratio',`comp.ratio`,t.comp.ratio,1,12,.5,':1')}</div><div class="editor-card"><strong>مشخصات پردازش</strong><p class="small-message">پردازش صوت فایل با فیلترهای Web Audio و کمپرسور مرورگر انجام می‌شود و الزاماً الگوریتم داخلی کمپرسور MIDAS نیست.</p></div></div>`;
    } else {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>STEREO POSITION</strong>${localRange('Pan',`pan`,t.pan,-1,1,.01,'')}</div><div class="editor-card"><strong>فایل انتخاب‌شده</strong><p class="small-message" dir="ltr" style="text-align:left">${escapeHTML(t.name)}<br>${(t.size/1048576).toFixed(1)} MB · ${Math.round(t.buffer.sampleRate)} Hz<br>${t.buffer.numberOfChannels} channel(s)</p><button class="soft danger" type="button" data-delete-track="${t.id}">حذف این ترک</button></div></div>`;
    }
    $('#fileInspector').innerHTML=html;
  }
  function formatTime(seconds) {seconds=Math.floor(Math.max(0,seconds)||0);return `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;}
  function getOffset() {return playback ? clamp(playOffset + (audioContext.currentTime-playback.started),0,audioDuration) : playOffset;}
  function updateTime(){const offset=getOffset();$('#timeLabel').textContent=`${formatTime(offset)} / ${formatTime(audioDuration)}`;if(!lastScrub)$('#positionSlider').value=String(audioDuration?Math.round(offset/audioDuration*1000):0);}
  function createTrackAudio(ctx,t,target,startingOffset) {
    if (t.buffer.duration<=startingOffset) return null;
    const source=ctx.createBufferSource(); source.buffer=t.buffer;
    let node=source;
    const analyser=ctx.createAnalyser();analyser.fftSize=512;node.connect(analyser);node=analyser;
    const filters=[];
    t.eq.forEach(b => {
      const filter=ctx.createBiquadFilter();filter.type=b.type;filter.frequency.value=b.freq;filter.gain.value=t.eqOn===false?0:b.gain;filter.Q.value=b.q;
      node.connect(filter);node=filter;filters.push(filter);
    });
    const compressor=ctx.createDynamicsCompressor();compressor.threshold.value=t.comp.on?t.comp.threshold:0;compressor.ratio.value=t.comp.on?t.comp.ratio:1;compressor.knee.value=6;compressor.attack.value=.012;compressor.release.value=.2;
    node.connect(compressor);node=compressor;
    const vol=ctx.createGain();vol.gain.value=trackAudible(t)?gain(t.fader):0;node.connect(vol);node=vol;
    const pan=ctx.createStereoPanner();pan.pan.value=t.pan;node.connect(pan);pan.connect(target);
    source.start(0,startingOffset);
    return {source,analyser,filters,compressor,vol,pan,track:t};
  }
  function trackAudible(t) {return !t.mute && (!localTracks.some(x=>x.solo) || t.solo);}
  function makeGraph(ctx,offset) {
    const out=ctx.createGain();out.gain.value=fileMaster.mute?0:gain(fileMaster.fader);
    const limiter=ctx.createDynamicsCompressor();limiter.threshold.value=-2;limiter.ratio.value=12;limiter.knee.value=0;limiter.attack.value=.002;limiter.release.value=.08;
    out.connect(limiter);limiter.connect(ctx.destination);
    const nodes=localTracks.map(t=>createTrackAudio(ctx,t,out,offset)).filter(Boolean);
    return {nodes,out,limiter};
  }
  function updateGraph() {
    if (!playback||!audioContext) return;
    const when=audioContext.currentTime;
    playback.out.gain.setTargetAtTime(fileMaster.mute?0:gain(fileMaster.fader),when,.012);
    for (const g of playback.nodes) {
      const t=g.track;
      g.vol.gain.setTargetAtTime(trackAudible(t)?gain(t.fader):0,when,.01);
      g.pan.pan.setTargetAtTime(t.pan,when,.01);
      g.filters.forEach((f,i)=>{const eq=t.eq[i];f.frequency.setTargetAtTime(eq.freq,when,.01);f.gain.setTargetAtTime(t.eqOn===false?0:eq.gain,when,.01);f.Q.setTargetAtTime(eq.q,when,.01);});
      g.compressor.threshold.setTargetAtTime(t.comp.on?t.comp.threshold:0,when,.02);
      g.compressor.ratio.setTargetAtTime(t.comp.on?t.comp.ratio:1,when,.02);
    }
  }
  async function beginPlayback(){
    if(!localTracks.length){notify('ابتدا فایل صوتی اضافه کن.');return;}
    if(playback) return;
    if(playOffset>=audioDuration-.01)playOffset=0;
    try{
      audioContext ||= new (window.AudioContext||window.webkitAudioContext)();
      await audioContext.resume();
      const graph=makeGraph(audioContext,playOffset);
      playback={...graph,started:audioContext.currentTime};
      $('#playButton').textContent='⏸ مکث';$('#simPlayButton').textContent='⏸ مکث';requestAnimationFrame(tick);
    }catch(e){notify('پخش آغاز نشد: '+e.message);}
  }
  function haltPlayback(reset=false){
    if(playback){
      const remaining=getOffset();
      playback.nodes.forEach(n=>{try{n.source.stop();}catch{}});
      playback.out.disconnect();playback.limiter.disconnect();
      playback=null;
      playOffset=reset?0:remaining;
    } else if(reset)playOffset=0;
    $('#playButton').textContent='▶ پخش';$('#simPlayButton').textContent='▶ پخش';document.querySelectorAll('.meter-mini i').forEach(x=>x.classList.remove('lit'));updateTime();
  }
  function tick(){
    if(!playback)return;
    updateTime();
    for(const node of playback.nodes){
      const buffer=new Float32Array(node.analyser.fftSize);node.analyser.getFloatTimeDomainData(buffer);
      let power=0;for(let i=0;i<buffer.length;i++)power+=buffer[i]*buffer[i];
      const rms=Math.sqrt(power/buffer.length),t=node.track;
      const magnitude=trackAudible(t)?clamp((20*Math.log10(Math.max(1e-5,rms))+65)/60):0;
      for(const el of document.querySelectorAll(`.strip[data-id="ch-${t.channel}"],.strip[data-id="${t.id}"]`)){
        el.querySelectorAll('.meter-mini i').forEach((bar,i)=>bar.classList.toggle('lit',i<Math.round(magnitude*9)));
      }
    }
    if(getOffset()>=audioDuration-.04){haltPlayback(true);return;}requestAnimationFrame(tick);
  }
  async function loadFiles(fileList) {
    const files=Array.from(fileList||[]);if(!files.length)return;
    if(playback)haltPlayback(true);
    notify('فایل‌ها در حال باز شدن‌اند…',10000);
    try{
      audioContext||=new (window.AudioContext||window.webkitAudioContext)();
      let added=0;
      for(const file of files){
        if(localTracks.length>=32){notify('حداکثر ۳۲ فایل در کانال‌های CH پشتیبانی می‌شود.');break;}
        try{
          const bytes=await file.arrayBuffer();const buffer=await audioContext.decodeAudioData(bytes.slice(0));
          const taken=new Set(localTracks.map(t=>t.channel));let assigned=1;while(taken.has(assigned))assigned++;
          const t={id:++trackId,channel:assigned,name:file.name,fader:.75,mute:false,solo:false,pan:0,eq:localEqDefaults(),eqOn:true,comp:{on:false,threshold:-24,ratio:3},buffer,size:file.size};localTracks.push(t);applySimToTrack(t);added++;
        } catch(err){notify(`فایل «${file.name}» باز نشد؛ احتمالاً فرمت توسط مرورگر پشتیبانی نمی‌شود.`,5500);}
      }
      renderLocal();makeStrips(); if(added)notify(`${added} فایل با موفقیت وارد میز میکس شد.`);
    }catch(err){notify('خطا هنگام باز کردن فایل: '+err.message);}
    $('#audioPicker').value='';$('#simAudioPicker').value='';
  }
  function toWAV(buffer){
    const chs=2,len=buffer.length;
    const output=new ArrayBuffer(44+len*chs*2),view=new DataView(output);
    const write=(off,s)=>{for(let i=0;i<s.length;i++)view.setUint8(off+i,s.charCodeAt(i));};
    write(0,'RIFF');view.setUint32(4,36+len*4,true);write(8,'WAVE');write(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,chs,true);view.setUint32(24,buffer.sampleRate,true);view.setUint32(28,buffer.sampleRate*chs*2,true);view.setUint16(32,chs*2,true);view.setUint16(34,16,true);write(36,'data');view.setUint32(40,len*chs*2,true);
    const a=buffer.getChannelData(0),b=buffer.getChannelData(1);let offset=44;
    for(let i=0;i<len;i++){for(const v of [a[i],b[i]]){let sample=clamp(v,-1,1);view.setInt16(offset,sample<0?sample*0x8000:sample*0x7fff,true);offset+=2;}}
    return new Blob([output],{type:'audio/wav'});
  }
  async function exportMix() {
    if(!localTracks.length){notify('ابتدا فایل اضافه کن.');return;}
    if(audioDuration>300 && !confirm('خروجی WAV طولانی می‌تواند حافظه زیادی مصرف کند. ادامه می‌دهی؟'))return;
    if(audioDuration>1800){notify('برای خروجی بیشتر از ۳۰ دقیقه، از DAW کامپیوتر استفاده کن.');return;}
    const button=$('#exportButton');button.disabled=true;button.textContent='در حال ساخت WAV…';
    try {
      const rate=44100; const ctx=new OfflineAudioContext(2,Math.ceil(audioDuration*rate),rate);
      makeGraph(ctx,0);
      const result=await ctx.startRendering();
      const blob=toWAV(result);
      if (window.M32_ANDROID && window.AndroidBridge) {
        const started=window.AndroidBridge.beginWav('M32-LiveStudio-Mix.wav');
        if (!started.startsWith('OK')) throw Error(started);
        try {
          const bytes=new Uint8Array(await blob.arrayBuffer());
          const chunkSize=24*1024;
          for(let pos=0;pos<bytes.length;pos+=chunkSize) {
            const chunk=bytes.subarray(pos,Math.min(pos+chunkSize,bytes.length));
            let binary='';for(let j=0;j<chunk.length;j++)binary+=String.fromCharCode(chunk[j]);
            const status=window.AndroidBridge.appendWavChunk(btoa(binary));
            if(status!=='OK')throw Error(status);
          }
          const saved=window.AndroidBridge.finishWav();
          if(!saved.startsWith('OK:'))throw Error(saved);
          notify('فایل WAV در '+saved.slice(4)+' ذخیره شد.',6500);
        } catch(e) {window.AndroidBridge.cancelWav();throw e;}
      } else {
        const objectURL=URL.createObjectURL(blob);
        const link=document.createElement('a');link.href=objectURL;link.download='M32-LiveStudio-Mix.wav';document.body.append(link);link.click();link.remove();
        setTimeout(()=>URL.revokeObjectURL(objectURL),60000);
        notify('میکس استریوی WAV ساخته شد. فایل را در Downloads / Files ذخیره کن.');
      }
    } catch(error){notify('خروجی ساخته نشد: '+error.message,6000);}
    finally {button.disabled=false;button.textContent='↓ خروجی WAV';}
  }
  function updateFaderVisual(strip,level){
    const f=strip.querySelector('.fader-container');f.style.setProperty('--level',level);f.style.setProperty('--knob',`${(level*165).toFixed(2)}px`);f.setAttribute('aria-valuenow',String(Math.round(level*100)));
    strip.querySelector('.db-number').textContent=`${db(level)} dB`;
  }
  const throttle=new Map();
  function editStripFader(strip,level) {
    level=clamp(Math.round(level*1023)/1023);
    updateFaderVisual(strip,level);
    const itemId=strip.dataset.id;
    if (strip.dataset.mode==='remote') {
      const [kind,n]=itemId.split('-');const item={kind,n:Number(n)};
      const path=simFaderPath(item);remote.values[path]=level;
      syncAudioFromSim(path,level);persistScene();
      const prev=throttle.get(path)||0;
      if(performance.now()-prev>38){throttle.set(path,performance.now());setRemoteFader(item,level);}
    } else {
      if(itemId==='file-master'){fileMaster.fader=level;remoteSet('/main/st/mix/fader',level);updateRemoteStripData();}
      else {const item=currentLocal(itemId);if(item){item.fader=level;pushTrackToSim(item);}}
      updateGraph();
    }
  }
  function attachFaderPointers(container){
    container.addEventListener('pointerdown',e=>{
      const f=e.target.closest('.fader-container');if(!f||!container.contains(f))return;
      if(e.button!==0)return;
      e.preventDefault();f.setPointerCapture(e.pointerId);f.dataset.dragging='1';
      const update=clientY=>{const r=f.getBoundingClientRect();const raw=clamp((r.bottom-clientY-14)/(r.height-28));editStripFader(f.closest('.strip'),raw);};
      f._faderMove=event=>update(event.clientY);update(e.clientY);
    });
    container.addEventListener('pointermove',e=>{const f=e.target.closest('.fader-container');if(f?.hasPointerCapture(e.pointerId))f._faderMove?.(e);});
    const end=e=>{
      const f=e.target.closest('.fader-container');if(!f||!f.hasPointerCapture(e.pointerId))return;
      delete f.dataset.dragging;
      const strip=f.closest('.strip');
      if(strip.dataset.mode==='remote'&&remote.connected){const [kind,n]=strip.dataset.id.split('-');setRemoteFader({kind,n:Number(n)},Number((f.style.getPropertyValue('--level')||'.75').trim()));}
    };
    container.addEventListener('pointerup',end);container.addEventListener('pointercancel',end);
    container.addEventListener('keydown',e=>{
      const f=e.target.closest('.fader-container');if(!f)return;
      if(!['ArrowUp','ArrowDown','Home','End'].includes(e.key))return;e.preventDefault();
      const old=Number(f.style.getPropertyValue('--level'))||0;
      const updated=e.key==='Home'?0:e.key==='End'?1:old+(e.key==='ArrowUp'?.01:-.01);
      editStripFader(f.closest('.strip'),updated);
    });
  }
  function stripAction(event){
    const btn=event.target.closest('[data-action]');if(!btn||btn.dataset.action==='fader')return;
    const el=btn.closest('.strip');if(!el)return;
    const action=btn.dataset.action;
    if(el.dataset.mode==='remote'){
      const [kind,n]=el.dataset.id.split('-');const item={kind,n:Number(n)};
      if(action==='select'){selectRemote(item);return;}
      if(action==='mute'){const p=pathFor(item,'on');const next=remote.values[p]===0?1:0;btn.classList.toggle('active',next===0);remoteSet(p,next);}
      if(action==='solo'){const p=soloPath(item);if(!p)return;const next=remote.values[p]?0:1;btn.classList.toggle('active',next===1);remoteSet(p,next);}
    }else{
      const t=currentLocal(el.dataset.id);if(!t)return;
      if(action==='select'){if(el.dataset.id==='file-master')return;fileSelected=t.id;fileTab='eq';updateLocalStripData();updateFileInspector();}
      if(action==='mute'){if(el.dataset.id==='file-master'){fileMaster.mute=!fileMaster.mute;remoteSet('/main/st/mix/on',fileMaster.mute?0:1);}else {t.mute=!t.mute;pushTrackToSim(t);}updateLocalStripData();updateGraph();}
      if(action==='solo'&&el.dataset.id!=='file-master'){t.solo=!t.solo;pushTrackToSim(t);updateLocalStripData();updateGraph();}
    }
  }
  function activateMode(mode) {
    activeMode=mode;
    document.querySelectorAll('.mode').forEach(el=>{const active=el.dataset.mode===mode;el.classList.toggle('active',active);el.setAttribute('aria-selected',String(active));});
    $('#remoteSection').classList.toggle('hidden',mode!=='remote');$('#fileSection').classList.toggle('hidden',mode!=='file');
  }
  function initEvents(){
    $('#remoteTab').onclick=()=>activateMode('remote');$('#fileTab').onclick=()=>activateMode('file');
    $('#bankbar').addEventListener('click',e=>{const b=e.target.closest('[data-bank]');if(!b)return;remote.bank=b.dataset.bank;makeStrips();});
    for(const container of [$('#remoteStrips'),$('#remoteMaster'),$('#fileStrips'),$('#fileMaster')]){container.addEventListener('click',stripAction);attachFaderPointers(container);}
    $('#remoteInspector').addEventListener('click',async e=>{
      const tab=e.target.closest('[data-remotetab]');if(tab){remote.tab=tab.dataset.remotetab;updateRemoteInspector();return;}
      const togg=e.target.closest('[data-toggle]');if(togg){const p=togg.dataset.toggle;const next=rv(p,0)===1?0:1;await remoteSet(p,next);togg.classList.toggle('on',next===1);return;}
      if(e.target.closest('#nameSave')){
        const p=`/ch/${ch2(remote.selected.n)}/config/name`;const val=$('#remoteChannelName').value.trim();
        if(val) {await remoteSet(p,val);updateRemoteStripData();}
      }
    });
    let sliderThrottle=new Map();
    $('#remoteInspector').addEventListener('input',e=>{
      const input=e.target.closest('.remote-input');if(!input)return;
      const val=Number(input.value)/1000;const path=input.dataset.path;
      input.closest('.control-row').querySelector('output').textContent=fmtRemote(input.dataset.format,val);
      remote.values[path]=val;
      const now=performance.now();if(now-(sliderThrottle.get(path)||0)>70){sliderThrottle.set(path,now);remoteSet(path,val);}
    });
    $('#remoteInspector').addEventListener('change',e=>{const inp=e.target.closest('.remote-input');if(inp)remoteSet(inp.dataset.path,Number(inp.value)/1000);});
    $('#fileInspector').addEventListener('click',e=>{
      const tab=e.target.closest('[data-filetab]');if(tab){fileTab=tab.dataset.filetab;updateFileInspector();return;}
      const tog=e.target.closest('[data-local-toggle]');const t=localTracks.find(x=>x.id===fileSelected);
      if(tog&&t){t.comp.on=!t.comp.on;tog.classList.toggle('on',t.comp.on);updateGraph();pushTrackToSim(t);}
      const del=e.target.closest('[data-delete-track]');if(del){haltPlayback(true);localTracks=localTracks.filter(x=>x.id!==Number(del.dataset.deleteTrack));renderLocal();}
    });
    $('#fileInspector').addEventListener('input',e=>{
      const input=e.target.closest('[data-local-field]');if(!input)return;
      const t=localTracks.find(x=>x.id===fileSelected);if(!t)return;
      const f=input.dataset.localField,v=Number(input.value);
      if(f.startsWith('eq.')){const [,index,key]=f.split('.');t.eq[Number(index)][key]=v;}
      else if(f.startsWith('comp.'))t.comp[f.split('.')[1]]=v;
      else if(f==='pan')t.pan=v;
      input.closest('.control-row').querySelector('output').textContent=v.toFixed(Number(input.step)<1?1:0)+(f==='pan'?'':f.includes('freq')?' Hz':f.includes('gain')||f.includes('threshold')?' dB':f.includes('ratio')?':1':'');
      updateGraph();pushTrackToSim(t);
    });
    $('#helpButton').onclick=()=>$('#helpDialog').showModal();
    $('#simAudioPicker').onchange=e=>loadFiles(e.target.files);
    $('#demoButton').onclick=makeDemo;
    $('#simPlayButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#simStopButton').onclick=()=>haltPlayback(true);
    sceneButtons();
    $('#audioPicker').onchange=e=>loadFiles(e.target.files);
    $('#playButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#stopButton').onclick=()=>haltPlayback(true);
    $('#positionSlider').addEventListener('pointerdown',()=>lastScrub=true);
    $('#positionSlider').addEventListener('change',e=>{const wasPlaying=Boolean(playback);haltPlayback(false);playOffset=(Number(e.target.value)/1000)*audioDuration;lastScrub=false;updateTime();if(wasPlaying)beginPlayback();});
    $('#positionSlider').addEventListener('pointerup',()=>{lastScrub=false;});
    $('#exportButton').onclick=exportMix;
    $('#clearButton').onclick=()=>{if(!localTracks.length)return;if(confirm('تمام فایل‌های بارگذاری‌شده از پروژه فعلی حذف شوند؟')){haltPlayback(true);localTracks=[];renderLocal();}};
  }
  initScene();initEvents();makeStrips();renderLocal();updateRemoteInspector();
})();
