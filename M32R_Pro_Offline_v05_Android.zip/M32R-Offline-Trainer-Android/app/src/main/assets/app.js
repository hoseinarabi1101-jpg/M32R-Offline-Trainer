'use strict';
(() => {
  const $ = selector => document.querySelector(selector);
  const clamp = (x, a=0, b=1) => Math.max(a, Math.min(b, x));
  const escapeHTML = value => String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
  const nativeStore = () => Boolean(window.M32_ANDROID && window.AndroidBridge && typeof window.AndroidBridge.getStore==='function');
  const getStore = key => nativeStore() ? window.AndroidBridge.getStore(key) : localStorage.getItem(key);
  const setStore = (key,value) => nativeStore() ? window.AndroidBridge.setStore(key,value) : localStorage.setItem(key,value);
  const ch2 = n => String(n).padStart(2,'0');
  const names = { ch:'CH',auxin:'AUX',fxrtn:'FX',bus:'BUS',dca:'DCA',mtx:'MTX',mono:'MONO',main:'MAIN' };
  const banks = [
    {id:'ch1',label:'CH 01–08',kind:'ch',start:1,count:8},
    {id:'ch2',label:'CH 09–16',kind:'ch',start:9,count:8},
    {id:'ch3',label:'CH 17–24',kind:'ch',start:17,count:8},
    {id:'ch4',label:'CH 25–32',kind:'ch',start:25,count:8},
    {id:'aux',label:'AUX 01–08',kind:'auxin',start:1,count:8},
    {id:'fx',label:'FX RETURNS',kind:'fxrtn',start:1,count:8},
    {id:'bus1',label:'BUS 01–08',kind:'bus',start:1,count:8},
    {id:'bus2',label:'BUS 09–16',kind:'bus',start:9,count:8},
    {id:'dca',label:'DCA 01–08',kind:'dca',start:1,count:8},
    {id:'mtx',label:'MATRIX / MONO',kind:'mtx',start:1,count:7},
  ];
  const remote = { bank:'ch1', selected:{kind:'ch',n:1}, tab:'eq', values:{}, pending:{}, lastTouch:{}, target:null,connected:true, lastReply:0, hasBridge:false, name:'' };
  let activeMode = 'remote';
  let localTracks = [];
  let fileSelected = null;
  let fileTab = 'eq';
  let fileMaster = { fader:0.75, mute:false };
  let audioContext = null;
  let playback = null;
  let playOffset = 0;
  let audioDuration = 0;
  let lastScrub = false;
  let toastTimer = null;
  let sendOnFaders=false;
  let selectedSendBus=1;
  let saveTimer=null;
  let trackId = 0;
  let fxChannel=1;
  const geqFreqs=[20,25,31.5,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000];
  let geqGains=Array(31).fill(0);
  try{const saved=JSON.parse(getStore('m32r_geq')||'null');if(Array.isArray(saved)&&saved.length===31)geqGains=saved.map(v=>clamp(Number(v),-12,12));}catch{}
  const saveGEQ=()=>{try{setStore('m32r_geq',JSON.stringify(geqGains));}catch{}};
  let proCurrent='mixer';
  let selectedOutput='main';
  const trainingSettings={matrix:{},routing:{},brightness:90};

  const fxDefaults = () => ({
    rev:{on:true,toMain:true,level:.30,decay:2.1,predelay:35,tone:7200},
    del:{on:true,toMain:true,level:.27,time:370,feedback:.33,pingpong:true,triple:false},
    cho:{on:true,toMain:true,level:.23,rate:.9,depth:7},
    fla:{on:true,toMain:true,level:.18,rate:.3,feedback:.24}
  });
  let fxRack=fxDefaults();
  try {const saved=JSON.parse(getStore('m32r_fx')||'null');if(saved&&saved.rev&&saved.del)for(const k of Object.keys(fxRack)){fxRack[k]={...fxRack[k],...(saved[k]||{})};}}catch{}
  function saveFX(){try{setStore('m32r_fx',JSON.stringify(fxRack));}catch{}}
  function effectSendPath(n,bus){return `/ch/${ch2(n)}/mix/${ch2(bus)}/level`;}

  const channelsForBank = bank => {
    if (bank.kind === 'mtx') return [...Array(6)].map((_,i)=>({kind:'mtx',n:i+1})).concat([{kind:'mono',n:1}]);
    return [...Array(bank.count)].map((_,i)=>({kind:bank.kind,n:bank.start+i}));
  };
  const basePath = item => item.kind === 'main' ? '/main/st' : item.kind === 'mono' ? '/main/m' : `/${item.kind}/${item.kind==='dca' ? item.n : ch2(item.n)}`;
  const pathFor = (item, field) => `${basePath(item)}/mix/${field}`;
  function soloPath(item) {
    let n;
    if (item.kind==='ch') n=item.n;
    else if (item.kind==='auxin') n=32+item.n;
    else if (item.kind==='fxrtn') n=40+item.n;
    else if (item.kind==='bus') n=48+item.n;
    else if (item.kind==='mtx') n=64+item.n;
    else if (item.kind==='main') n=71;
    return n ? `/-stat/solosw/${ch2(n)}` : null;
  }
  function db(f) {
    if (f === undefined || f === null || f <= 0) return '-∞';
    const d = f >= 0.5 ? 40*f-30 : f>=.25 ? 80*f-50 : f>=.0625 ? 160*f-70 : 480*f-90;
    return (d>=0 ? '+' : '') + d.toFixed(1);
  }
  function gain(f) {
    if (f <= 0) return 0;
    const x = f >= .5 ? 40*f-30 : f>=.25 ? 80*f-50 : f>=.0625 ? 160*f-70 : 480*f-90;
    return Math.pow(10, x/20);
  }
  const notify = (message, duration=3800) => {
    const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>el.classList.remove('show'),duration);
  };
  function simFaderPath(item) {
    return sendOnFaders && item.kind === 'ch'
      ? `/ch/${ch2(item.n)}/mix/${ch2(selectedSendBus)}/level`
      : pathFor(item,'fader');
  }
  function initialScene(){
    const vals={};
    for(const kind of ['ch','auxin','fxrtn','bus','dca','mtx','mono','main']){
      const count={ch:32,auxin:8,fxrtn:8,bus:16,dca:8,mtx:6,mono:1,main:1}[kind];
      for(let n=1;n<=count;n++){
        const it={kind,n}; vals[pathFor(it,'fader')]=.75;
        vals[pathFor(it,'on')]=1;
        const sp=soloPath(it);if(sp)vals[sp]=0;
      }
    }
    for(let n=1;n<=32;n++){
      const pre=`/ch/${ch2(n)}`;
      vals[`${pre}/mix/pan`]=.5;
      vals[`${pre}/eq/on`]=1;
      vals[`${pre}/gate/on`]=0;
      vals[`${pre}/gate/thr`]=.5;
      vals[`${pre}/dyn/on`]=0;
      vals[`${pre}/dyn/thr`]=.6;
      for(let b=1;b<=4;b++){
        const bp=`${pre}/eq/${b}`;
        vals[bp+'/f']=[.233,.451,.699,.885][b-1];
        vals[bp+'/g']=.5; vals[bp+'/q']=.68;
      }
      for(let b=1;b<=16;b++)vals[`${pre}/mix/${ch2(b)}/level`]=0;
    }
    return vals;
  }
  function initScene(){
    remote.values=initialScene();
    try {
      const loaded=JSON.parse(getStore('m32r_current_state')||'null');
      if(loaded && typeof loaded==='object' && !Array.isArray(loaded))
        Object.assign(remote.values,loaded);
    }catch{}
    fileMaster.fader=remote.values['/main/st/mix/fader'];
    fileMaster.mute=remote.values['/main/st/mix/on']===0;
  }
  function persistScene(){
    clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{try{setStore('m32r_current_state',JSON.stringify(remote.values));}catch{}},250);
  }
  function trackAtChannel(n){return localTracks.find(t=>t.channel===n);}
  function syncAudioFromSim(path,value){
    const fxMatch=path.match(/^\/fxrtn\/(\d{2})\/mix\/(fader|on)$/);
    if(fxMatch){
      const fxIds=['rev','del','cho','fla'],id=fxIds[Number(fxMatch[1])-1];
      if(id){if(fxMatch[2]==='fader')fxRack[id].level=Number(value);
        else fxRack[id].on=!!value;
        saveFX();updateFXGraph();}
      return;
    }
    if(path==='/main/st/mix/fader'){fileMaster.fader=value;updateGraph();updateLocalStripData();return;}
    if(path==='/main/st/mix/on'){fileMaster.mute=value===0;updateGraph();updateLocalStripData();return;}
    const solo=path.match(/^\/-stat\/solosw\/(\d+)$/);
    if(solo){const t=trackAtChannel(+solo[1]);if(t){t.solo=!!value;updateGraph();updateLocalStripData();}return;}
    const m=path.match(/^\/ch\/(\d{2})\/(.+)$/);
    if(!m)return;
    const t=trackAtChannel(+m[1]);if(!t)return;
    const field=m[2];
    if(field==='mix/fader')t.fader=value;
    else if(field==='mix/on')t.mute=value===0;
    else if(field==='mix/pan')t.pan=(value-.5)*2;
    else if(field==='config/name')t.name=String(value);
    else if(field==='eq/on')t.eqOn=value===1;
    else if(field==='dyn/on')t.comp.on=value===1;
    else if(field==='dyn/thr')t.comp.threshold=-60+60*value;
    else {
      const e=field.match(/^eq\/(\d)\/(f|g|q)$/);
      if(e){const band=t.eq[+e[1]-1];if(band) {
        if(e[2]==='f')band.freq=20*Math.pow(1000,value);
        if(e[2]==='g')band.gain=(value-.5)*30;
        if(e[2]==='q')band.q=10*Math.pow(.03,value);
      }}
    }
    updateGraph();updateLocalStripData();
  }
  function applySimToTrack(t){
    const n=ch2(t.channel),p=`/ch/${n}`;
    for(const [path,v] of Object.entries(remote.values)){
      if(path.startsWith(p+'/')||path===`/-stat/solosw/${n}`)syncAudioFromSim(path,v);
    }
    if(!remote.values[p+'/config/name'])remote.values[p+'/config/name']=t.name.slice(0,12);
    else t.name=String(remote.values[p+'/config/name']);
    updateRemoteStripData();persistScene();
  }
  function pushTrackToSim(t){
    const n=ch2(t.channel),p=`/ch/${n}`;
    remote.values[p+'/config/name']=t.name.slice(0,12);
    remote.values[p+'/mix/fader']=t.fader;
    remote.values[p+'/mix/on']=t.mute?0:1;
    remote.values[p+'/mix/pan']=(t.pan+1)/2;
    remote.values[`/-stat/solosw/${n}`]=t.solo?1:0;
    remote.values[p+'/eq/on']=t.eqOn===false?0:1;
    remote.values[p+'/dyn/on']=t.comp.on?1:0;
    remote.values[p+'/dyn/thr']=(t.comp.threshold+60)/60;
    t.eq.forEach((band,i)=>{
      remote.values[`${p}/eq/${i+1}/f`]=clamp(Math.log(band.freq/20)/Math.log(1000));
      remote.values[`${p}/eq/${i+1}/g`]=clamp(band.gain/30+.5);
      remote.values[`${p}/eq/${i+1}/q`]=clamp(Math.log(band.q/10)/Math.log(.03));
    });
    persistScene();updateRemoteStripData();
  }
  async function remoteSet(path,value){
    remote.values[path]=value;
    syncAudioFromSim(path,value);
    persistScene();
    return true;
  }
  function sceneRestore(values){
    remote.values={...initialScene(),...values};
    for(const t of localTracks){
      const n=ch2(t.channel),p=`/ch/${n}`;
      for(const [path,v] of Object.entries(remote.values)){
        if(path.startsWith(p+'/')||path===`/-stat/solosw/${n}`)syncAudioFromSim(path,v);
      }
    }
    syncAudioFromSim('/main/st/mix/fader',remote.values['/main/st/mix/fader']);
    syncAudioFromSim('/main/st/mix/on',remote.values['/main/st/mix/on']);
    makeStrips();updateRemoteInspector();updateGraph();persistScene();renderFX();
  }
  function sceneButtons(){
    $('#saveScene').onclick=()=>{
      const name=prompt('نام Scene را وارد کن (مثل جلسه اول):','تمرین من');if(!name)return;
      try{
        const scenes=JSON.parse(getStore('m32r_scenes')||'{}');
        scenes[name.trim()]={values:JSON.parse(JSON.stringify(remote.values)),fx:JSON.parse(JSON.stringify(fxRack)),geq:geqGains.slice()};
        setStore('m32r_scenes',JSON.stringify(scenes));notify('Scene «'+name.trim()+'» ذخیره شد.');
      }catch(e){notify('ذخیره انجام نشد: '+e.message);}
    };
    $('#loadScene').onclick=()=>{
      try{
        const scenes=JSON.parse(getStore('m32r_scenes')||'{}'), names=Object.keys(scenes);
        if(!names.length){notify('هنوز Scene ذخیره نکرده‌ای.');return;}
        const name=prompt('نام Scene را وارد کن:\n'+names.join(' / '),names[names.length-1]);
        if(!name)return;if(!scenes[name.trim()]){notify('Scene پیدا نشد.');return;}
        const scene=scenes[name.trim()];sceneRestore(scene.values||scene);if(scene.fx){fxRack=fxDefaults();for(const k of Object.keys(fxRack))fxRack[k]={...fxRack[k],...(scene.fx[k]||{})};saveFX();updateFXGraph();renderFX();}if(Array.isArray(scene.geq)&&scene.geq.length===31){geqGains=scene.geq.map(v=>clamp(Number(v),-12,12));saveGEQ();updateGraph();}notify('Scene بازیابی شد.');
      }catch(e){notify('بازیابی ممکن نشد: '+e.message);}
    };
    $('#resetScene').onclick=()=>{
      if(!confirm('تمام تنظیمات میکسر مجازی صفر/پیش‌فرض شوند؟ فایل‌های صوتی حذف نمی‌شوند.'))return;
      sceneRestore({});fxRack=fxDefaults();geqGains.fill(0);saveGEQ();saveFX();updateFXGraph();updateGraph();renderFX();notify('تنظیمات به حالت پیش‌فرض برگشت.');
    };
    $('#sofButton').onclick=()=>{
      sendOnFaders=!sendOnFaders;
      const btn=$('#sofButton');btn.classList.toggle('active-sof',sendOnFaders);
      btn.textContent=`SENDS ON FADERS: ${sendOnFaders?'ON · BUS '+ch2(selectedSendBus):'OFF'}`;
      updatePracticeStatus();makeStrips();
    };
  }
  function updatePracticeStatus(){
    $('#practiceStatus').textContent=sendOnFaders
      ? `حالت Sends on Faders · BUS ${ch2(selectedSendBus)}: فیدرهای CH سطح ارسال به این باس را تغییر می‌دهند. برای عوض‌کردن باس روی BUS 1–16 برو و SELECT را بزن. (صرفاً شبیه‌سازی مسیر؛ بدون پردازش Bus)`
      : `${banks.find(b=>b.id===remote.bank)?.label||''} · حالت عادی · روی SELECT بزن تا تنظیمات کانال را ببینی. برای تمرین شنیداری از «آوردن صدای واقعی» استفاده کن.`;
  }
  async function makeDemo(){
    if(localTracks.length){notify('برای ساخت صدای آزمایشی، ابتدا ترک‌های قبلی را از بخش میکس فایل‌ها پاک کن.');return;}
    audioContext||=new (window.AudioContext||window.webkitAudioContext)();
    const rate=22050,duration=16,count=Math.round(rate*duration);
    const samples=[110,220,440,880];
    for(let i=0;i<4;i++){
      const buffer=audioContext.createBuffer(1,count,rate),data=buffer.getChannelData(0),freq=samples[i];
      for(let j=0;j<count;j++){
        const t=j/rate,env=Math.min(1,t*15)*Math.min(1,(duration-t)*5);
        data[j]=env*(.23*Math.sin(2*Math.PI*freq*t)+.08*Math.sin(2*Math.PI*freq*2*t)+.02*Math.sin(2*Math.PI*freq*3*t));
      }
      const names=['بم · Bass','صدای بم','صدای میانی','صدای زیر'];
      const t={id:++trackId,channel:i+1,name:names[i],fader:.75,mute:false,solo:false,pan:0,eq:localEqDefaults(),eqOn:true,comp:{on:false,threshold:-24,ratio:3},buffer,size:count*4};
      localTracks.push(t);applySimToTrack(t);
    }
    renderLocal();makeStrips();renderFX();notify('۴ منبع صوتی آزمایشی روی CH 1–4 قرار گرفت. پخش را بزن و EQ و فیدرها را تغییر بده.',6000);
  }
  function makeStrips() {
    $('#bankbar').innerHTML=banks.map(b=>`<button class="bank-button ${remote.bank===b.id?'active':''}" data-bank="${b.id}">${b.label}</button>`).join('');
    $('#bankCaption').textContent=banks.find(b=>b.id===remote.bank)?.label||'';
    $('#remoteStrips').innerHTML=channelsForBank(banks.find(b=>b.id===remote.bank)).map(item=>stripHTML(item,'remote')).join('');
    $('#remoteMaster').innerHTML=stripHTML({kind:'main',n:1},'remote');
    updateRemoteStripData();updatePracticeStatus();
  }
  function stripHTML(item, mode) {
    const isRemote=mode==='remote';
    const id=isRemote ? `${item.kind}-${item.n}` : String(item.id);
    const identity = isRemote ? `${names[item.kind]} ${item.kind==='main' ? 'L/R' : ch2(item.n)}` : `FILE ${String(localTracks.indexOf(item)+1).padStart(2,'0')}`;
    const selected = isRemote ? (remote.selected.kind===item.kind&&remote.selected.n===item.n) : (fileSelected===item.id);
    const value=isRemote ? remote.values[simFaderPath(item)] : item.fader;
    const level=typeof value==='number' ? clamp(value) : .75;
    const label = isRemote ? (remote.values[`${basePath(item)}/config/name`]||identity) : item.name;
    const muted = isRemote ? remote.values[pathFor(item,'on')]===0 : item.mute;
    const solo = isRemote ? Boolean(remote.values[soloPath(item)]) : item.solo;
    const soloAllowed = isRemote ? Boolean(soloPath(item)) : item.id!=='file-master';
    return `<div class="strip ${selected?'selected':''} ${item.kind==='main'?'master':''}" data-id="${escapeHTML(id)}" data-mode="${mode}">
      <div class="strip-title">${escapeHTML(identity)}</div>
      <div class="scribble"><span class="scribble-name" title="${escapeHTML(label)}">${escapeHTML(label)}</span><span class="scribble-sub">${isRemote ? (sendOnFaders&&item.kind==='ch'? 'SEND BUS '+ch2(selectedSendBus) : 'OFFLINE') : 'LOCAL AUDIO'}</span></div>
      <div class="meter-mini" aria-label="متر سطح صدای واقعی در این نسخه موجود نیست"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
      <button class="strip-btn select ${selected?'active':''}" data-action="select">SELECT</button>
      <button class="strip-btn solo ${solo?'active':''}" data-action="solo" ${soloAllowed?'':'disabled'}>SOLO</button>
      <div class="fader-container" role="slider" tabindex="0" data-action="fader" aria-label="${escapeHTML(label)} فیدر" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(level*100)}" style="--level:${level};--knob:${(level*165).toFixed(2)}px">
        <div class="fader-markers"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        <div class="fader-rail"></div><div class="fader-knob"></div>
      </div>
      <div class="db-number">${isRemote&&typeof value!=='number'?'—':db(level)} dB</div>
      <button class="strip-btn mute ${muted?'active':''}" data-action="mute">MUTE</button>
    </div>`;
  }
  function updateVisualStrip(el, item, mode) {
    if (!el) return;
    const r=mode==='remote';
    const f=r ? remote.values[simFaderPath(item)] : item.fader;
    const level=typeof f==='number'?clamp(f):.75;
    const fader=el.querySelector('.fader-container');
    if (!fader.matches(':active')&&!fader.hasAttribute('data-dragging')) {
      fader.style.setProperty('--level',level);fader.style.setProperty('--knob',`${(level*165).toFixed(2)}px`);
      fader.setAttribute('aria-valuenow',String(Math.round(level*100)));
      el.querySelector('.db-number').textContent=r&&typeof f!=='number' ? '— dB' : `${db(level)} dB`;
    }
    const name=r ? remote.values[`${basePath(item)}/config/name`] : item.name;
    if (name) el.querySelector('.scribble-name').textContent=String(name);
    const muted=r ? remote.values[pathFor(item,'on')]===0 : item.mute;
    el.querySelector('.mute').classList.toggle('active',Boolean(muted));
    const solo=r ? Boolean(remote.values[soloPath(item)]) : item.solo;
    el.querySelector('.solo').classList.toggle('active',Boolean(solo));
    const isSelected=r ? remote.selected.kind===item.kind&&remote.selected.n===item.n : fileSelected===item.id;
    el.classList.toggle('selected',isSelected);
    el.querySelector('.select').classList.toggle('active',isSelected);
  }
  function updateRemoteStripData() {
    document.querySelectorAll('#remoteStrips .strip,#remoteMaster .strip').forEach(el => {
      const [kind,n]=el.dataset.id.split('-');updateVisualStrip(el,{kind,n:Number(n)},'remote');
    });
  }
  // Offline simulator: edits are stored locally, never sent to a console.
  function setRemoteFader(item,level) {remoteSet(simFaderPath(item),level);}
  function selectRemote(item) {
    remote.selected={kind:item.kind,n:item.n};remote.tab='eq';
    updateRemoteStripData(); updateRemoteInspector();
    if(item.kind==='bus'){selectedSendBus=item.n;$('#sofButton').textContent=`SENDS ON FADERS: ${sendOnFaders?'ON · BUS '+ch2(selectedSendBus):'OFF'}`;updatePracticeStatus();}
  }
  const isNumeric = x => typeof x==='number'&&Number.isFinite(x);
  const rv = (path,defaultValue=.5) => isNumeric(remote.values[path]) ? remote.values[path] : defaultValue;
  const controlHTML = (label,path,def,formatter) => `<div class="control-row" data-path="${escapeHTML(path)}"><label><span>${label}</span><output>${escapeHTML(formatter(rv(path,def)))}</output></label><input type="range" class="remote-input" data-path="${escapeHTML(path)}" min="0" max="1000" value="${Math.round(rv(path,def)*1000)}" data-format="${escapeHTML(label)}" /></div>`;
  const toggleHTML = (label,path) => `<div class="toggle-row"><span>${escapeHTML(label)}</span><button class="toggle ${rv(path,0)===1?'on':''}" type="button" data-toggle="${path}" aria-label="${escapeHTML(label)}"></button></div>`;
  function updateRemoteInspector() {
    const item=remote.selected;
    const heading=`<div class="inspector-title"><h3>پردازش کانال ${names[item.kind]} ${ch2(item.n)}</h3><span class="caption">SIMULATION · مستقل از سخت‌افزار</span></div>`;
    if (item.kind!=='ch') {
      $('#remoteInspector').innerHTML=heading+`<p class="small-message">فیدر، Solo و Mute این لایه تمرینی هستند. برای تنظیم EQ، کمپرسور و Sends از لایه CH 01–32 کانالی را انتخاب کن.</p>`;
      return;
    }
    const p=`/ch/${ch2(item.n)}`;
    const tabs=[['eq','EQ · اکولایزر'],['dyn','DYNAMICS'],['fx','FX1 / FX2 · افکت'],['send','BUS SENDS'],['pan','PAN / NAME']];
    let html=heading+`<div class="inspector-nav">${tabs.map(([id,label])=>`<button class="subtab ${remote.tab===id?'active':''}" data-remotetab="${id}">${label}</button>`).join('')}</div>`;
    if (remote.tab==='eq') {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>PARAMETRIC EQ</strong>${toggleHTML('EQ روشن',`${p}/eq/on`)}<p class="small-message">چهار باند پارامتریکِ آموزشی. EQ روی فایل صوتی بارگذاری‌شده اثر می‌گذارد.</p></div>`;
      for (let i=1;i<=4;i++) {
        const bp=`${p}/eq/${i}`;
        html+=`<div class="editor-card"><strong>BAND ${i}</strong>${controlHTML('فرکانس',`${bp}/f`,[.23,.45,.65,.87][i-1],v=>`${Math.round(20*Math.pow(1000,v))} Hz`)}${controlHTML('گین',`${bp}/g`,.5,v=>`${((v-.5)*30).toFixed(1)} dB`)}${controlHTML('Q',`${bp}/q`,.5,v=>`${(10*Math.pow(.03,v)).toFixed(2)}`)}</div>`;
      }
      html+='</div>';
    } else if (remote.tab==='dyn') {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>GATE</strong>${toggleHTML('Gate روشن',`${p}/gate/on`)}${controlHTML('Threshold',`${p}/gate/thr`,.5,v=>`${Math.round(-80+80*v)} dB`)}</div><div class="editor-card"><strong>COMPRESSOR</strong>${toggleHTML('Compressor روشن',`${p}/dyn/on`)}${controlHTML('Threshold',`${p}/dyn/thr`,.6,v=>`${Math.round(-60+60*v)} dB`)}</div></div><p class="small-message">توجه: کمپرسور روی فایل صوتی پردازش می‌شود؛ Gate در این نسخه صرفاً برای تمرین نمایش و تنظیم می‌شود.</p>`;
    } else if(remote.tab==='fx'){
      html+=`<div class="editor-grid"><div class="editor-card"><strong>FX 1 · Reverb · BUS 13</strong>${controlHTML('SEND LEVEL',effectSendPath(item.n,13),0,v=>`${db(v)} dB`)}<p class="small-message">مقدار ارسال واقعی ریورب این کانال</p></div><div class="editor-card"><strong>FX 2 · Delay · BUS 14</strong>${controlHTML('SEND LEVEL',effectSendPath(item.n,14),0,v=>`${db(v)} dB`)}<p class="small-message">مقدار ارسال واقعی دیلی این کانال</p></div><div class="editor-card"><strong>رک افکت</strong><button class="primary" type="button" id="gotoFXfromInspector">✨ تنظیم ریورب و پینگ‌پنگ</button></div></div>`;
    } else if (remote.tab==='send') {
      html+='<div class="editor-grid">';
      for (let i=1;i<=16;i++) { const sendp=`${p}/mix/${ch2(i)}/level`; html+=`<div class="editor-card"><strong>BUS ${ch2(i)}</strong>${controlHTML('SEND LEVEL',sendp,0,v=>`${db(v)} dB`)}</div>`; }
      html+='</div>';
    } else {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>STEREO PAN</strong>${controlHTML('PAN',`${p}/mix/pan`,.5,v=>Math.abs(v-.5)<.01?'CENTER':v<.5?`L ${Math.round((.5-v)*200)}%`:`R ${Math.round((v-.5)*200)}%`)}</div><div class="editor-card"><strong>CHANNEL LABEL</strong><label class="field">نام کانال<input id="remoteChannelName" type="text" maxlength="12" value="${escapeHTML(remote.values[`${p}/config/name`]||'')}" placeholder="CH ${ch2(item.n)}" /></label><button class="soft" id="nameSave">ذخیره نام</button></div></div>`;
    }
    $('#remoteInspector').innerHTML=html;
  }
  function fmtRemote(label,v){if(label==='فرکانس')return `${Math.round(20*Math.pow(1000,v))} Hz`;if(label==='گین')return `${((v-.5)*30).toFixed(1)} dB`;if(label==='Q')return (10*Math.pow(.03,v)).toFixed(2);if(label==='PAN')return Math.abs(v-.5)<.01?'CENTER':v<.5?`L ${Math.round((.5-v)*200)}%`:`R ${Math.round((v-.5)*200)}%`;if(label==='SEND LEVEL')return `${db(v)} dB`;if(label==='Threshold')return `${Math.round(-80+80*v)} dB`;return String(v.toFixed(2));}
  function refreshInspectorValues(){
    document.querySelectorAll('#remoteInspector .control-row').forEach(el=>{
      const p=el.dataset.path;const v=remote.values[p];if(!isNumeric(v))return;
      const input=el.querySelector('input');if(input===document.activeElement)return;
      input.value=String(Math.round(clamp(v)*1000));
      el.querySelector('output').textContent=fmtRemote(input.dataset.format,v);
    });
    document.querySelectorAll('#remoteInspector .toggle').forEach(el=>el.classList.toggle('on',rv(el.dataset.toggle,0)===1));
  }
  function currentLocal(itemId) {return itemId==='file-master'?fileMaster:localTracks.find(t=>String(t.id)===itemId);}
  function localMasterItem(){return {id:'file-master',kind:'main',n:1,name:'MAIN L/R',fader:fileMaster.fader,mute:fileMaster.mute,solo:false};}
  function renderLocal() {
    $('#trackCount').textContent=`${localTracks.length} ترک`;
    $('#fileStrips').innerHTML=localTracks.length?localTracks.map(item=>stripHTML(item,'file')).join(''):'<div class="empty-state" dir="rtl">هنوز فایلی باز نشده. با «افزودن فایل از Files» شروع کن.<br /><small>فایل‌های طولانی و حجیم ممکن است در آیفون به حافظهٔ زیادی نیاز داشته باشند.</small></div>';
    $('#fileMaster').innerHTML=stripHTML(localMasterItem(),'file');
    $('#fileMaster .strip').dataset.id='file-master';
    const first=localTracks[0]; if (!localTracks.some(t=>t.id===fileSelected)) fileSelected=first?.id??null;
    updateLocalStripData();updateFileInspector();
    audioDuration=Math.max(0,...localTracks.map(t=>t.buffer.duration));
    updateTime();
  }
  function updateLocalStripData() {
    document.querySelectorAll('#fileStrips .strip,#fileMaster .strip').forEach(el=>{
      const item=el.dataset.id==='file-master'?localMasterItem():localTracks.find(t=>String(t.id)===el.dataset.id);
      if (item) updateVisualStrip(el,item,'file');
    });
  }
  function localEqDefaults() {return [
    {freq:100,gain:0,q:.8,type:'lowshelf'},
    {freq:450,gain:0,q:1,type:'peaking'},
    {freq:2500,gain:0,q:1,type:'peaking'},
    {freq:9000,gain:0,q:.8,type:'highshelf'}
  ];}
  function localRange(label,field,val,min,max,step,suffix) {
    return `<div class="control-row"><label><span>${label}</span><output>${Number(val).toFixed(step<1?1:0)}${suffix}</output></label><input type="range" data-local-field="${field}" min="${min}" max="${max}" step="${step}" value="${val}" /></div>`;
  }
  function updateFileInspector() {
    const t=localTracks.find(t=>t.id===fileSelected);
    if(!t){$('#fileInspector').innerHTML='<h3>ویرایش صدای فایل</h3><p class="small-message">یک فایل را اضافه و با SELECT انتخاب کن.</p>';return;}
    const tabs=[['eq','EQ · اکولایزر'],['dyn','COMPRESSOR'],['fx','FX SENDS'],['pan','PAN / INFO']];
    let html=`<div class="inspector-title"><h3>${escapeHTML(t.name)}</h3><span class="caption">میکس محلی · ${formatTime(t.buffer.duration)} · ${t.buffer.numberOfChannels===1?'Mono':'Stereo'}</span></div><div class="inspector-nav">${tabs.map(([id,label])=>`<button class="subtab ${id===fileTab?'active':''}" data-filetab="${id}">${label}</button>`).join('')}</div>`;
    if(fileTab==='eq'){
      html+=`<div class="editor-grid">${t.eq.map((band,i)=>`<div class="editor-card"><strong>BAND ${i+1} · ${['LOW','LOW MID','HIGH MID','HIGH'][i]}</strong>${localRange('فرکانس',`eq.${i}.freq`,band.freq,20,18000,10,' Hz')}${localRange('گین',`eq.${i}.gain`,band.gain,-15,15,.5,' dB')}${i===1||i===2?localRange('Q',`eq.${i}.q`,band.q,.3,8,.1,''):''}</div>`).join('')}</div>`;
    } else if (fileTab==='fx') {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>FX1 · REVERB / BUS 13</strong>${controlHTML('SEND LEVEL',effectSendPath(t.channel,13),0,v=>`${db(v)} dB`)}</div><div class="editor-card"><strong>FX2 · DELAY / BUS 14</strong>${controlHTML('SEND LEVEL',effectSendPath(t.channel,14),0,v=>`${db(v)} dB`)}</div><div class="editor-card"><strong>تنظیم افکت‌ها</strong><button class="primary" type="button" id="gotoFXfromFile">✨ ورود به FX RACK</button></div></div>`;
    } else if(fileTab==='dyn'){
      html+=`<div class="editor-grid"><div class="editor-card"><strong>COMPRESSOR (روی صدای فایل)</strong><div class="toggle-row"><span>کمپرسور فعال</span><button class="toggle ${t.comp.on?'on':''}" type="button" data-local-toggle="comp.on"></button></div>${localRange('Threshold',`comp.threshold`,t.comp.threshold,-60,0,1,' dB')}${localRange('Ratio',`comp.ratio`,t.comp.ratio,1,12,.5,':1')}</div><div class="editor-card"><strong>مشخصات پردازش</strong><p class="small-message">پردازش صوت فایل با فیلترهای Web Audio و کمپرسور مرورگر انجام می‌شود و الزاماً الگوریتم داخلی کمپرسور MIDAS نیست.</p></div></div>`;
    } else {
      html+=`<div class="editor-grid"><div class="editor-card"><strong>STEREO POSITION</strong>${localRange('Pan',`pan`,t.pan,-1,1,.01,'')}</div><div class="editor-card"><strong>فایل انتخاب‌شده</strong><p class="small-message" dir="ltr" style="text-align:left">${escapeHTML(t.name)}<br>${(t.size/1048576).toFixed(1)} MB · ${Math.round(t.buffer.sampleRate)} Hz<br>${t.buffer.numberOfChannels} channel(s)</p><button class="soft danger" type="button" data-delete-track="${t.id}">حذف این ترک</button></div></div>`;
    }
    $('#fileInspector').innerHTML=html;
  }

  // Web Audio FX engine: same graph used by real-time playback and WAV offline rendering.
  function fxImpulse(ctx,seconds){
    const count=Math.max(64,Math.floor(ctx.sampleRate*clamp(seconds,.3,5.2)));
    const impulse=ctx.createBuffer(2,count,ctx.sampleRate);
    for(let c=0;c<2;c++){
      const data=impulse.getChannelData(c);
      let seed=(c+1)*38531819;
      for(let i=0;i<count;i++){
        seed=(Math.imul(seed,1664525)+1013904223)|0;
        const noise=((seed>>>0)/4294967296)*2-1;
        const t=i/count;
        const envelope=Math.pow(1-t,2.8)*(1-Math.exp(-i/Math.max(1,ctx.sampleRate*.008)));
        data[i]=noise*envelope*.60;
      }
    }
    return impulse;
  }
  function buildFX(ctx,mainBus){
    const reverbIn=ctx.createGain(),delayIn=ctx.createGain();
    const predelay=ctx.createDelay(.5);predelay.delayTime.value=fxRack.rev.predelay/1000;
    const convolver=ctx.createConvolver();convolver.normalize=true;convolver.buffer=fxImpulse(ctx,fxRack.rev.decay);
    const revTone=ctx.createBiquadFilter();revTone.type='lowpass';revTone.frequency.value=fxRack.rev.tone;
    const revOut=ctx.createGain();revOut.gain.value=fxRack.rev.on&&fxRack.rev.toMain?fxRack.rev.level:0;
    reverbIn.connect(predelay);predelay.connect(convolver);convolver.connect(revTone);revTone.connect(revOut);revOut.connect(mainBus);

    const left=ctx.createDelay(1.2),right=ctx.createDelay(1.2);
    left.delayTime.value=fxRack.del.time/1000;right.delayTime.value=fxRack.del.time/1000;
    const lpan=ctx.createStereoPanner(),rpan=ctx.createStereoPanner();
    lpan.pan.value=fxRack.del.pingpong?-.95:0;rpan.pan.value=fxRack.del.pingpong?.95:0;
    const fbL=ctx.createGain(),fbR=ctx.createGain();
    fbL.gain.value=fxRack.del.feedback;fbR.gain.value=fxRack.del.feedback;
    const tap3=ctx.createDelay(4);tap3.delayTime.value=fxRack.del.time*3/1000;
    const tap3Pan=ctx.createStereoPanner();tap3Pan.pan.value=0;
    const tap3Gain=ctx.createGain();tap3Gain.gain.value=fxRack.del.triple?.34:0;
    const delOut=ctx.createGain();delOut.gain.value=fxRack.del.on&&fxRack.del.toMain?fxRack.del.level:0;
    delayIn.connect(left);left.connect(lpan);lpan.connect(delOut);
    left.connect(fbL);fbL.connect(right);right.connect(rpan);rpan.connect(delOut);
    right.connect(fbR);fbR.connect(left);
    delayIn.connect(tap3);tap3.connect(tap3Pan);tap3Pan.connect(tap3Gain);tap3Gain.connect(delOut);
    delOut.connect(mainBus);
    // FX3: modulation chorus. FX4: short modulated feedback delay (flanger).
    const choIn=ctx.createGain(),choDelay=ctx.createDelay(.08),choOut=ctx.createGain();
    choDelay.delayTime.value=.023;
    choOut.gain.value=fxRack.cho.on&&fxRack.cho.toMain?fxRack.cho.level:0;
    choIn.connect(choDelay);choDelay.connect(choOut);choOut.connect(mainBus);
    const choLfo=ctx.createOscillator(),choDepth=ctx.createGain();
    choLfo.type='sine';choLfo.frequency.value=fxRack.cho.rate;choDepth.gain.value=fxRack.cho.depth/1000;
    choLfo.connect(choDepth);choDepth.connect(choDelay.delayTime);choLfo.start(0);
    const flaIn=ctx.createGain(),flaDelay=ctx.createDelay(.04),flaOut=ctx.createGain(),flaFeedback=ctx.createGain();
    flaDelay.delayTime.value=.004;flaOut.gain.value=fxRack.fla.on&&fxRack.fla.toMain?fxRack.fla.level:0;
    flaFeedback.gain.value=fxRack.fla.feedback;
    flaIn.connect(flaDelay);flaDelay.connect(flaFeedback);flaFeedback.connect(flaDelay);
    flaDelay.connect(flaOut);flaOut.connect(mainBus);
    const flaLfo=ctx.createOscillator(),flaDepth=ctx.createGain();
    flaLfo.type='sine';flaLfo.frequency.value=fxRack.fla.rate;flaDepth.gain.value=.0024;
    flaLfo.connect(flaDepth);flaDepth.connect(flaDelay.delayTime);flaLfo.start(0);
    return {reverbIn,delayIn,choIn,flaIn,predelay,convolver,revTone,revOut,left,right,lpan,rpan,fbL,fbR,tap3,tap3Gain,delOut,choOut,choLfo,choDepth,flaOut,flaLfo,flaDelay,flaFeedback,ctx};
  }
  let lastImpulseUpdate=0;
  function updateFXGraph(force=false){
    if(!playback||!audioContext)return;
    const fx=playback.fxGraph;if(!fx)return;
    const now=audioContext.currentTime;
    const apply=(node,val)=>node.setTargetAtTime(val,now,.025);
    apply(fx.revOut.gain,fxRack.rev.on&&fxRack.rev.toMain?fxRack.rev.level:0);
    apply(fx.delOut.gain,fxRack.del.on&&fxRack.del.toMain?fxRack.del.level:0);
    apply(fx.choOut.gain,fxRack.cho.on&&fxRack.cho.toMain?fxRack.cho.level:0);
    apply(fx.flaOut.gain,fxRack.fla.on&&fxRack.fla.toMain?fxRack.fla.level:0);
    apply(fx.choLfo.frequency,fxRack.cho.rate);apply(fx.choDepth.gain,fxRack.cho.depth/1000);
    apply(fx.flaLfo.frequency,fxRack.fla.rate);apply(fx.flaFeedback.gain,fxRack.fla.feedback);
    apply(fx.predelay.delayTime,fxRack.rev.predelay/1000);
    apply(fx.revTone.frequency,fxRack.rev.tone);
    apply(fx.left.delayTime,fxRack.del.time/1000);
    apply(fx.right.delayTime,fxRack.del.time/1000);
    apply(fx.tap3.delayTime,fxRack.del.time*3/1000);
    apply(fx.fbL.gain,fxRack.del.feedback);
    apply(fx.fbR.gain,fxRack.del.feedback);
    apply(fx.lpan.pan,fxRack.del.pingpong?-.95:0);
    apply(fx.rpan.pan,fxRack.del.pingpong?.95:0);
    apply(fx.tap3Gain.gain,fxRack.del.triple?.34:0);
    const old=fx._decay;
    if(old!==fxRack.rev.decay && (force||performance.now()-lastImpulseUpdate>230)){fx.convolver.buffer=fxImpulse(audioContext,fxRack.rev.decay);fx._decay=fxRack.rev.decay;lastImpulseUpdate=performance.now();}
  }
  function fxControl(key,property,title,min,max,step,unit){
    const v=fxRack[key][property];
    const display=unit==='s'?(v/1000).toFixed(2)+' s':typeof v==='number'?(Number(v).toFixed(step>=1?0:2)+' '+unit):v;
    return `<div class="control-row"><label><span>${title}</span><output>${display}</output></label><input type="range" min="${min}" max="${max}" step="${step}" value="${v}" data-fx-key="${key}" data-fx-prop="${property}" data-fx-unit="${unit}" /></div>`;
  }
  function fxToggle(key,property,label){const val=fxRack[key][property];return `<div class="toggle-row"><span>${label}</span><button class="toggle ${val?'on':''}" type="button" data-fx-toggle="${key}.${property}" aria-pressed="${val}"></button></div>`;}
  function renderFX(){
    const rack=$('#fxControls');if(!rack)return;
    rack.innerHTML=`<div class="fx-card"><div class="fx-card-head"><h3>FX1 · REVERB</h3><span>🏛️</span></div><span class="caption">ریورب واقعی کانولوشن · Send BUS 13</span>${fxToggle('rev','on','ریورب روشن')}${fxControl('rev','level','FX RETURN · حجم افکت',0,1,.01,'')}${fxControl('rev','decay','Decay · مدت ریورب',.4,4.8,.1,'sec')}${fxControl('rev','predelay','Pre-delay · تأخیر اولیه',0,140,5,'ms')}${fxControl('rev','tone','Tone · شفافیت',700,15000,100,'Hz')}<p class="fx-explain">زمان Decay طول پژواک ریورب و Tone رنگ صوت آن را کنترل می‌کند. برای وکال، با ریورب کوتاه شروع کن.</p></div>
    <div class="fx-card"><div class="fx-card-head"><h3>FX2 · DELAY</h3><span>↔️</span></div><span class="caption">دیلی واقعی · Ping Pong و Triple Tap · Send BUS 14</span>${fxToggle('del','on','دیلی روشن')}${fxToggle('del','pingpong','Ping Pong · چپ ↔ راست')}${fxToggle('del','triple','Triple Tap · تکرار سوم')}${fxControl('del','level','FX RETURN · حجم دیلی',0,1,.01,'')}${fxControl('del','time','Time · فاصله تکرار',80,900,10,'ms')}${fxControl('del','feedback','Feedback · تعداد تکرار',0,.75,.01,'')}<p class="fx-explain">با Time فاصله شنیدن تکرار و با Feedback تعداد پژواک‌ها را کنترل کن. ولوم زیاد افکت می‌تواند صدا را شلوغ کند.</p></div>
    <div class="fx-card"><div class="fx-card-head"><h3>FX3 · CHORUS</h3><span>〰️</span></div><span class="caption">کورس شنیداری · SEND BUS 15</span>${fxToggle('cho','on','کورس روشن')}${fxControl('cho','level','FX RETURN',0,1,.01,'')}${fxControl('cho','rate','LFO Rate',.1,6,.1,'Hz')}${fxControl('cho','depth','Depth',1,12,.5,'ms')}</div>
    <div class="fx-card"><div class="fx-card-head"><h3>FX4 · FLANGER</h3><span>🎛️</span></div><span class="caption">فلنجر شنیداری · SEND BUS 16</span>${fxToggle('fla','on','فلنجر روشن')}${fxControl('fla','level','FX RETURN',0,1,.01,'')}${fxControl('fla','rate','LFO Rate',.1,2,.1,'Hz')}${fxControl('fla','feedback','Feedback',0,.7,.01,'')}</div>
    <div class="fx-card fx-planned"><h3>FX5–FX8 · TRAINING SLOTS</h3><p>چهار اسلات تکمیلی در چیدمان رک دیده می‌شوند، ولی در نسخه ۰.۵ پردازش شنیداری ندارند. مدل پردازش این اسلات‌ها هنوز پیاده‌سازی نشده است.</p><div class="slot-dummies">FX5 · MULTI FX &nbsp; | &nbsp; FX6 · MOD &nbsp; | &nbsp; FX7 · DYNAMICS &nbsp; | &nbsp; FX8 · INSERT</div></div>`;
    const dropdown=$('#fxChannelSelect');const selected=Number(dropdown?.value)||fxChannel;
    dropdown.innerHTML=Array.from({length:32},(_,i)=>{const n=i+1,t=trackAtChannel(n);return `<option value="${n}">${ch2(n)} · ${t?escapeHTML(t.name):'CH '+ch2(n)+(localTracks.length?' (بدون فایل)':'')}</option>`;}).join('');
    fxChannel=Math.min(32,Math.max(1,selected));dropdown.value=String(fxChannel);
    renderFXSends();
    $('#fxAudioStatus').textContent=localTracks.length?`${localTracks.length} فایل/ترک وارد شده · ${formatTime(audioDuration)}`:'هنوز فایلی وارد نشده';
  }
  function renderFXSends(){
    const el=$('#fxSendControls');if(!el)return;
    el.innerHTML=[{bus:13,title:'BUS 13 → FX1 Reverb'},{bus:14,title:'BUS 14 → FX2 Delay'},{bus:15,title:'BUS 15 → FX3 Chorus'},{bus:16,title:'BUS 16 → FX4 Flanger'}].map(x=>{
      const path=effectSendPath(fxChannel,x.bus),v=rv(path,0);
      return `<div class="editor-card"><strong>${x.title}</strong>${controlHTML('SEND LEVEL',path,0,val=>`${db(val)} dB`)}<div class="fx-explain">${v===0?'افکت این کانال خاموش است':`مقدار ارسال: ${db(v)} dB`}</div></div>`;
    }).join('');
  }
  function applyPreset(name){
    const d=fxDefaults();
    if(name==='vocal'){fxRack={...d,rev:{...d.rev,level:.30,decay:1.4,predelay:40},del:{...d.del,level:.16,time:315,feedback:.20,pingpong:false}};}
    else if(name==='hall'){fxRack={...d,rev:{...d.rev,level:.43,decay:3.7,predelay:65,tone:5400},del:{...d.del,level:.12}};}
    else if(name==='pingpong'){fxRack={...d,rev:{...d.rev,level:.18},del:{...d.del,level:.36,time:380,feedback:.47,pingpong:true,triple:false}};}
    else if(name==='triple'){fxRack={...d,rev:{...d.rev,level:.12},del:{...d.del,level:.35,time:235,feedback:.37,pingpong:true,triple:true}};}
    else if(name==='dry'){fxRack={...d,rev:{...d.rev,on:false},del:{...d.del,on:false},cho:{...d.cho,on:false},fla:{...d.fla,on:false}};}
    else return;
    if(name!=='dry'){
      const n=fxChannel;
      if(name==='vocal'||name==='hall')remoteSet(effectSendPath(n,13),.75);
      if(name==='pingpong'||name==='triple')remoteSet(effectSendPath(n,14),.75);
    }
    saveFX();updateFXGraph();updateGraph();renderFX();notify('پریست '+name+' اعمال شد. برای شنیدن، پخش را بزن.');
  }
  function initFXEvents(){
    $('#fxTab').onclick=()=>{activateMode('fx');renderFX();};
    $('#openFX').onclick=()=>{activateMode('fx');renderFX();};
    $('#fileFxButton').onclick=()=>{fxChannel=localTracks.find(t=>t.id===fileSelected)?.channel||1;activateMode('fx');renderFX();};
    $('#backToMixer').onclick=()=>activateMode('remote');
    $('#fxPlayButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#fxStopButton').onclick=()=>haltPlayback(true);
    $('#fxExportButton').onclick=exportMix;
    $('#fxAudioPicker').onchange=e=>loadFiles(e.target.files);
    $('#fxChannelSelect').onchange=e=>{fxChannel=+e.target.value;renderFXSends();};
    $('#fxSection').addEventListener('click',e=>{
      const preset=e.target.closest('[data-fx-preset]');if(preset){applyPreset(preset.dataset.fxPreset);return;}
      const tog=e.target.closest('[data-fx-toggle]');if(tog){const [k,property]=tog.dataset.fxToggle.split('.');fxRack[k][property]=!fxRack[k][property];saveFX();updateFXGraph();renderFX();return;}
    });
    $('#fxSection').addEventListener('change',e=>{if(e.target.matches('[data-fx-key]'))updateFXGraph(true);});
    $('#fxSection').addEventListener('input',e=>{
      const input=e.target.closest('[data-fx-key]');
      if(input){const key=input.dataset.fxKey,prop=input.dataset.fxProp,val=Number(input.value);fxRack[key][prop]=val;
        input.closest('.control-row').querySelector('output').textContent=prop==='time'?(val/1000).toFixed(2)+' s':(val.toFixed(Number(input.step)>=1?0:2)+' '+input.dataset.fxUnit);
        saveFX();updateFXGraph();return;}
      const send=e.target.closest('#fxSendControls .remote-input');if(send){const val=+send.value/1000;send.closest('.control-row').querySelector('output').textContent=`${db(val)} dB`;remoteSet(send.dataset.path,val);}
    });
  }

  function formatTime(seconds) {seconds=Math.floor(Math.max(0,seconds)||0);return `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;}
  function getOffset() {return playback ? clamp(playOffset + (audioContext.currentTime-playback.started),0,audioDuration) : playOffset;}
  function updateTime(){const offset=getOffset();$('#timeLabel').textContent=`${formatTime(offset)} / ${formatTime(audioDuration)}`;if(!lastScrub)$('#positionSlider').value=String(audioDuration?Math.round(offset/audioDuration*1000):0);}
  function createTrackAudio(ctx,t,target,fx,startingOffset) {
    if(t.buffer.duration<=startingOffset)return null;
    const source=ctx.createBufferSource();source.buffer=t.buffer;
    let node=source;
    const analyser=ctx.createAnalyser();analyser.fftSize=512;node.connect(analyser);node=analyser;
    const filters=[];
    t.eq.forEach(b=>{const filter=ctx.createBiquadFilter();filter.type=b.type;filter.frequency.value=b.freq;filter.gain.value=t.eqOn===false?0:b.gain;filter.Q.value=b.q;node.connect(filter);node=filter;filters.push(filter);});
    const compressor=ctx.createDynamicsCompressor();compressor.threshold.value=t.comp.on?t.comp.threshold:0;compressor.ratio.value=t.comp.on?t.comp.ratio:1;compressor.knee.value=6;compressor.attack.value=.012;compressor.release.value=.2;
    node.connect(compressor);node=compressor;
    const vol=ctx.createGain();vol.gain.value=trackAudible(t)?gain(t.fader):0;node.connect(vol);node=vol;
    const pan=ctx.createStereoPanner();pan.pan.value=t.pan;node.connect(pan);pan.connect(target);
    // FX sends follow fader/mute. Each FX return is shared between all 32 channel strips.
    const revSend=ctx.createGain(),delSend=ctx.createGain(),choSend=ctx.createGain(),flaSend=ctx.createGain();
    revSend.gain.value=gain(rv(effectSendPath(t.channel,13),0));
    delSend.gain.value=gain(rv(effectSendPath(t.channel,14),0));
    choSend.gain.value=gain(rv(effectSendPath(t.channel,15),0));
    flaSend.gain.value=gain(rv(effectSendPath(t.channel,16),0));
    vol.connect(revSend);revSend.connect(fx.reverbIn);
    vol.connect(delSend);delSend.connect(fx.delayIn);
    vol.connect(choSend);choSend.connect(fx.choIn);
    vol.connect(flaSend);flaSend.connect(fx.flaIn);
    source.start(0,startingOffset);
    return {source,analyser,filters,compressor,vol,pan,revSend,delSend,choSend,flaSend,track:t};
  }
  function trackAudible(t){return !t.mute&&(!localTracks.some(x=>x.solo)||t.solo);}
  function makeGraph(ctx,offset){
    const out=ctx.createGain();out.gain.value=fileMaster.mute?0:gain(fileMaster.fader);
    const limiter=ctx.createDynamicsCompressor();limiter.threshold.value=-2;limiter.ratio.value=12;limiter.knee.value=0;limiter.attack.value=.002;limiter.release.value=.08;
    let geqInput=out;
    const geqNodes=geqFreqs.map((freq,i)=>{
      const filter=ctx.createBiquadFilter();filter.type='peaking';filter.frequency.value=Math.min(freq,ctx.sampleRate*.44);filter.Q.value=4.3;filter.gain.value=geqGains[i];
      geqInput.connect(filter);geqInput=filter;return filter;
    });
    geqInput.connect(limiter);
    const spectrum=ctx.createAnalyser();spectrum.fftSize=2048;spectrum.smoothingTimeConstant=.72;
    limiter.connect(spectrum);spectrum.connect(ctx.destination);
    const fxGraph=buildFX(ctx,out);fxGraph._decay=fxRack.rev.decay;
    const nodes=localTracks.map(t=>createTrackAudio(ctx,t,out,fxGraph,offset)).filter(Boolean);
    return {nodes,out,limiter,fxGraph,geqNodes,spectrum};
  }
  function updateGraph() {
    if (!playback||!audioContext) return;
    const when=audioContext.currentTime;
    playback.out.gain.setTargetAtTime(fileMaster.mute?0:gain(fileMaster.fader),when,.012);
    playback.geqNodes.forEach((f,i)=>f.gain.setTargetAtTime(geqGains[i],when,.02));
    for (const g of playback.nodes) {
      const t=g.track;
      g.vol.gain.setTargetAtTime(trackAudible(t)?gain(t.fader):0,when,.01);
      g.pan.pan.setTargetAtTime(t.pan,when,.01);
      g.filters.forEach((f,i)=>{const eq=t.eq[i];f.frequency.setTargetAtTime(eq.freq,when,.01);f.gain.setTargetAtTime(t.eqOn===false?0:eq.gain,when,.01);f.Q.setTargetAtTime(eq.q,when,.01);});
      g.compressor.threshold.setTargetAtTime(t.comp.on?t.comp.threshold:0,when,.02);
      g.compressor.ratio.setTargetAtTime(t.comp.on?t.comp.ratio:1,when,.02);
      g.revSend.gain.setTargetAtTime(gain(rv(effectSendPath(t.channel,13),0)),when,.02);
      g.delSend.gain.setTargetAtTime(gain(rv(effectSendPath(t.channel,14),0)),when,.02);
      g.choSend.gain.setTargetAtTime(gain(rv(effectSendPath(t.channel,15),0)),when,.02);
      g.flaSend.gain.setTargetAtTime(gain(rv(effectSendPath(t.channel,16),0)),when,.02);
    }
  }
  async function beginPlayback(){
    if(!localTracks.length){notify('ابتدا فایل صوتی اضافه کن.');return;}
    if(playback) return;
    if(playOffset>=audioDuration-.01)playOffset=0;
    try{
      audioContext ||= new (window.AudioContext||window.webkitAudioContext)();
      await audioContext.resume();
      const graph=makeGraph(audioContext,playOffset);
      playback={...graph,started:audioContext.currentTime};
      $('#playButton').textContent='⏸ مکث';$('#simPlayButton').textContent='⏸ مکث';$('#fxPlayButton').textContent='⏸ مکث';requestAnimationFrame(tick);
    }catch(e){notify('پخش آغاز نشد: '+e.message);}
  }
  function haltPlayback(reset=false){
    if(playback){
      const remaining=getOffset();
      playback.nodes.forEach(n=>{try{n.source.stop();}catch{}});
      playback.out.disconnect();playback.limiter.disconnect();playback.spectrum.disconnect();
      playback.fxGraph.choLfo.stop();playback.fxGraph.flaLfo.stop();
      playback=null;
      playOffset=reset?0:remaining;
    } else if(reset)playOffset=0;
    $('#playButton').textContent='▶ پخش';$('#simPlayButton').textContent='▶ پخش';$('#fxPlayButton').textContent='▶ پخش و شنیدن';document.querySelectorAll('.meter-mini i').forEach(x=>x.classList.remove('lit'));updateTime();
  }
  function tick(){
    if(!playback)return;
    updateTime();
    for(const node of playback.nodes){
      const buffer=new Float32Array(node.analyser.fftSize);node.analyser.getFloatTimeDomainData(buffer);
      let power=0;for(let i=0;i<buffer.length;i++)power+=buffer[i]*buffer[i];
      const rms=Math.sqrt(power/buffer.length),t=node.track;
      const magnitude=trackAudible(t)?clamp((20*Math.log10(Math.max(1e-5,rms))+65)/60):0;
      for(const el of document.querySelectorAll(`.strip[data-id="ch-${t.channel}"],.strip[data-id="${t.id}"]`)){
        el.querySelectorAll('.meter-mini i').forEach((bar,i)=>bar.classList.toggle('lit',i<Math.round(magnitude*9)));
      }
    }
    if(proCurrent==='rta')renderRTAChart();
    if(getOffset()>=audioDuration-.04){haltPlayback(true);return;}requestAnimationFrame(tick);
  }
  async function loadFiles(fileList) {
    const files=Array.from(fileList||[]);if(!files.length)return;
    if(playback)haltPlayback(true);
    notify('فایل‌ها در حال باز شدن‌اند…',10000);
    try{
      audioContext||=new (window.AudioContext||window.webkitAudioContext)();
      let added=0;
      for(const file of files){
        if(localTracks.length>=32){notify('حداکثر ۳۲ فایل در کانال‌های CH پشتیبانی می‌شود.');break;}
        try{
          const bytes=await file.arrayBuffer();const buffer=await audioContext.decodeAudioData(bytes.slice(0));
          const taken=new Set(localTracks.map(t=>t.channel));let assigned=1;while(taken.has(assigned))assigned++;
          const t={id:++trackId,channel:assigned,name:file.name,fader:.75,mute:false,solo:false,pan:0,eq:localEqDefaults(),eqOn:true,comp:{on:false,threshold:-24,ratio:3},buffer,size:file.size};localTracks.push(t);applySimToTrack(t);added++;
        } catch(err){notify(`فایل «${file.name}» باز نشد؛ احتمالاً فرمت توسط مرورگر پشتیبانی نمی‌شود.`,5500);}
      }
      renderLocal();makeStrips();renderFX(); if(added)notify(`${added} فایل با موفقیت وارد میز میکس شد.`);
    }catch(err){notify('خطا هنگام باز کردن فایل: '+err.message);}
    $('#audioPicker').value='';$('#simAudioPicker').value='';
  }
  function toWAV(buffer){
    const chs=2,len=buffer.length;
    const output=new ArrayBuffer(44+len*chs*2),view=new DataView(output);
    const write=(off,s)=>{for(let i=0;i<s.length;i++)view.setUint8(off+i,s.charCodeAt(i));};
    write(0,'RIFF');view.setUint32(4,36+len*4,true);write(8,'WAVE');write(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,chs,true);view.setUint32(24,buffer.sampleRate,true);view.setUint32(28,buffer.sampleRate*chs*2,true);view.setUint16(32,chs*2,true);view.setUint16(34,16,true);write(36,'data');view.setUint32(40,len*chs*2,true);
    const a=buffer.getChannelData(0),b=buffer.getChannelData(1);let offset=44;
    for(let i=0;i<len;i++){for(const v of [a[i],b[i]]){let sample=clamp(v,-1,1);view.setInt16(offset,sample<0?sample*0x8000:sample*0x7fff,true);offset+=2;}}
    return new Blob([output],{type:'audio/wav'});
  }
  async function exportMix() {
    if(!localTracks.length){notify('ابتدا فایل اضافه کن.');return;}
    if(audioDuration>300 && !confirm('خروجی WAV طولانی می‌تواند حافظه زیادی مصرف کند. ادامه می‌دهی؟'))return;
    if(audioDuration>1800){notify('برای خروجی بیشتر از ۳۰ دقیقه، از DAW کامپیوتر استفاده کن.');return;}
    const button=$('#exportButton'),fxButton=$('#fxExportButton');button.disabled=true;fxButton.disabled=true;
    button.textContent='در حال ساخت WAV…';fxButton.textContent='در حال ساخت WAV…';
    try {
      const rate=44100; const tail=(fxRack.rev.on?fxRack.rev.decay:.1)+(fxRack.del.on?Math.min(5,fxRack.del.time/1000*6):0)+.3;
      const ctx=new OfflineAudioContext(2,Math.ceil((audioDuration+Math.min(7,tail))*rate),rate);
      makeGraph(ctx,0);
      const result=await ctx.startRendering();
      const blob=toWAV(result);
      if (window.M32_ANDROID && window.AndroidBridge) {
        const started=window.AndroidBridge.beginWav('M32-LiveStudio-Mix.wav');
        if (!started.startsWith('OK')) throw Error(started);
        try {
          const bytes=new Uint8Array(await blob.arrayBuffer());
          const chunkSize=24*1024;
          for(let pos=0;pos<bytes.length;pos+=chunkSize) {
            const chunk=bytes.subarray(pos,Math.min(pos+chunkSize,bytes.length));
            let binary='';for(let j=0;j<chunk.length;j++)binary+=String.fromCharCode(chunk[j]);
            const status=window.AndroidBridge.appendWavChunk(btoa(binary));
            if(status!=='OK')throw Error(status);
          }
          const saved=window.AndroidBridge.finishWav();
          if(!saved.startsWith('OK:'))throw Error(saved);
          notify('فایل WAV در '+saved.slice(4)+' ذخیره شد.',6500);
        } catch(e) {window.AndroidBridge.cancelWav();throw e;}
      } else {
        const objectURL=URL.createObjectURL(blob);
        const link=document.createElement('a');link.href=objectURL;link.download='M32-LiveStudio-Mix.wav';document.body.append(link);link.click();link.remove();
        setTimeout(()=>URL.revokeObjectURL(objectURL),60000);
        notify('میکس استریوی WAV ساخته شد. فایل را در Downloads / Files ذخیره کن.');
      }
    } catch(error){notify('خروجی ساخته نشد: '+error.message,6000);}
    finally {button.disabled=false;fxButton.disabled=false;button.textContent='↓ خروجی WAV با افکت‌ها';fxButton.textContent='↓ خروجی WAV با FX';}
  }
  function updateFaderVisual(strip,level){
    const f=strip.querySelector('.fader-container');f.style.setProperty('--level',level);f.style.setProperty('--knob',`${(level*165).toFixed(2)}px`);f.setAttribute('aria-valuenow',String(Math.round(level*100)));
    strip.querySelector('.db-number').textContent=`${db(level)} dB`;
  }
  const throttle=new Map();
  function editStripFader(strip,level) {
    level=clamp(Math.round(level*1023)/1023);
    updateFaderVisual(strip,level);
    const itemId=strip.dataset.id;
    if (strip.dataset.mode==='remote') {
      const [kind,n]=itemId.split('-');const item={kind,n:Number(n)};
      const path=simFaderPath(item);remote.values[path]=level;
      syncAudioFromSim(path,level);persistScene();
      const prev=throttle.get(path)||0;
      if(performance.now()-prev>38){throttle.set(path,performance.now());setRemoteFader(item,level);}
    } else {
      if(itemId==='file-master'){fileMaster.fader=level;remoteSet('/main/st/mix/fader',level);updateRemoteStripData();}
      else {const item=currentLocal(itemId);if(item){item.fader=level;pushTrackToSim(item);}}
      updateGraph();
    }
  }
  function attachFaderPointers(container){
    container.addEventListener('pointerdown',e=>{
      const f=e.target.closest('.fader-container');if(!f||!container.contains(f))return;
      if(e.button!==0)return;
      e.preventDefault();f.setPointerCapture(e.pointerId);f.dataset.dragging='1';
      const update=clientY=>{const r=f.getBoundingClientRect();const raw=clamp((r.bottom-clientY-14)/(r.height-28));editStripFader(f.closest('.strip'),raw);};
      f._faderMove=event=>update(event.clientY);update(e.clientY);
    });
    container.addEventListener('pointermove',e=>{const f=e.target.closest('.fader-container');if(f?.hasPointerCapture(e.pointerId))f._faderMove?.(e);});
    const end=e=>{
      const f=e.target.closest('.fader-container');if(!f||!f.hasPointerCapture(e.pointerId))return;
      delete f.dataset.dragging;
      const strip=f.closest('.strip');
      if(strip.dataset.mode==='remote'&&remote.connected){const [kind,n]=strip.dataset.id.split('-');setRemoteFader({kind,n:Number(n)},Number((f.style.getPropertyValue('--level')||'.75').trim()));}
    };
    container.addEventListener('pointerup',end);container.addEventListener('pointercancel',end);
    container.addEventListener('keydown',e=>{
      const f=e.target.closest('.fader-container');if(!f)return;
      if(!['ArrowUp','ArrowDown','Home','End'].includes(e.key))return;e.preventDefault();
      const old=Number(f.style.getPropertyValue('--level'))||0;
      const updated=e.key==='Home'?0:e.key==='End'?1:old+(e.key==='ArrowUp'?.01:-.01);
      editStripFader(f.closest('.strip'),updated);
    });
  }
  function stripAction(event){
    const btn=event.target.closest('[data-action]');if(!btn||btn.dataset.action==='fader')return;
    const el=btn.closest('.strip');if(!el)return;
    const action=btn.dataset.action;
    if(el.dataset.mode==='remote'){
      const [kind,n]=el.dataset.id.split('-');const item={kind,n:Number(n)};
      if(action==='select'){selectRemote(item);return;}
      if(action==='mute'){const p=pathFor(item,'on');const next=remote.values[p]===0?1:0;btn.classList.toggle('active',next===0);remoteSet(p,next);}
      if(action==='solo'){const p=soloPath(item);if(!p)return;const next=remote.values[p]?0:1;btn.classList.toggle('active',next===1);remoteSet(p,next);}
    }else{
      const t=currentLocal(el.dataset.id);if(!t)return;
      if(action==='select'){if(el.dataset.id==='file-master')return;fileSelected=t.id;fileTab='eq';updateLocalStripData();updateFileInspector();}
      if(action==='mute'){if(el.dataset.id==='file-master'){fileMaster.mute=!fileMaster.mute;remoteSet('/main/st/mix/on',fileMaster.mute?0:1);}else {t.mute=!t.mute;pushTrackToSim(t);}updateLocalStripData();updateGraph();}
      if(action==='solo'&&el.dataset.id!=='file-master'){t.solo=!t.solo;pushTrackToSim(t);updateLocalStripData();updateGraph();}
    }
  }
  function activateMode(mode) {
    activeMode=mode;$('#proWorkspace').classList.add('hidden');
    document.querySelectorAll('.mode').forEach(el=>{const active=el.dataset.mode===mode;el.classList.toggle('active',active);el.setAttribute('aria-selected',String(active));});
    $('#remoteSection').classList.toggle('hidden',mode!=='remote');$('#fileSection').classList.toggle('hidden',mode!=='file');$('#fxSection').classList.toggle('hidden',mode!=='fx');
    if(mode==='fx'){renderFX();window.scrollTo({top:0,behavior:'smooth'});}
  }
  function initEvents(){
    $('#remoteTab').onclick=()=>activateMode('remote');$('#fileTab').onclick=()=>activateMode('file');initFXEvents();
    $('#bankbar').addEventListener('click',e=>{const b=e.target.closest('[data-bank]');if(!b)return;remote.bank=b.dataset.bank;makeStrips();});
    for(const container of [$('#remoteStrips'),$('#remoteMaster'),$('#fileStrips'),$('#fileMaster')]){container.addEventListener('click',stripAction);attachFaderPointers(container);}
    $('#remoteInspector').addEventListener('click',async e=>{
      if(e.target.closest('#gotoFXfromInspector')){fxChannel=remote.selected.n;activateMode('fx');return;}
      const tab=e.target.closest('[data-remotetab]');if(tab){remote.tab=tab.dataset.remotetab;updateRemoteInspector();return;}
      const togg=e.target.closest('[data-toggle]');if(togg){const p=togg.dataset.toggle;const next=rv(p,0)===1?0:1;await remoteSet(p,next);togg.classList.toggle('on',next===1);return;}
      if(e.target.closest('#nameSave')){
        const p=`/ch/${ch2(remote.selected.n)}/config/name`;const val=$('#remoteChannelName').value.trim();
        if(val) {await remoteSet(p,val);updateRemoteStripData();}
      }
    });
    let sliderThrottle=new Map();
    $('#remoteInspector').addEventListener('input',e=>{
      const input=e.target.closest('.remote-input');if(!input)return;
      const val=Number(input.value)/1000;const path=input.dataset.path;
      input.closest('.control-row').querySelector('output').textContent=fmtRemote(input.dataset.format,val);
      remote.values[path]=val;
      const now=performance.now();if(now-(sliderThrottle.get(path)||0)>70){sliderThrottle.set(path,now);remoteSet(path,val);}
    });
    $('#remoteInspector').addEventListener('change',e=>{const inp=e.target.closest('.remote-input');if(inp)remoteSet(inp.dataset.path,Number(inp.value)/1000);});
    $('#fileInspector').addEventListener('click',e=>{
      const tab=e.target.closest('[data-filetab]');if(tab){fileTab=tab.dataset.filetab;updateFileInspector();return;}
      const tog=e.target.closest('[data-local-toggle]');const t=localTracks.find(x=>x.id===fileSelected);
      if(tog&&t){t.comp.on=!t.comp.on;tog.classList.toggle('on',t.comp.on);updateGraph();pushTrackToSim(t);}
      if(e.target.closest('#gotoFXfromFile')){fxChannel=t?.channel||1;activateMode('fx');return;}
      const del=e.target.closest('[data-delete-track]');if(del){haltPlayback(true);localTracks=localTracks.filter(x=>x.id!==Number(del.dataset.deleteTrack));renderLocal();}
    });
    $('#fileInspector').addEventListener('input',e=>{
      const fxinput=e.target.closest('.remote-input');if(fxinput){const v=Number(fxinput.value)/1000;fxinput.closest('.control-row').querySelector('output').textContent=`${db(v)} dB`;remoteSet(fxinput.dataset.path,v);return;}
      const input=e.target.closest('[data-local-field]');if(!input)return;
      const t=localTracks.find(x=>x.id===fileSelected);if(!t)return;
      const f=input.dataset.localField,v=Number(input.value);
      if(f.startsWith('eq.')){const [,index,key]=f.split('.');t.eq[Number(index)][key]=v;}
      else if(f.startsWith('comp.'))t.comp[f.split('.')[1]]=v;
      else if(f==='pan')t.pan=v;
      input.closest('.control-row').querySelector('output').textContent=v.toFixed(Number(input.step)<1?1:0)+(f==='pan'?'':f.includes('freq')?' Hz':f.includes('gain')||f.includes('threshold')?' dB':f.includes('ratio')?':1':'');
      updateGraph();pushTrackToSim(t);
    });
    $('#helpButton').onclick=()=>$('#helpDialog').showModal();
    $('#simAudioPicker').onchange=e=>loadFiles(e.target.files);
    $('#demoButton').onclick=makeDemo;
    $('#simPlayButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#simStopButton').onclick=()=>haltPlayback(true);
    sceneButtons();
    $('#audioPicker').onchange=e=>loadFiles(e.target.files);
    $('#playButton').onclick=()=>{if(playback)haltPlayback(false);else beginPlayback();};
    $('#stopButton').onclick=()=>haltPlayback(true);
    $('#positionSlider').addEventListener('pointerdown',()=>lastScrub=true);
    $('#positionSlider').addEventListener('change',e=>{const wasPlaying=Boolean(playback);haltPlayback(false);playOffset=(Number(e.target.value)/1000)*audioDuration;lastScrub=false;updateTime();if(wasPlaying)beginPlayback();});
    $('#positionSlider').addEventListener('pointerup',()=>{lastScrub=false;});
    $('#exportButton').onclick=exportMix;
    $('#clearButton').onclick=()=>{if(!localTracks.length)return;if(confirm('تمام فایل‌های بارگذاری‌شده از پروژه فعلی حذف شوند؟')){haltPlayback(true);localTracks=[];renderLocal();}};
  }
  // ---------------------------------------------------------------------------
  // Pro surface: fourteen screens, with real main GEQ, FX1..4, meters and WAV.
  // Other buses, matrix routing, and 5-8 FX slots are training-only in v0.5.
  // ---------------------------------------------------------------------------
  const proPages=[
    ['mixer','01','میکسر','MIXER'],['channel','02','کانال و EQ','CHANNEL'],
    ['dynamics','03','داینامیک','DYNAMICS'],['sends','04','ارسال‌ها','SENDS'],
    ['geq','05','اکولایزر ۳۱ باند','GEQ'],['fx','06','رک افکت','FX RACK'],
    ['fxreturns','07','بازگشت افکت','FX RETURNS'],['matrix','08','ماتریکس','MATRIX'],
    ['routing','09','مسیریابی','ROUTING'],['player','10','پخش فایل','PLAYER'],
    ['scenes','11','صحنه‌ها','SCENES'],['setup','12','تنظیمات','SETUP'],
    ['rta','13','آنالایزر','RTA'],['export','14','خروجی WAV','EXPORT']
  ];
  const geqOther={};
  const trainingOutputs=['main',...Array.from({length:16},(_,i)=>`bus${i+1}`),...Array.from({length:6},(_,i)=>`matrix${i+1}`)];
  const outLabel=id=>id==='main'?'MAIN L/R':id.startsWith('bus')?`BUS ${ch2(Number(id.slice(3)))}`:`MATRIX ${Number(id.slice(6))}`;
  const proCard=(heading,body,mini='')=>`<article class="pro-card"><div class="pro-card-top"><h3>${heading}</h3>${mini?`<span class="pro-badge">${mini}</span>`:''}</div>${body}</article>`;
  const fieldSlider=(key,label,value,min,max,step,unit='')=>`<label class="pro-slider"><span>${label} <output>${Number(value).toFixed(step>=1?0:1)}${unit}</output></span><input data-pro-slider="${key}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"></label>`;
  const banner=(label,text)=>`<div class="pro-banner"><strong>${label}</strong><span>${text}</span></div>`;
  function updateNav(){
    document.querySelectorAll('#proNav [data-pro-page]').forEach(b=>b.classList.toggle('selected',b.dataset.proPage===proCurrent));
  }
  function showProPage(id){
    proCurrent=id;
    updateNav();
    const inspectorModes={mixer:['remote',null],channel:['remote','eq'],dynamics:['remote','dyn'],sends:['remote','send'],fx:['fx',null],player:['file',null]};
    if(inspectorModes[id]){
      const [mode,tab]=inspectorModes[id];
      if(mode==='remote'&&tab){remote.selected.kind='ch';remote.tab=tab;remote.bank='ch1';makeStrips();updateRemoteInspector();}
      activateMode(mode);
    }else{
      activeMode='pro';
      for(const section of ['remoteSection','fileSection','fxSection'])$('#'+section).classList.add('hidden');
      $('#proWorkspace').classList.remove('hidden');
      renderPro();
    }
    // Keep navigation in view when selecting from the 14-page menu.
    $('#proNav').scrollIntoView({block:'start',behavior:'instant'});
  }
  function proGains(){return selectedOutput==='main'?geqGains:(geqOther[selectedOutput]||=Array(31).fill(0));}
  const freqCaption=f=>f>=1000?(f/1000).toString().replace('.5','.5')+'k':String(f);
  function renderGEQPlot(){
    const canvas=$('#geqPlot');if(!canvas)return;
    const dpi=window.devicePixelRatio||1,w=Math.max(200,canvas.clientWidth),h=170;
    canvas.width=Math.round(w*dpi);canvas.height=Math.round(h*dpi);
    const c=canvas.getContext('2d');c.scale(dpi,dpi);c.clearRect(0,0,w,h);
    const mid=h/2,padding=13;
    c.strokeStyle='#26394b';c.lineWidth=1;
    for(let i=-12;i<=12;i+=3){let y=mid-i*5.1;c.beginPath();c.moveTo(10,y);c.lineTo(w-10,y);c.stroke();}
    for(let i=0;i<=10;i++){let x=padding+(w-padding*2)*i/10;c.beginPath();c.moveTo(x,6);c.lineTo(x,h-6);c.stroke();}
    const curve=proGains(),points=[];
    for(let t=0;t<500;t++){
      const f=20*Math.pow(1000,t/499);let dbSum=0;
      for(let k=0;k<31;k++){
        const d=Math.log2(f/geqFreqs[k]);dbSum+=curve[k]*Math.exp(-.5*(d/.20)**2);
      }
      points.push([padding+(w-2*padding)*t/499,mid-Math.max(-14,Math.min(14,dbSum))*5.1]);
    }
    c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.strokeStyle='#f7ba58';c.lineWidth=3;c.stroke();
    c.font='10px monospace';c.fillStyle='#a7b6ca';c.fillText('+12',4,22);c.fillText('0',4,mid-6);c.fillText('-12',4,h-16);
  }
  function renderRTAChart(){
    const canvas=$('#rtaCanvas');if(!canvas)return;
    const w=Math.max(200,canvas.clientWidth),h=235,dpi=window.devicePixelRatio||1;
    if(canvas.width!==Math.round(w*dpi)||canvas.height!==Math.round(h*dpi)){canvas.width=Math.round(w*dpi);canvas.height=Math.round(h*dpi);}
    const c=canvas.getContext('2d');c.setTransform(dpi,0,0,dpi,0,0);c.clearRect(0,0,w,h);
    for(let i=0;i<5;i++){c.strokeStyle='#25374a';c.beginPath();c.moveTo(6,13+i*48);c.lineTo(w-6,13+i*48);c.stroke();}
    if(!playback?.spectrum){c.fillStyle='#b7c9d8';c.font='14px sans-serif';c.textAlign='center';c.fillText('برای نمایش طیف فرکانسی، یک فایل صوتی پخش کن',w/2,h/2);return;}
    const n=playback.spectrum.frequencyBinCount,bytes=new Uint8Array(n);playback.spectrum.getByteFrequencyData(bytes);
    const steps=75,nyquist=audioContext.sampleRate/2,barW=(w-24)/steps;
    for(let i=0;i<steps;i++){
      const f=25*Math.pow(800,i/(steps-1)),index=Math.max(0,Math.min(n-1,Math.round(f/nyquist*n))),value=bytes[index]/255;
      const y=(h-29)*Math.pow(value,1.18);
      c.fillStyle=value>.8?'#f49e68':value>.54?'#f1c66f':'#46dbb6';
      c.fillRect(12+i*barW,h-20-y,Math.max(2,barW-1),y);
    }
    c.textAlign='left';c.fillStyle='#c1d5e0';c.font='12px monospace';['30','100','300','1k','3k','10k','20k'].forEach((f,i)=>c.fillText(f,12+(w-56)*i/6,h-2));
  }
  function renderPro(){
    const page=proPages.find(p=>p[0]===proCurrent)||proPages[0];
    $('#proTitle').textContent=`${page[2]} / ${page[3]}`;
    $('#proTag').textContent=['geq','fxreturns','rta','export'].includes(proCurrent)?'LIVE AUDIO ENGINE':'TRAINING / AUDIO';
    const el=$('#proContent');let content='';
    if(proCurrent==='geq'){
      const real=selectedOutput==='main',vals=proGains();
      content=`${banner(real?'✅ پردازش شنیداری فعال':'⚠️ نمایش و تمرین فقط',real?'این ۳۱ فیلتر روی MAIN L/R، هنگام پخش فایل و در خروجی WAV اعمال می‌شوند.':'برای BUS و MATRIX فعلاً تنظیمات قابل تمرین‌اند، اما روی فایل خروجی صوتی اعمال نمی‌شوند.')}
      <div class="pro-tools"><label>خروجی مورد نظر <select id="geqOutput">${trainingOutputs.map(o=>`<option value="${o}" ${o===selectedOutput?'selected':''}>${outLabel(o)}</option>`).join('')}</select></label>
      <button class="soft" data-pro-click="geq-flat">FLAT · صفرکردن</button><button class="soft" data-pro-click="geq-vocal">Speech Curve</button><button class="soft" data-pro-click="geq-dip">Room Trim</button></div>
      ${proCard('GRAPHIC EQ · RESPONSE CURVE','<canvas id="geqPlot" aria-label="نمودار پاسخ ۳۱ باند"></canvas>','31 BAND')}
      ${proCard('31 BAND EQUALIZER',`<div class="geq-scroll" dir="ltr"><div class="geq-bands">${vals.map((v,i)=>`<div class="geq-band"><output>${v>0?'+':''}${v.toFixed(0)}</output><input type="range" data-geq="${i}" aria-label="GEQ ${geqFreqs[i]} Hz" min="-12" max="12" step=".5" value="${v}" orient="vertical"><span>${freqCaption(geqFreqs[i])}</span></div>`).join('')}</div></div>`,'±12 dB')}`;
    } else if(proCurrent==='fxreturns'){
      content=banner('✅ شنیداری و واقعی در نسخه ۰.۵','فیدر FX RETURN و کلید ارسال به MAIN به‌طور واقعی روی ریورب، دیلی، کورس و فلنجر اثر دارند.');
      content+=`<div class="pro-cards four">${[['rev','FX1 · REVERB'],['del','FX2 · DELAY'],['cho','FX3 · CHORUS'],['fla','FX4 · FLANGER']].map(([id,n])=>proCard(n,`${fieldSlider('fx.'+id+'.level','FX Return Level',fxRack[id].level,0,1,.01)}<div class="pro-actions"><button data-pro-toggle="${id}.on" class="soft ${fxRack[id].on?'pro-on':''}">${fxRack[id].on?'ON':'MUTE'}</button><button data-pro-toggle="${id}.toMain" class="soft ${fxRack[id].toMain?'pro-on':''}">${fxRack[id].toMain?'→ MAIN L/R':'MAIN قطع'}</button></div>`, 'FX RETURN')).join('')}</div>`;
      content+=banner('FX5–FX8','اسلات‌های ۵ تا ۸ در چیدمان نسخه بعدی وجود خواهند داشت؛ در این نسخه شنیداری نیستند.');
    } else if(proCurrent==='routing'){
      const ch=Math.max(1,Math.min(32,fxChannel));
      content=banner('Routing در نسخه ۰.۵','مسیریابی FX BUS 13 تا 16 و برگشت FX به MAIN عملیاتی است. Patch فیزیکی AES50، XLR و Direct Out در شبیه‌ساز آفلاین کاربرد ندارد و فعلاً صرفاً آموزشی است.');
      content+=`<div class="pro-flow" dir="ltr"><span>CH ${ch2(ch)}</span><b>→</b><span>BUS 13–16</span><b>→</b><span>FX 1–4</span><b>→</b><span>FX RETURN</span><b>→</b><span>MAIN L/R</span></div>
       <div class="pro-tools"><label>کانال مبدا <select id="proFXChannel">${Array.from({length:32},(_,i)=>`<option ${i+1===ch?'selected':''} value="${i+1}">CH ${ch2(i+1)}${trackAtChannel(i+1)?' · '+escapeHTML(trackAtChannel(i+1).name):''}</option>`).join('')}</select></label><button class="primary" data-pro-click="tofx">ویرایش رک FX</button></div>
       <div class="pro-cards four">${[['13','Reverb'],['14','Delay'],['15','Chorus'],['16','Flanger']].map(([b,name])=>{let v=rv(effectSendPath(ch,Number(b)),0);return proCard(`BUS ${b} → ${name}`,fieldSlider(`send.${b}`,`Send CH ${ch2(ch)} · ${db(v)} dB`,v,0,1,.01),'SEND / POST');}).join('')}</div>`;
    } else if(proCurrent==='matrix'){
      content=banner('⚠️ صفحه تمرینی (بدون پردازش ماتریکس)','در این نسخه فیدرهای ماتریکس و مسیرهای زیر برای آشنایی با ساختار M32R هستند. خروجی‌های فیزیکی مستقل یا متریکس صوتی واقعی ساخته نمی‌شوند.');
      content+=`<div class="pro-flow" dir="ltr"><span>MAIN L/R</span><b>→</b><span>MATRIX 1–6</span><b>→</b><span>SPEAKERS / ZONES</span></div><div class="pro-cards three">${Array.from({length:6},(_,i)=>{const n=i+1,v=trainingSettings.matrix[n]??.75;return proCard('MATRIX '+n,`${fieldSlider('matrix.'+n,'سطح تمرینی',v,0,1,.01)}<span class="pro-muted">فقط نمایش آموزشی</span>`,'TRAINING');}).join('')}</div>`;
    } else if(proCurrent==='scenes'){
      let sceneNames=[];try{sceneNames=Object.keys(JSON.parse(getStore('m32r_scenes')||'{}'));}catch{}
      content=banner('ذخیره Scene','فیدرها، EQ کانال‌ها، GEQ مستر، باس‌سندها و تنظیم‌های FX ذخیره می‌شوند. صدای فایل‌های بارگذاری‌شده در Scene ذخیره نمی‌شود.');
      content+=`<div class="pro-tools"><button class="primary" data-pro-click="save-scene">💾 ذخیره Scene</button><button class="soft" data-pro-click="load-scene">↺ بازیابی Scene</button><button class="soft" data-pro-click="reset-scene">شروع از صفر</button></div>${proCard('SCENE MEMORY',sceneNames.length?`<div class="scene-tags">${sceneNames.map(x=>`<span>${escapeHTML(x)}</span>`).join('')}</div>`:'<p class="pro-muted">هنوز Scene ذخیره‌شده‌ای نداری.</p>')}`;
    } else if(proCurrent==='setup'){
      content=proCard('SYSTEM / OFFLINE AUDIO',`<div class="pro-specs"><div><small>حالت</small><b>OFFLINE · LOCAL</b></div><div><small>Audio Input</small><b>FILES ON DEVICE</b></div><div><small>Mixdown</small><b>44.1 kHz · 16-bit WAV</b></div><div><small>Connection</small><b>NO MIXER / NO NETWORK</b></div><div><small>GEQ</small><b>MAIN 31-BAND</b></div><div><small>Active FX</small><b>REVERB / DELAY / CHORUS / FLANGER</b></div></div>`,'DEVICE INFO');
      content+=banner('کار با گوشی','برای تمرین با فیدرهای بیشتر، گوشی را افقی بگیر. برنامه پس از نصب، بدون اینترنت به میکسر مجازی دسترسی می‌دهد.');
    } else if(proCurrent==='rta'){
      content=banner('RTA LIVE','نمایش طیف صدای میکس‌شده از خروجی برنامه است. این RTA صدای میکروفون یا صدای محیط سالن را اندازه‌گیری نمی‌کند.');
      content+=`<div class="pro-tools"><label class="primary pick-file" for="rtaAudioPicker">＋ افزودن فایل WAV/MP3</label><input type="file" id="rtaAudioPicker" accept="audio/*" multiple hidden><button class="primary" data-pro-click="play-audio">▶ پخش / مکث</button><button class="soft" data-pro-click="stop-audio">■ توقف</button></div>${proCard('REAL TIME ANALYZER · FFT','<canvas id="rtaCanvas" aria-label="فرکانس صدای میکس"></canvas>','LIVE SPECTRUM')}`;
    } else if(proCurrent==='export'){
      content=banner('WAV EXPORT · میکس آفلاین','تمام ترک‌های بارگذاری‌شده، فیدر، پن، اکولایزر ۴ بانده، کمپرسور کانال، GEQ مستر، FX1–FX4 و Master وارد فایل خروجی WAV می‌شوند.');
      content+=`${proCard('FINAL MIXDOWN',`<p class="pro-muted">ترک فعال: ${localTracks.length} | مدت: ${formatTime(audioDuration)} | کیفیت WAV: 44.1 kHz / 16-bit / Stereo</p><div class="pro-actions"><button class="primary" data-pro-click="export-wav">↓ ساخت WAV با تمام افکت‌ها</button><button class="soft" data-pro-click="to-player">♫ مدیریت فایل‌ها</button></div><p class="pro-muted">خروجی طولانی به حافظه زیادی نیاز دارد. خروجی MP3 هنوز پیاده‌سازی نشده است.</p>`,'EXPORT')}`;
    }
    el.innerHTML=content;
    if(proCurrent==='geq')requestAnimationFrame(renderGEQPlot);
    if(proCurrent==='rta')requestAnimationFrame(renderRTAChart);
  }
  function initPro(){
    const nav=$('#proNav');nav.innerHTML=proPages.map(([id,n,label,en])=>`<button class="pro-tab" data-pro-page="${id}"><span class="pro-tab-number">${n}</span><strong>${label}</strong><small>${en}</small></button>`).join('');
    updateNav();
    nav.addEventListener('click',e=>{const btn=e.target.closest('[data-pro-page]');if(btn)showProPage(btn.dataset.proPage);});
    $('#proWorkspace').addEventListener('change',e=>{
      if(e.target.id==='geqOutput'){selectedOutput=e.target.value;renderPro();}
      if(e.target.id==='proFXChannel'){fxChannel=Number(e.target.value);renderPro();}
      if(e.target.id==='rtaAudioPicker')loadFiles(e.target.files);
    });
    $('#proWorkspace').addEventListener('input',e=>{
      const slider=e.target.closest('[data-geq]');if(slider){
        const index=Number(slider.dataset.geq),v=Number(slider.value);proGains()[index]=v;
        slider.closest('.geq-band').querySelector('output').textContent=(v>0?'+':'')+v.toFixed(1);
        if(selectedOutput==='main'){saveGEQ();updateGraph();}renderGEQPlot();return;
      }
      const p=e.target.closest('[data-pro-slider]');if(!p)return;
      const key=p.dataset.proSlider,v=Number(p.value);
      p.closest('.pro-slider').querySelector('output').textContent=v.toFixed(Number(p.step)>=1?0:2);
      if(key.startsWith('matrix.'))trainingSettings.matrix[Number(key.split('.')[1])]=v;
      if(key.startsWith('fx.')){const [,fx,field]=key.split('.');fxRack[fx][field]=v;saveFX();updateFXGraph();}
      if(key.startsWith('send.'))remoteSet(effectSendPath(fxChannel,Number(key.split('.')[1])),v);
    });
    $('#proWorkspace').addEventListener('click',e=>{
      const toggle=e.target.closest('[data-pro-toggle]');if(toggle){const [fx,property]=toggle.dataset.proToggle.split('.');fxRack[fx][property]=!fxRack[fx][property];saveFX();updateFXGraph();renderPro();return;}
      const btn=e.target.closest('[data-pro-click]');if(!btn)return;
      const action=btn.dataset.proClick;
      if(action==='geq-flat'){proGains().fill(0);if(selectedOutput==='main'){saveGEQ();updateGraph();}renderPro();}
      else if(action==='geq-vocal'||action==='geq-dip'){
        const vals=proGains();vals.fill(0);
        geqFreqs.forEach((f,i)=>{vals[i]=action==='geq-vocal'?(f<80?-4:f<180?-2:f>4500?1.5:0):(f>180&&f<450?-3:f>1800&&f<3500?-2:0);});
        if(selectedOutput==='main'){saveGEQ();updateGraph();}renderPro();
      }
      else if(action==='save-scene'){$('#saveScene').click();renderPro();}
      else if(action==='load-scene'){$('#loadScene').click();renderPro();}
      else if(action==='reset-scene'){$('#resetScene').click();renderPro();}
      else if(action==='export-wav')exportMix();
      else if(action==='to-player')showProPage('player');
      else if(action==='tofx')showProPage('fx');
      else if(action==='play-audio'){if(playback)haltPlayback(false);else beginPlayback();}
      else if(action==='stop-audio')haltPlayback(true);
    });
    window.addEventListener('resize',()=>{if(proCurrent==='geq')renderGEQPlot();if(proCurrent==='rta')renderRTAChart();});
    window.M32PRO_TEST={getPage:()=>proCurrent,getTracks:()=>localTracks.length,getGEQ:()=>geqGains.slice(),getFX:()=>JSON.parse(JSON.stringify(fxRack)),selectPage:showProPage};
  }

  initPro();
  initScene();initEvents();makeStrips();renderLocal();updateRemoteInspector();renderFX();
})();
